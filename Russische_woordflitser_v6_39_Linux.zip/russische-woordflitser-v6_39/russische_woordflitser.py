#!/usr/bin/env python3
"""Russische woordflitser v6.39 — Afteltekst uitsluitend tot het antwoord.

Geen externe Python-pakketten vereist voor de popup zelf (wel python3-tk).
Optioneel: edge-tts voor natuurlijke Russische spraak, ffplay/mpv voor afspelen.
"""
from __future__ import annotations

import argparse
import asyncio
import csv
import copy
from datetime import datetime, time as day_time
import hashlib
import json
import math
import os
from pathlib import Path
import random
import re
import shutil
import signal
import socket
import subprocess
import sys
import threading
import time
import tkinter as tk
from tkinter import font as tkfont
import frequentie

BASE = Path(__file__).resolve().parent
DATA = Path(os.environ.get('XDG_DATA_HOME', Path.home() / '.local/share')) / 'russische-woordflitser'
DATA.mkdir(parents=True, exist_ok=True)
STATE_FILE = DATA / 'progress.json'
EXTRA_FILE = DATA / 'eigen_woorden.json'
EDITS_FILE = DATA / 'woordcorrecties.json'  # persoonlijke teksten, buiten programmamap
PID_FILE = DATA / 'woordflitser.pid'
PAUSE_FILE = DATA / 'pauze_tot.txt'
CONTROL_SOCKET = DATA / 'control.sock'
FREQUENCY_FILE = DATA / 'frequency_ranks.json'
SPEECH_DIR = DATA / 'audio'
SPEECH_DIR.mkdir(exist_ok=True)
AUTOSTART = Path(os.environ.get('XDG_CONFIG_HOME', Path.home() / '.config')) / 'autostart/russische-woordflitser.desktop'
DEFAULT_SETTINGS = {
    'interval_minutes': 5, 'idle_seconds': 12,
    'hide_after_seconds': 9, 'new_word_every': 5,
    'quiet_hours_from': '22:30', 'quiet_hours_until': '08:00',
    'position': 'near-cursor', 'voice': 'ru-RU-SvetlanaNeural',
    'play_audio_automatically': True, 'popup_opacity': 0.85,
    'direction': 'ru-nl', 'selected_themes': None,
}
# Afstanden zijn aantallen *andere getoonde kaarten*, niet minuten/uren.
# Goed n=1 -> 10 andere kaarten, goed n=2 -> 25, enzovoort.
GOOD_RETRY_CARDS = [10, 25, 60, 150, 350, 800, 1800, 4000]
WRONG_RETRY_CARDS = 3
UNRATED_RETRY_CARDS = 4
SCHEDULER_VERSION = 2
# Keuzes in het GTK-systeemvakmenu; inhoud van settings.json blijft leidend.
INTERVAL_CHOICES = (1, 2, 5, 10, 15, 30, 60)
COUNTDOWN_CHOICES = (5, 7, 9, 11, 13, 15)
# Het getal is het totale aantal kaarten per nieuw woord (dus: 1 nieuw,
# (n-1) herhalingen). Minimaal 1 nieuw + 1 herhaling.
NEW_WORD_EVERY_CHOICES = (2, 3, 4, 5, 6, 8, 10, 15, 20)
# Elk woord hoort bij precies één thema. Eigen imports zonder thema vallen onder 'overig'.
THEME_CHOICES = (
    ('mensen', 'Mensen & relaties'), ('thuis', 'Huis & spullen'),
    ('eten', 'Eten & drinken'), ('natuur', 'Natuur & dieren'),
    ('reizen', 'Reizen & vervoer'), ('gezondheid', 'Lichaam & gezondheid'),
    ('werk', 'Werk & leren'), ('kleding', 'Kleding'),
    ('tijd', 'Tijd & getallen'), ('handelingen', 'Werkwoorden & handelingen'),
    ('eigenschappen', 'Eigenschappen'), ('grammatica', 'Kleine woorden & grammatica'),
    ('zinnen', 'Veelgebruikte zinnen'), ('verwarring', 'Verwarringswoorden (NL → RU)'),
    ('overig', 'Eigen / overige woorden'),
)
THEME_IDS = tuple(theme for theme, _ in THEME_CHOICES)
DIRECTIONS = ('ru-nl', 'nl-ru')


def eligible_words(words, settings):
    """Filter de voorraad zonder ooit leerhistorie of woord-ID te wijzigen."""
    selected = settings.get('selected_themes')
    if not isinstance(selected, list):
        selected = list(THEME_IDS)
    return [word for word in words if (
        # Verwarringsvragen zijn zinsgebonden NL→RU-vragen; in RU→NL
        # zouden ze dubbele woorden en ongeschikte prompts opleveren.
        not (word.get('theme') == 'verwarring' and settings.get('direction') != 'nl-ru')
        and any(theme in selected for theme in word.get('themes', [word.get('theme', 'overig')])))]



def normalized_countdown(seconds) -> int:
    """Zet oude afteltijden (<5 of >15 s) om naar een geldige keuze."""
    try:
        value = float(seconds)
        return min(COUNTDOWN_CHOICES, key=lambda choice: (abs(choice-value), choice))
    except (ValueError, TypeError):
        return 9


def reveal_delay_seconds(hide_after_seconds: float) -> float:
    """Toon de betekenis na de kortste van vijf seconden of 1/3 afteltijd."""
    return min(5.0, max(0.0, float(hide_after_seconds) / 3.0))


def countdown_color(elapsed: float, reveal_delay: float) -> str:
    """Groen bij begin, geel halverwege, rood als antwoord verschijnt.

    Na het onthullen blijft de balk volledig rood. De overgang is vloeiend
    en onafhankelijk van de ingestelde totale duur.
    """
    fraction = min(1.0, max(0.0, elapsed / max(0.001, reveal_delay)))
    green, yellow, red = (0x52, 0xa5, 0x6d), (0xf2, 0xc2, 0x3c), (0xd6, 0x40, 0x4c)
    start, end, progress = ((green, yellow, fraction * 2) if fraction <= 0.5
                            else (yellow, red, (fraction - 0.5) * 2))
    rgb = tuple(round(a + (b - a) * progress) for a, b in zip(start, end))
    return '#%02x%02x%02x' % rgb


def load_json(path: Path, fallback):
    try:
        return json.loads(path.read_text(encoding='utf-8'))
    except (OSError, ValueError):
        return fallback


def save_json(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + '.tmp')
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(path)


def plain_russian(text: str) -> str:
    """Remove stress accents, not Cyrillic letters, for TTS and stable word IDs."""
    return text.replace('\u0301', '').strip()


def displayed_russian(word: dict) -> str:
    """Show the infinitive AND I-form on one line, before the translation."""
    if word.get('ik'):
        return f"{word['ru']} — {word['ik']}"
    return word['ru']


def spoken_russian(word: dict) -> str:
    """A short pause separates infinitive and I-form in the natural TTS voice.

    This is deliberately different from the display text: a period makes
    edge-tts pause more reliably than a typographic dash.
    """
    if word.get('ik'):
        return f"{word['ru']}. {word['ik']}"
    return word['ru']


EDITABLE_FIELDS = ('nl', 'context_ru', 'context_nl')


def load_word_edits() -> dict:
    """Eigen vertalingen staan los van de standaardlijst en de leerhistorie."""
    saved = load_json(EDITS_FILE, {})
    if not isinstance(saved, dict):
        return {}
    return {str(k): {field: v for field, v in value.items()
                     if field in EDITABLE_FIELDS and isinstance(v, str)}
            for k, value in saved.items() if isinstance(value, dict)}


def original_word(word: dict) -> dict:
    """De bronkaart voor 'Standaard herstellen' (inclusief eigen imports)."""
    key = word_key(word)
    for source in (EXTRA_FILE, BASE / 'words.json'):
        for candidate in load_json(source, []):
            if isinstance(candidate, dict) and candidate.get('ru') and word_key(candidate) == key:
                return candidate
    return word


def persist_word_edit(word: dict, changes: dict | None) -> dict:
    """Bewerk of herstel tekst zonder Russische ID of beoordelingen te wijzigen.

    None wist persoonlijke overschrijvingen. Oude voortgang, audio en beelden
    zitten in andere bestanden en worden daarom nooit aangeraakt.
    """
    key = word_key(word)
    edits = load_word_edits()
    if changes is None:
        edits.pop(key, None)
        target = original_word(word)
        new_text = {field: target.get(field, '') for field in EDITABLE_FIELDS}
    else:
        if not isinstance(changes, dict) or set(changes) != set(EDITABLE_FIELDS):
            raise ValueError('Alle drie tekstvelden moeten worden opgegeven.')
        new_text = {field: str(changes[field]).strip() for field in EDITABLE_FIELDS}
        if not new_text['nl']:
            raise ValueError('De Nederlandse betekenis mag niet leeg zijn.')
        if bool(new_text['context_ru']) != bool(new_text['context_nl']):
            raise ValueError('Vul beide voorbeeldzinnen in, of maak beide leeg.')
        edits[key] = new_text.copy()
    save_json(EDITS_FILE, edits)
    word.update(new_text)
    return new_text


def all_words():
    normal = load_json(BASE / 'words.json', [])
    custom = load_json(EXTRA_FILE, [])
    if not isinstance(normal, list):
        normal = []
    if not isinstance(custom, list):
        custom = []
    unique = {}
    edits = load_word_edits()
    for word in normal + custom:
        if isinstance(word, dict) and word.get('ru') and word.get('nl'):
            key = word_key(word)
            corrected = dict(word)  # gebundelde woordenlijst niet veranderen
            corrected.update(edits.get(key, {}))
            unique[key] = corrected
    return list(unique.values())


def load_settings():
    data = load_json(BASE / 'settings.json', {})
    settings = {**DEFAULT_SETTINGS, **(data if isinstance(data, dict) else {})}
    # Oudere versies hadden ook 20, 30 of 60 seconden. Gebruik voor die
    # instellingen bij het starten de dichtstbijzijnde keuze van 5 t/m 15 s.
    settings['hide_after_seconds'] = normalized_countdown(settings['hide_after_seconds'])
    if settings.get('direction') not in DIRECTIONS:
        settings['direction'] = 'ru-nl'
    chosen = settings.get('selected_themes')
    if chosen is None:
        settings['selected_themes'] = list(THEME_IDS)
    elif isinstance(chosen, list):
        settings['selected_themes'] = [item for item in THEME_IDS if item in chosen]
    else:
        settings['selected_themes'] = list(THEME_IDS)
    return settings


def is_quiet_now(now: datetime, settings: dict) -> bool:
    try:
        st = day_time.fromisoformat(settings['quiet_hours_from'])
        en = day_time.fromisoformat(settings['quiet_hours_until'])
    except (ValueError, KeyError):
        return False
    t = now.time()
    if st == en:
        return False
    return (st <= t < en) if st < en else (t >= st or t < en)


def is_paused():
    try:
        limit = float(PAUSE_FILE.read_text().strip())
        if limit > time.time():
            return True
        PAUSE_FILE.unlink(missing_ok=True)
    except (OSError, ValueError):
        pass
    return False


def idle_seconds() -> float | None:
    """X11 only. On Wayland or without xprintidle, return None (timed fallback)."""
    if os.environ.get('XDG_SESSION_TYPE') == 'wayland':
        return None  # XWayland idle time is not a reliable measure of native Wayland activity.
    if not os.environ.get('DISPLAY') or not shutil.which('xprintidle'):
        return None
    try:
        r = subprocess.run(['xprintidle'], capture_output=True, text=True, timeout=1)
        if r.returncode == 0:
            return max(0, int(r.stdout.strip()) / 1000)
    except (OSError, ValueError, subprocess.TimeoutExpired):
        pass
    return None


def fullscreen_on_x11() -> bool:
    """Best effort: avoid popping over active fullscreen windows on X11."""
    if not os.environ.get('DISPLAY') or not shutil.which('xprop'):
        return False
    try:
        r = subprocess.run(['xprop', '-root', '_NET_ACTIVE_WINDOW'], capture_output=True,
                           text=True, timeout=1)
        hit = re.search(r'0x[0-9a-fA-F]+', r.stdout)
        if not hit or hit.group() == '0x0':
            return False
        s = subprocess.run(['xprop', '-id', hit.group(), '_NET_WM_STATE'],
                           capture_output=True, text=True, timeout=1)
        return '_NET_WM_STATE_FULLSCREEN' in s.stdout
    except (OSError, subprocess.TimeoutExpired):
        return False



def parse_xrandr_monitors(output: str) -> list[tuple[int, int, int, int]]:
    """Read XRandR's monitor rectangles without adding a Python dependency.

    Expected geometry looks like: 2560/597x1440/336+1920+0.
    The physical size fields (/597, /336) are optional.
    """
    result = []
    pattern = re.compile(r'(?<![\d/])(?P<w>\d+)(?:/\d+)?x(?P<h>\d+)(?:/\d+)?(?P<x>[+-]\d+)(?P<y>[+-]\d+)')
    for line in output.splitlines():
        match = pattern.search(line)
        if match:
            result.append((int(match['x']), int(match['y']), int(match['w']), int(match['h'])))
    return result


def monitor_under_pointer(px: int, py: int, fallback: tuple[int, int, int, int]) -> tuple[int, int, int, int]:
    """Prefer the X11 monitor containing the pointer, not the whole virtual desktop.

    On Wayland we cannot reliably ask another app for all output rectangles,
    so Tk's screen rectangle is used as a best-effort fallback.
    """
    if os.environ.get('XDG_SESSION_TYPE') != 'wayland' and shutil.which('xrandr'):
        try:
            completed = subprocess.run(['xrandr', '--listmonitors'], capture_output=True, text=True, timeout=1)
            if completed.returncode == 0:
                for x, y, w, h in parse_xrandr_monitors(completed.stdout):
                    if x <= px < x+w and y <= py < y+h:
                        return (x, y, w, h)
        except (OSError, subprocess.TimeoutExpired):
            pass
    return fallback


def place_near_cursor(px: int, py: int, width: int, height: int,
                      bounds: tuple[int, int, int, int], gap: int = 42, margin: int = 16) -> tuple[int, int]:
    """Place near, never directly on, the pointer; keep the whole popup on-screen."""
    bx, by, bw, bh = bounds
    min_x, max_x = bx+margin, max(bx+margin, bx+bw-width-margin)
    min_y, max_y = by+margin, max(by+margin, by+bh-height-margin)
    candidates = [(px+gap, py+gap), (px+gap, py-height-gap),
                  (px-width-gap, py+gap), (px-width-gap, py-height-gap)]
    for x, y in candidates:
        if min_x <= x <= max_x and min_y <= y <= max_y:
            return x, y
    # This fallback is only needed for tiny displays or unusual DPI scaling.
    # Prefer the clamped candidate with the biggest distance to the pointer.
    def candidate_score(p):
        x, y = p
        dx = max(x-px, px-(x+width), 0)
        dy = max(y-py, py-(y+height), 0)
        return (dx*dx + dy*dy, -abs(x-px), -abs(y-py))
    clamped = [(min(max(x, min_x), max_x), min(max(y, min_y), max_y)) for x, y in candidates]
    return max(clamped, key=candidate_score)


def word_key(w):
    # Iedere verwarringsoefening heeft een eigen herhaalschema. Zonder extra
    # kaart-ID zou een voorbeeld met 'тот' de normale kaart 'тот' vervangen.
    if w.get('theme') == 'verwarring' and w.get('exercise_id'):
        return 'verwarring:' + str(w['exercise_id'])
    return plain_russian(w['ru']).lower()


def is_confusion_key(key):
    return isinstance(key, str) and key.startswith('verwarring:')


def confusion_prompt(word, direction, choices=None):
    # Meerkeuzetekst uitsluitend op verwarringsoefeningen in NL→RU.
    if direction != 'nl-ru' or word.get('theme') != 'verwarring':
        return word['nl'] if direction == 'nl-ru' else displayed_russian(word)
    options = choices if choices is not None else word.get('choices', [])
    if not isinstance(options, list) or len(options) < 2:
        return word['nl']
    return f"{word['nl'].rstrip(':')}: {' / '.join(options)}"


def empty_direction_progress() -> dict:
    """Elke oefenrichting heeft zelfstandige woord- én kaarttellers."""
    return {
        'words': {}, 'shown_total': 0, 'new_total': 0,
        'cards_since_new': 100000, 'recent_keys': [],
        'new_day': '', 'new_today': 0,
        'scheduler_version': SCHEDULER_VERSION,
    }


def direction_progress(storage: dict, direction: str = 'ru-nl') -> dict:
    """Het oude root-schema blijft RU→NL, zonder bestaande scores te wissen.

    Het nieuwe `nl_ru` is onafhankelijk en wordt bij overstappen gestart.
    Oude ratings bevatten geen informatie over de oefenrichting; ze kunnen
    daarom niet achteraf betrouwbaar worden verdeeld.
    """
    if direction == 'nl-ru':
        reverse = storage.get('nl_ru', {}) if isinstance(storage, dict) else {}
        return reverse if isinstance(reverse, dict) else {}
    return storage if isinstance(storage, dict) else {}


def vocabulary_score(state: dict, direction: str = 'ru-nl') -> int:
    """Count unique words whose *latest* explicit answer is Good.

    A repeated Good never adds another point. Wrong removes one point only if
    that word previously counted. Unrated views/dismissals change no score.
    Existing progress.json entries from earlier versions work unchanged.
    """
    state = direction_progress(state, direction)
    entries = state.get('words', {}) if isinstance(state, dict) else {}
    if not isinstance(entries, dict):
        return 0
    return sum(isinstance(entry, dict) and entry.get('last_result') == 'good'
               and not is_confusion_key(key)
               for key, entry in entries.items())


class Scheduler:
    """Spaced repetition op basis van getoonde kaarten, niet verstreken tijd.

    next_due_other_count is de stand van de teller van *andere* kaarten
    waarbij een woord weer aan de beurt mag komen. Een kaart telt mee zodra
    het scherm verschijnt, ook bij rechtsklikken of doorklikken.

    Wanneer er tijdelijk geen woorden aan de beurt zijn, kan een bekende
    kaart als *extra oefening* eerder verschijnen. Dit is onvermijdelijk met
    kleine woordenlijsten en houdt de teller (en popup) in beweging.
    """
    def __init__(self, words, demo=False, direction='ru-nl'):
        if direction not in DIRECTIONS:
            raise ValueError('Ongeldige oefenrichting')
        self.words = words
        self.frequency_cache = frequentie.load_cache(FREQUENCY_FILE)
        # Ook --demo en --once gebruiken dezelfde opgeslagen leerschema's.
        self.demo = False
        stored = load_json(STATE_FILE, {})
        self._storage = stored if isinstance(stored, dict) else {}
        self.direction = direction
        self._init_progress(self._storage)
        if not isinstance(self._storage.get('nl_ru'), dict):
            self._storage['nl_ru'] = empty_direction_progress()
        self._init_progress(self._storage['nl_ru'])
        self._storage.setdefault('direction_progress_version', 1)
        self.demo_index = 0
        self._save()

    def _init_progress(self, state):
        for name, default in empty_direction_progress().items():
            if name == 'scheduler_version':
                continue
            if name == 'words' and not isinstance(state.get('words'), dict):
                state['words'] = {}
            else:
                state.setdefault(name, copy.deepcopy(default))
        # Eerdere tijdgebaseerde schema's eenmalig omzetten per richting.
        if state.get('scheduler_version', 1) < SCHEDULER_VERSION:
            for entry in state['words'].values():
                if isinstance(entry, dict):
                    entry.setdefault('next_due_other_count', max(
                        0, int(state['shown_total']) - int(entry.get('shown_count', 0))))
            state['scheduler_version'] = SCHEDULER_VERSION

    @property
    def state(self):
        """Actieve leerhistorie: alle bestaande app-code gebruikt deze view."""
        return direction_progress(self._storage, self.direction)

    def _save(self):
        save_json(STATE_FILE, self._storage)

    def set_direction(self, direction):
        if direction not in DIRECTIONS:
            raise ValueError('Ongeldige oefenrichting')
        self.direction = direction

    def introduced(self):
        return sum(word_key(w) in self.state['words'] for w in self.words)

    def vocabulary_score(self, direction=None):
        return vocabulary_score(self._storage, direction or self.direction)

    def choose(self, settings, now=None, exclude=None, manual=False):
        """Choose by due card number; `now` exists for old caller compatibility."""
        candidates = eligible_words(self.words, settings)
        if not candidates:
            return None
        history = self.state['words']
        shown = int(self.state.get('shown_total', 0))
        fresh = [w for w in candidates if word_key(w) not in history]
        known = [w for w in candidates if word_key(w) in history]
        due = [w for w in known if int(history[word_key(w)].get('next_due_other_count', 0)) <=
               shown - int(history[word_key(w)].get('shown_count', 0))]
        if manual and exclude:
            due = [w for w in due if word_key(w) != exclude]
        recent = self.state.get('recent_keys', [])[-3:]
        every = max(2, int(settings.get('new_word_every', 5)))
        new_slot = int(self.state.get('cards_since_new', 100000)) >= every - 1

        def select(options):
            pool = [w for w in options if word_key(w) != exclude] or list(options)
            if not pool:
                return None
            # Voorkom telkens dezelfde alfabetische volgorde na een herstart.
            # Neem bij voorkeur niet een van de laatst getoonde woorden.
            not_recent = [w for w in pool if word_key(w) not in recent]
            if not_recent:
                pool = not_recent
            # Voor nieuwe woorden zijn er nog geen planmomenten.
            if all(word_key(w) not in history for w in pool):
                # Binnen het eerstvolgende corpusvenster willekeurig kiezen:
                # de prioriteit is reproduceerbaar, de volgorde niet mechanisch.
                pool.sort(key=lambda w: frequentie.priority(w, self.frequency_cache))
                best = frequentie.priority(pool[0], self.frequency_cache)[0]
                same_group = [w for w in pool if frequentie.priority(w, self.frequency_cache)[0] == best]
                if best == 0:
                    # Alleen ongeveer even frequente lemmata afwisselen:
                    # nooit een woord van 4 ipm gelijkwaardig behandelen aan 500 ipm.
                    highest = self.frequency_cache['entries'][frequentie.get_lemma(same_group[0])]['ipm']
                    same_group = [w for w in same_group if
                                  self.frequency_cache['entries'][frequentie.get_lemma(w)]['ipm'] >= highest * 0.70]
                return random.choice(same_group[:min(len(same_group), 8)])
            # Voor bekende woorden eerst de langst wachtende kandidaten,
            # maar wissel gelijkwaardige kandidaten willekeurig af.
            pool.sort(key=lambda w: (
                int(history.get(word_key(w), {}).get('next_due_other_count', 0))
                + int(history.get(word_key(w), {}).get('shown_count', 0)),
                history.get(word_key(w), {}).get('last_presented', 0)))
            return random.choice(pool[:min(3, len(pool))])

        # Fout: terug zodra er 3 andere kaarten zijn geweest (met prioriteit).
        urgent = [w for w in due if history[word_key(w)].get('last_result') == 'wrong']
        if urgent:
            return select(urgent)
        if fresh and new_slot:
            # Corpusfrequentie bepaalt de volgende nieuwe kaarten.
            # Veelgebruikte zinnen krijgen apart ruimte: een op zes *nieuwe*
            # kaarten (alleen wanneer het thema is geselecteerd).
            phrases = [w for w in fresh if w.get('theme') == 'zinnen']
            learned_new = int(self.state.get('new_total', 0))
            if phrases and learned_new % 6 == 5:
                return select(phrases)
            lexical = [w for w in fresh if w.get('theme') != 'zinnen']
            return select(lexical or fresh)
        if due:
            return select(due)

        # Opstart: twee basiswoorden om met Volgende af te kunnen wisselen.
        # Als ze allebei goed zijn en nog niet aan de beurt, introduceren
        # we liever een extra nieuw woord dan ze voortijdig te herhalen.
        if fresh and len(known) < min(2, len(candidates)):
            return select(fresh)

        # Onbeoordeelde woorden mogen als opvulling worden geoefend.
        extras = [w for w in known if word_key(w) != exclude]
        unrated = [w for w in extras if history[word_key(w)].get('last_result') in (None, 'exposed')]
        if unrated:
            return select(unrated)
        # Introduceer liever een extra nieuw woord dan een 'Goed'-woord
        # vóór de geplande beurt te herhalen. Alleen wanneer echt alle
        # 30 woorden ingebracht zijn, kan dat nog nodig zijn.
        if extras:
            # Als nog geen herhaling gepland is, oefen dan tijdelijk een
            # eerder gezien woord. Daarmee wordt de gekozen verhouding
            # nieuw/herhaling niet stilzwijgend overschreden. Zo'n extra
            # kaart verlaagt de 'Goed'-termijn niet.
            return select(extras)
        if fresh:
            return select(fresh)
        return None

    def note_shown(self, word, now=None):
        """Persist each displayed card, including dismissed and Next."""
        if not word:
            return
        now = time.time() if now is None else now
        key = word_key(word)
        history = self.state['words']
        fresh = key not in history
        entry = dict(history.get(key, {}))
        self.state['shown_total'] = int(self.state.get('shown_total', 0)) + 1
        if fresh:
            entry['introduced_at'] = now
            self.state['new_total'] += 1
            self.state['cards_since_new'] = 0
        else:
            self.state['cards_since_new'] = int(self.state.get('cards_since_new', 0)) + 1
        entry['shown_count'] = int(entry.get('shown_count', 0)) + 1
        if fresh:
            entry['next_due_other_count'] = (self.state['shown_total'] - entry['shown_count']
                                             + UNRATED_RETRY_CARDS)
        entry['last_presented'] = now
        entry['last_card_number'] = self.state['shown_total']
        history[key] = entry
        self.state['recent_keys'] = (self.state.get('recent_keys', []) + [key])[-8:]
        self._save()

    def record_result(self, word, result: str, now=None):
        """Good/Wrong schedule by shown-card count; dismissal leaves it intact."""
        if result == 'dismissed' or not word:
            return
        if result not in ('good', 'wrong', 'exposed'):
            raise ValueError(f'Onbekend resultaat: {result!r}')
        now = time.time() if now is None else now
        key = word_key(word)
        entry = dict(self.state['words'].get(key, {}))
        old_count = max(0, int(entry.get('count', 0)))
        streak = max(0, int(entry.get('good_streak', 0)))
        other_count = max(0, int(self.state.get('shown_total', 0))
                          - int(entry.get('shown_count', 0)))
        if result == 'good':
            delay = GOOD_RETRY_CARDS[min(streak, len(GOOD_RETRY_CARDS)-1)]
            streak += 1
            entry['successes'] = int(entry.get('successes', 0)) + 1
            entry['next_due_other_count'] = other_count + delay
        elif result == 'wrong':
            streak = 0
            entry['failures'] = int(entry.get('failures', 0)) + 1
            entry['next_due_other_count'] = other_count + WRONG_RETRY_CARDS
        else:
            # Extra oefenen zonder beoordeling mag het oude Goed/Fout-schema
            # niet veranderen of de succesreeks resetten.
            prior_due = int(entry.get('next_due_other_count', other_count))
            if entry.get('last_result') in ('good', 'wrong'):
                # Bij vroeg extra oefenen blijft het geplande moment staan.
                # Was het woord al aan de beurt en werd het niet beoordeeld,
                # probeer dan over vier andere kaarten opnieuw.
                entry['next_due_other_count'] = (prior_due if prior_due > other_count
                                                  else other_count + UNRATED_RETRY_CARDS)
                result = entry['last_result']
            else:
                entry['next_due_other_count'] = max(prior_due, other_count + UNRATED_RETRY_CARDS)
        entry.update({
            'count': old_count + 1, 'good_streak': streak,
            'last_seen': now, 'last_result': result,
        })
        self.state['words'][key] = entry
        self._save()

    def mark_seen(self, word, now=None):
        self.record_result(word, 'exposed', now=now)


def voice_cache_path(ru: str, voice: str) -> Path:
    stable = hashlib.sha256((voice + '|' + plain_russian(ru)).encode('utf-8')).hexdigest()[:22]
    return SPEECH_DIR / (stable + '.mp3')


async def make_voice(ru: str, voice: str, outfile: Path):
    import edge_tts  # optional dependency, installed by prepare-audio.sh
    if outfile.exists() and outfile.stat().st_size > 100:
        return
    outfile.parent.mkdir(parents=True, exist_ok=True)
    tmp = outfile.with_suffix('.tmp.mp3')
    try:
        com = edge_tts.Communicate(plain_russian(ru), voice, rate='-15%')
        await com.save(str(tmp))
        if not tmp.exists() or tmp.stat().st_size < 100:
            raise RuntimeError('Ontvangen audio was leeg')
        tmp.replace(outfile)
    finally:
        tmp.unlink(missing_ok=True)


def audio_path_for_word(word: dict) -> Path | None:
    explicit = word.get('audio')
    if explicit:
        p = Path(explicit).expanduser()
        if not p.is_absolute():
            p = BASE / p
        if p.is_file():
            return p
    return None


def play_audio(path: Path) -> subprocess.Popen | None:
    for name, params in [
        ('ffplay', ['-nodisp', '-autoexit', '-loglevel', 'quiet', '-volume', '75']),
        ('mpv', ['--no-video', '--really-quiet', '--volume=75']),
        ('cvlc', ['--play-and-exit', '--intf', 'dummy']),
    ]:
        program = shutil.which(name)
        if program:
            try:
                return subprocess.Popen([program, *params, str(path)], stdout=subprocess.DEVNULL,
                                        stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL,
                                        start_new_session=True)
            except OSError:
                continue
    return None


class Popup:
    # Iedere kaart heeft exact dezelfde afmetingen en vaste tekstgebieden.
    WIDTH, HEIGHT = 580, 290
    CONTEXT_SHIFT = 0  # Compatibiliteit met oudere tests; geen dynamische hoogte.
    BAR_LEFT, BAR_RIGHT = 20, 438
    BAR_TOP, BAR_BOTTOM = 281, 285

    def __init__(self, root, settings):
        self.root = root
        self.settings = settings
        self._layout_fonts = {}  # Cache Tk fonts; voorkomt haperingen per woord.
        self.active_word = None
        self.file_image = None
        self.flag_image = None
        self.voice_requested = False
        self.audio_process = None  # Huidige MP3: stoppen als de kaart wordt weggeklikt.
        self.audio_failure_hint = None
        self.pending_audio = set()
        self.audio_result_queue = []  # Always initialized before a worker may finish.
        self.audio_poll_id = None
        # Wacht bij automatisch afspelen tot de stem klaar is. Nooit de
        # leer-afteller laten verlopen terwijl een lange zin nog klinkt.
        self.awaiting_initial_audio = False
        self.audio_wait_started_at = None
        self.audio_wait_timer_id = None
        self.on_hidden = None
        self.rated_result = None  # Goed/Fout is gekozen; Volgende kan daarna nog.
        self.vocabulary_count = 0
        self.vocabulary_delta = 0
        self.on_rated = None      # Bij klikken direct duurzaam opslaan.
        self.on_edit = None       # Opslaan persoonlijke vertalingen via Application.
        self.edit_dialog = None

        self.rating_saved = False
        self.position_initialized = False  # Volgende houdt dezelfde schermpositie aan.
        self.context_mode = False
        self.picture_available = False
        self.footer_shift = 0
        self.drag_origin = None  # (muisknop-x/y, oorspronkelijke venster-x/y)
        self.drag_moved = False  # Gewone klik = uitspraak; slepen = geen uitspraak.
        self.hide_deadline = None  # Monotone klok: afteller loopt synchroon met verbergen.
        # Alleen deze kaart, onafhankelijk van de systeemvak-pauze voor popups.
        # Hover pauzeert tijdelijk; klikken vergrendelt de pauze tot hervatten.
        self.pause_hover = False
        self.pause_locked = False
        self.pause_hover_suppressed = False  # Hervat-klik werkt ook als de muis blijft staan.
        self.countdown_paused_at = None
        self.reveal_timer_id = None
        self.card_shown_at = None
        self.countdown_timer_id = None
        self.hide_timer_id = None
        self.revealed = False
        self.direction = 'ru-nl'
        self.reverse_audio_started = False
        self.reverse_audio_done_at = None
        self.reverse_audio_requested_at = None
        self.delayed_hide_timer_id = None
        self.win = tk.Toplevel(root)
        self.win.bind('<Destroy>', self.on_window_destroy, add='+')
        self.win.withdraw()
        self.win.overrideredirect(True)
        try:
            self.win.wm_attributes('-topmost', True)
            self.win.wm_attributes('-type', 'notification')  # X11 hint only
        except tk.TclError:
            pass
        self.win.configure(bg='#eaf0f8')
        self.canvas = tk.Canvas(self.win, width=self.WIDTH, height=self.HEIGHT,
                                highlightthickness=0, bd=0, bg='#eaf0f8')
        self.canvas.pack()
        # Rechtermuisklik op elke plek van de kaart sluit hem, zonder beoordeling.
        self.win.bind('<Button-3>', self.close_current_card)
        self.canvas.bind('<Button-3>', self.close_current_card)
        # Slepen met linkermuisknop op titel, afbeelding, woord of lege ruimte.
        # Bedieningsknoppen blijven normaal werken. Alleen een klik zonder
        # slepen op het woordgedeelte speelt de uitspraak opnieuw af.
        self.canvas.bind('<ButtonPress-1>', self.begin_drag)
        self.canvas.bind('<B1-Motion>', self.drag_motion)
        self.canvas.bind('<ButtonRelease-1>', self.end_drag)
        self.canvas.bind('<Motion>', self.on_pause_motion)
        self.canvas.bind('<Leave>', self.on_pause_leave)
        self.timer_ids = []
        self.redraw_base()

    def rounded(self, x1, y1, x2, y2, r, fill, outline='', tags=(), width=1):
        # Tk's smoothed polygon approximates a rounded panel.
        points = [x1+r,y1, x2-r,y1, x2,y1, x2,y1+r,
                  x2,y2-r, x2,y2, x2-r,y2, x1+r,y2,
                  x1,y2, x1,y2-r, x1,y1+r, x1,y1]
        self.canvas.create_polygon(points, smooth=True, splinesteps=16,
                                   fill=fill, outline=outline, width=width, tags=tags)

    @property
    def current_height(self):
        # Beide soorten kaarten zijn 580 x 290 pixels met een bredere beeldkolom.
        return self.HEIGHT

    def footer_y(self, normal_y):
        # Behoud oudere interne coördinaten voor events en toetsenbordacties.
        return normal_y + 151

    def _fit_text(self, tag, value, width, max_height, start_size, min_size=10,
                  weight='normal'):
        """Maak tekst passend in een afgebakend vak zonder andere vakken te verplaatsen.

        Canvas gebruikt zelf woordafbreking. De grootte wordt verlaagd totdat
        de Tk-bounding-box binnen de gereserveerde hoogte past.
        """
        c = self.canvas
        # Tk geeft geen bounding box voor verborgen Canvas-tekst.
        # Tijdens meten tijdelijk zichtbaar; show() verbergt NL daarna opnieuw.
        c.itemconfigure(tag, state='normal')
        for size in range(start_size, min_size - 1, -1):
            key = (size, weight)
            if key not in self._layout_fonts:
                self._layout_fonts[key] = tkfont.Font(family='DejaVu Sans', size=size, weight=weight)
            c.itemconfigure(tag, text=value, width=width, font=self._layout_fonts[key])
            box = c.bbox(tag)
            if not box or box[3] - box[1] <= max_height:
                return
        # Veiligheidsnet voor extreem lange geïmporteerde Anki-teksten:
        # afkappen is minder ideaal, maar voorkomt dat knoppen overlappen.
        value = str(value)
        while value:
            c.itemconfigure(tag, text=value + '…')
            b = c.bbox(tag)
            if not b or b[3] - b[1] <= max_height:
                break
            value = value[:-1]

    def redraw_base(self):
        c = self.canvas
        c.delete('all')
        self.rounded(3, 4, self.WIDTH - 3, self.HEIGHT - 4, 17, '#f9fbff')
        c.create_text(21, 22, text='RUSSISCH TUSSENDOOR', fill='#64748b',
                      font=('DejaVu Sans', 9, 'bold'), anchor='w')
        score_label = f'Bekend {self.direction.upper().replace("-", "→")}: {self.vocabulary_count}'
        if self.vocabulary_delta:
            score_label += f' ({self.vocabulary_delta:+d})'
        color = '#216a45' if self.vocabulary_delta > 0 else (
            '#9f2e39' if self.vocabulary_delta < 0 else '#53677d')
        c.create_text(286, 22, text=score_label, fill=color,
                      font=('DejaVu Sans', 9, 'bold'), anchor='w', tags=('vocab-score',))
        try:
            self.flag_image = tk.PhotoImage(file=str(BASE / 'images/flag_ru.png'))
            c.create_image(self.WIDTH - 72, 22, image=self.flag_image)
        except tk.TclError:
            c.create_text(self.WIDTH - 64, 22, text='RU', fill='#64748b',
                          font=('DejaVu Sans', 9, 'bold'), anchor='e')
        self.rounded(self.WIDTH - 42, 6, self.WIDTH - 8, 37, 8,
                     '#e1e8f1', tags=('close',))
        c.create_text(self.WIDTH - 25, 21, text='×', fill='#44566e',
                      font=('DejaVu Sans', 18, 'bold'), tags=('close',))
        c.tag_bind('close', '<Button-1>', self.close_current_card)
        c.tag_bind('close', '<Enter>', lambda e: c.configure(cursor='hand2'))
        c.tag_bind('close', '<Leave>', lambda e: c.configure(cursor=''))
        # Potlood naast de vlag: beide oefenrichtingen bewerken dezelfde tekst.
        self.rounded(447, 6, 480, 37, 8, '#e6edf7', tags=('edit-word',))
        c.create_text(463, 21, text='✎', fill='#275a85',
                      font=('DejaVu Sans', 16, 'bold'), tags=('edit-word',))
        c.tag_bind('edit-word', '<Button-1>', self.open_word_editor)
        c.tag_bind('edit-word', '<Enter>', lambda e: c.configure(cursor='hand2'))
        c.tag_bind('edit-word', '<Leave>', lambda e: c.configure(cursor=''))
        c.create_line(20, 43, self.WIDTH - 20, 43, fill='#e5ebf2')

        # Compacte V6.24-indeling: een vaste ruimte voor woord, vertaling,
        # voorbeeld en afbeelding. Beide richtingen gebruiken dezelfde vakken.
        c.create_text(22, 51, text='', anchor='nw', fill='#182439',
                      font=('DejaVu Sans', 19, 'bold'), tags=('russian',))
        c.create_text(22, 87, text='', anchor='nw', fill='#1768a5',
                      font=('DejaVu Sans', 14), tags=('translation',), state='hidden')
        c.create_line(20, 145, self.WIDTH - 20, 145, fill='#e5ebf2')
        if self.context_mode:
            c.create_text(22, 150, text='VOORBEELD', anchor='nw',
                          fill='#718096', font=('DejaVu Sans', 8, 'bold'))
        c.create_text(22, 164, text='', anchor='nw', fill='#24394f',
                      font=('DejaVu Sans', 12, 'bold'), tags=('context-ru',))
        c.create_text(22, 187, text='', anchor='nw', fill='#53677d',
                      font=('DejaVu Sans', 11), tags=('context-nl',), state='hidden')
        # Instructie blijft intern verborgen; de beoordelingsknoppen zijn duidelijk.
        c.create_text(22, 232, text='', anchor='w', fill='#718096',
                      font=('DejaVu Sans', 9), tags=('status',), state='hidden')

        # Zichtbare feedback rechts van VOORBEELD, boven de zinnen.
        c.create_text(560, 155, text='', anchor='e', fill='#216a45',
                      font=('DejaVu Sans', 9, 'bold'), tags=('rating-feedback',),
                      state='hidden')

        # Het afbeeldingsvak gebruikt de beschikbare hoogte naast het woord.
        if getattr(self, 'picture_available', False):
            self.rounded(406, 46, 560, 228, 12, '#e7f0fb', tags=('image-panel',))
            c.create_text(483, 137, text='?', fill='#aec0d3',
                          font=('DejaVu Sans', 34), tags=('placeholder', 'image-panel'))

        # 36px hoge knoppen (+29%): groot genoeg om snel te raken.
        self.rounded(20, 243, 185, 279, 8, '#fde8e9', tags=('rating', 'wrong', 'wrong-bg'))
        c.create_text(102, 261, text='✗  Fout', fill='#9f2e39',
                      font=('DejaVu Sans', 11, 'bold'), tags=('rating', 'wrong', 'wrong-label'))
        self.rounded(195, 243, 360, 279, 8, '#e2f3e8', tags=('rating', 'good', 'good-bg'))
        c.create_text(278, 261, text='✓  Goed', fill='#216a45',
                      font=('DejaVu Sans', 11, 'bold'), tags=('rating', 'good', 'good-label'))
        # Geen grotere popup: plaats Pauzeer naast Toon antwoord op dezelfde rij.
        self.rounded(20, 243, 199, 279, 8, '#dceaf9', tags=('know',))
        c.create_text(109, 261, text='Toon antwoord', fill='#1c558c',
                      font=('DejaVu Sans', 11, 'bold'), tags=('know',))
        self.rounded(207, 243, 360, 279, 8, '#e9ecf5', tags=('pause', 'pause-bg'))
        c.create_text(283, 261, text='Pauzeer', fill='#435a78',
                      font=('DejaVu Sans', 11, 'bold'), tags=('pause', 'pause-label'))
        c.tag_bind('pause', '<Button-1>', self.toggle_countdown_pause)
        self.rounded(405, 243, 560, 279, 8, '#dceaf9', tags=('next',))
        c.create_text(483, 261, text='Volgende →', fill='#1c558c',
                      font=('DejaVu Sans', 11, 'bold'), tags=('next',))
        for tag, action in [('know', self.mark_known), ('next', self.next_card),
                            ('wrong', self.mark_wrong), ('good', self.mark_good)]:
            c.tag_bind(tag, '<Button-1>', action)
            c.tag_bind(tag, '<Enter>', lambda e: c.configure(cursor='hand2'))
            c.tag_bind(tag, '<Leave>', lambda e: c.configure(cursor=''))
        c.itemconfigure('rating', state='hidden')
        # Eén doorlopende 4px-balk in het bestaande 580x290 kaartformaat.
        # De gekleurde breedte krimpt vanaf 100% (start) via 66,7%
        # (antwoord bij 1/3 van de tijd) tot 0% (kaart verdwijnt).
        # Groen → geel → rood gebeurt tijdens de eerste fase.
        c.create_rectangle(self.BAR_LEFT, self.BAR_TOP, self.BAR_RIGHT,
                           self.BAR_BOTTOM, fill='#e2e8f0', outline='',
                           tags=('countdown-track',))
        c.create_rectangle(self.BAR_LEFT, self.BAR_TOP, self.BAR_RIGHT,
                           self.BAR_BOTTOM, fill='#52a56d', outline='',
                           tags=('countdown-fill',))
        # Korte tijdtekst naast VOORBEELD, vóór de beeldkolom (x=406).
        # Alleen zichtbaar tot het antwoord wordt getoond.
        c.create_text(395, 155, text='', anchor='e', fill='#5c6777',
                      font=('DejaVu Sans', 9), tags=('countdown-label',))

    def show_rating_selection(self, result):
        """Markeer de laatst gekozen knop; houd de andere keuze beschikbaar."""
        c = self.canvas
        selected = result == 'good'
        c.itemconfigure('good-bg', fill='#238451' if selected else '#e2f3e8',
                        outline='#14603a' if selected else '', width=2 if selected else 1)
        c.itemconfigure('good-label', fill='#ffffff' if selected else '#216a45')
        c.itemconfigure('wrong-bg', fill='#c34251' if not selected else '#fde8e9',
                        outline='#8e2532' if not selected else '', width=2 if not selected else 1)
        c.itemconfigure('wrong-label', fill='#ffffff' if not selected else '#9f2e39')
        c.itemconfigure('rating-feedback',
                        text='✓ Goed opgeslagen' if selected else '✗ Fout opgeslagen',
                        fill='#216a45' if selected else '#9f2e39', state='normal')

    def set_vocabulary_score(self, count: int, delta: int = 0):
        """Refresh score immediately after Good/Wrong without rebuilding popup."""
        self.vocabulary_count = max(0, count)
        self.vocabulary_delta = delta
        if not self.canvas.find_withtag('vocab-score'):
            return
        label = f'Bekend {self.direction.upper().replace("-", "→")}: {self.vocabulary_count}'
        if delta:
            label += f' ({delta:+d})'
        color = '#216a45' if delta > 0 else (
            '#9f2e39' if delta < 0 else '#53677d')
        self.canvas.itemconfigure('vocab-score', text=label, fill=color)

    def begin_drag(self, event):
        """Onthoud muis- en vensterpositie voor sleepbewegingen.

        Een knopdruk op ×, Goed, Fout of Volgende mag nooit een drag starten.
        De knoppen hebben daarnaast eigen Canvas-events die met 'break'
        stoppen. Deze coördinaatcheck is een extra beveiliging.
        """
        self.drag_origin = None
        self.drag_moved = False
        if not self.active_word or event.y >= 241 or (event.y < 42 and event.x >= 442):
            return
        self.drag_origin = (event.x_root, event.y_root,
                            self.win.winfo_x(), self.win.winfo_y())

    def drag_motion(self, event):
        """Verplaats de bestaande popup; volgende kaarten houden deze plek."""
        if self.drag_origin is None or not self.active_word:
            return
        start_x, start_y, window_x, window_y = self.drag_origin
        dx, dy = event.x_root - start_x, event.y_root - start_y
        # Een kleine handtrilling geldt nog als een gewone audioklik.
        if not self.drag_moved and abs(dx) < 5 and abs(dy) < 5:
            return
        self.drag_moved = True
        self.win.geometry(f'{self.WIDTH}x{self.current_height}{window_x + dx:+d}{window_y + dy:+d}')
        self.position_initialized = True

    def end_drag(self, event):
        """Een echte klik speelt geluid af; verslepen nooit."""
        was_pressed = self.drag_origin is not None
        was_dragged = self.drag_moved
        self.drag_origin = None
        self.drag_moved = False
        if was_pressed and not was_dragged:
            self.click_audio(event)

    def open_word_editor(self, event=None):
        """Verberg de kaart tijdelijk voor de editor; bewaar score en leerstand."""
        if not self.active_word or self.edit_dialog is not None:
            return 'break'
        self.cancel_timers()
        self.voice_requested = False
        self.stop_audio()
        self.canvas.itemconfigure('countdown-label', text='Tekst bewerken')
        self.canvas.coords('countdown-fill', self.BAR_LEFT, self.BAR_TOP,
                           self.BAR_LEFT, self.BAR_BOTTOM)
        # Dit is een EIGEN venster, niet een transient van de (deels transparante,
        # undecorated) woordkaart. Sommige Linux-windowmanagers laten anders de
        # transparantie/vensterstijl van de kaart doorwerken in het bewerkvenster.
        dlg = tk.Toplevel(self.root)
        self.edit_dialog = dlg
        dlg.title('Woordkaart aanpassen')
        dlg.configure(bg='#f9fbff')
        dlg.resizable(False, False)
        try:
            dlg.wm_attributes('-alpha', 1.0)  # Bewerkvenster altijd ondoorzichtig.
            dlg.wm_attributes('-topmost', True)
            dlg.wm_attributes('-type', 'normal')  # Gewone titelbalk op X11.
        except tk.TclError:
            pass
        frame = tk.Frame(dlg, bg='#f9fbff', padx=20, pady=15)
        frame.pack()

        tk.Label(frame, text='Russisch: ' + displayed_russian(self.active_word),
                 bg='#f9fbff', fg='#182439', font=('DejaVu Sans', 12, 'bold'),
                 wraplength=440).pack(anchor='w', pady=(0, 10))
        inputs = {}
        def add_field(label, field, lines=1):
            tk.Label(frame, text=label, bg='#f9fbff', fg='#475569',
                     font=('DejaVu Sans', 10, 'bold')).pack(anchor='w', pady=(8, 3))
            if lines == 1:
                entry = tk.Entry(frame, width=49, font=('DejaVu Sans', 11))
                entry.insert(0, self.active_word.get(field, ''))
            else:
                entry = tk.Text(frame, width=49, height=lines, font=('DejaVu Sans', 10),
                                wrap='word', undo=True)
                entry.insert('1.0', self.active_word.get(field, ''))
            entry.pack(fill='x')
            inputs[field] = entry
            return entry
        first = add_field('Nederlandse betekenis', 'nl')
        add_field('Russische voorbeeldzin', 'context_ru', 2)
        add_field('Nederlandse voorbeeldzin', 'context_nl', 2)
        tk.Label(frame, text='Je correcties blijven bewaard na een update.\n'
                             'De Russische woordvorm blijft vast voor je leerhistorie.',
                 bg='#f9fbff', fg='#64748b', justify='left',
                 font=('DejaVu Sans', 9)).pack(anchor='w', pady=(12, 6))

        def finish():
            self.edit_dialog = None
            try:
                dlg.grab_release()
            except tk.TclError:
                pass
            dlg.destroy()
            if self.active_word:
                # Herstel uitsluitend de kaart die vóór het openen zichtbaar
                # was. Geometrie, woord, score, beoordeling en timerstand
                # blijven ongewijzigd; de oorspronkelijke alpha blijft staan.
                if card_was_visible:
                    self.win.deiconify()
                    try:
                        self.win.wm_attributes('-alpha', card_alpha)
                        self.win.wm_attributes('-topmost', True)
                    except tk.TclError:
                        pass
                    self.win.lift()
                self._resume_after_edit()

        def save():
            from tkinter import messagebox
            values = {field: (widget.get() if isinstance(widget, tk.Entry)
                              else widget.get('1.0', 'end-1c'))
                      for field, widget in inputs.items()}
            try:
                if callable(self.on_edit):
                    self.on_edit(self.active_word, values)
                else:
                    persist_word_edit(self.active_word, values)
            except (OSError, ValueError) as exc:
                messagebox.showerror('Kan tekst niet opslaan', str(exc), parent=dlg)
                return
            self.refresh_card_text()
            finish()

        def restore():
            from tkinter import messagebox
            if not messagebox.askyesno('Standaard herstellen',
                    'Eigen vertaling en voorbeelden voor dit woord verwijderen?', parent=dlg):
                return
            try:
                if callable(self.on_edit):
                    self.on_edit(self.active_word, None)
                else:
                    persist_word_edit(self.active_word, None)
            except (OSError, ValueError) as exc:
                messagebox.showerror('Herstellen mislukt', str(exc), parent=dlg)
                return
            self.refresh_card_text()
            finish()

        row = tk.Frame(frame, bg='#f9fbff')
        row.pack(fill='x', pady=(12, 0))
        tk.Button(row, text='Standaard herstellen', command=restore).pack(side='left')
        tk.Button(row, text='Annuleren', command=finish).pack(side='right', padx=(8, 0))
        tk.Button(row, text='Opslaan', command=save, bg='#dceaf9').pack(side='right')
        dlg.protocol('WM_DELETE_WINDOW', finish)
        dlg.bind('<Escape>', lambda e: finish())
        dlg.update_idletasks()
        x = max(0, self.win.winfo_rootx() + (self.WIDTH - dlg.winfo_width()) // 2)
        y = max(0, self.win.winfo_rooty() + 30)
        dlg.geometry(f'+{x}+{y}')
        # De kaart is een X11 'notification'-venster en kan bovenop een
        # normale editor blijven liggen, zelfs als BEIDE '-topmost' hebben.
        # Dit maakte de editor op het overlappende gebied *schijnbaar*
        # transparant. Haal de kaart daarom tijdens het bewerken uit de
        # vensterstapel. Bewaar zichtbaarheid en transparantie voor herstel.
        card_was_visible = bool(self.win.winfo_viewable())
        try:
            card_alpha = float(self.win.wm_attributes('-alpha'))
        except (tk.TclError, ValueError, TypeError):
            card_alpha = float(self.settings.get('popup_opacity', 0.85))
        self.win.withdraw()
        dlg.lift()
        # Sommige windowmanagers passen -alpha pas na tonen toe.
        # Dit raakt uitsluitend dit venster, niet de transparante woordkaart.
        try:
            dlg.wm_attributes('-alpha', 1.0)
        except tk.TclError:
            pass
        dlg.grab_set()
        first.focus_set()
        first.selection_range(0, 'end')
        return 'break'

    def refresh_card_text(self):
        """Bijgewerkte vertaling tonen zonder beoordelen/woordwisseling."""
        word = self.active_word
        if not word:
            return
        reverse = self.direction == 'nl-ru'
        prompt = confusion_prompt(word, self.direction, getattr(self, 'card_choices', None))
        answer = displayed_russian(word) if reverse else word['nl']
        self._fit_text('russian', prompt, 360, 51, 19, 10, 'bold')
        b = self.canvas.bbox('russian')
        answer_y = min(106, max(82, (b[3] + 3) if b else 85))
        self.canvas.coords('translation', 22, answer_y)
        self._fit_text('translation', answer, 360, max(18, 141-answer_y), 14, 9)
        self.canvas.itemconfigure('translation', state='normal' if self.revealed else 'hidden')
        if self.context_mode:
            self._fit_text('context-ru', word.get('context_nl','') if reverse
                           else word.get('context_ru',''), 360, 42, 12, 8, 'bold')
            b = self.canvas.bbox('context-ru')
            nl_y = min(208, max(184, (b[3] + 2) if b else 187))
            self.canvas.coords('context-nl', 22, nl_y)
            self._fit_text('context-nl', word.get('context_ru','') if reverse
                           else word.get('context_nl',''), 360, max(22, 232-nl_y), 11, 8)
            self.canvas.itemconfigure('context-nl', state='normal' if self.revealed else 'hidden')

    def _resume_after_edit(self):
        """Na het aanpassen krijgt een onbeoordeelde kaart opnieuw leertijd."""
        if not self.active_word:
            return
        if self.rated_result:
            self.canvas.itemconfigure('countdown-label', text='')
        elif self.revealed:
            # Betekenis staat al in beeld; laat hem open voor een oordeel.
            self.canvas.itemconfigure('countdown-label', text='')
        else:
            self.begin_card_countdown()

    def reposition(self):
        sw = self.root.winfo_screenwidth()
        sh = self.root.winfo_screenheight()
        pos = self.settings.get('position', 'near-cursor')
        if pos in ('near-cursor', 'cursor'):
            try:
                px, py = self.root.winfo_pointerxy()
                if px < 0 or py < 0:
                    raise ValueError('Mouse pointer not available')
                bounds = monitor_under_pointer(px, py, (0, 0, sw, sh))
                x, y = place_near_cursor(px, py, self.WIDTH, self.current_height, bounds)
            except (tk.TclError, ValueError):
                x, y = max(0, sw-self.WIDTH-24), max(0, sh-self.HEIGHT-65)
        else:
            x = 24 if pos.endswith('left') else max(0, sw-self.WIDTH-24)
            y = 48 if pos.startswith('top') else max(0, sh-self.HEIGHT-65)
        self.win.geometry(f'{self.WIDTH}x{self.current_height}{x:+d}{y:+d}')
        self.position_initialized = True

    def show(self, word, on_hidden=None, preserve_position=False):
        self.cancel_timers()
        self.voice_requested = False
        self.stop_audio()
        self.drag_origin = None
        self.drag_moved = False
        self.pause_hover = False
        self.pause_locked = False
        self.pause_hover_suppressed = False
        self.countdown_paused_at = None
        self.active_word = word
        self.on_hidden = on_hidden
        self.rated_result = None
        self.rating_saved = False
        self.voice_requested = False
        self.audio_failure_hint = None
        self.file_image = None
        self.revealed = False
        self.direction = self.settings.get('direction', 'ru-nl')
        self.reverse_audio_started = False
        self.reverse_audio_done_at = None
        self.reverse_audio_requested_at = None
        self.vocabulary_delta = 0
        self.context_mode = bool(word.get('context_ru') and word.get('context_nl'))
        self.card_choices = None
        if self.direction == 'nl-ru' and word.get('theme') == 'verwarring':
            options = word.get('choices')
            if isinstance(options, list) and len(options) >= 2:
                self.card_choices = list(options)
                random.shuffle(self.card_choices)
        self.footer_shift = 0
        picture_path = word.get('image')
        self.picture_available = False
        if picture_path:
            candidate = Path(picture_path)
            if not candidate.is_absolute():
                candidate = BASE / candidate
            self.picture_available = candidate.is_file()
        self.canvas.configure(width=self.WIDTH, height=self.HEIGHT)
        self.redraw_base()
        # Altijd dezelfde x/y-positie. Lettergrootte past zich binnen het vak aan.
        # Naast het woord blijft een brede beeldkolom vrij die woord- en voorbeeldblok bestrijkt.
        reverse = self.direction == 'nl-ru'
        prompt = confusion_prompt(word, self.direction, getattr(self, 'card_choices', None))
        answer = displayed_russian(word) if reverse else word['nl']
        self._fit_text('russian', prompt, 360, 51, 19, 10, 'bold')
        # Zet NL net onder de werkelijke hoogte van het hoofdwoord. Daardoor
        # ontstaat bij korte woorden minder lege ruimte, zonder bij langere
        # (bijv. infinitief + ik-vorm) over tekst heen te tekenen.
        ru_bounds = self.canvas.bbox('russian')
        answer_y = min(106, max(82, (ru_bounds[3] + 3) if ru_bounds else 85))
        self.canvas.coords('translation', 22, answer_y)
        self._fit_text('translation', answer, 360, max(18, 141 - answer_y), 14, 9)
        self.canvas.itemconfigure('translation', text='', state='hidden')
        if self.context_mode:
            self._fit_text('context-ru', word['context_nl'] if reverse else word['context_ru'],
                           360, 42, 12, 8, 'bold')
            ru_context_bounds = self.canvas.bbox('context-ru')
            nl_y = min(208, max(184, (ru_context_bounds[3] + 2)
                                     if ru_context_bounds else 187))
            self.canvas.coords('context-nl', 22, nl_y)
            self._fit_text('context-nl', word['context_ru'] if reverse else word['context_nl'],
                           360, max(22, 232 - nl_y), 11, 8)
            self.canvas.itemconfigure('context-nl', text='', state='hidden')
        self.canvas.itemconfigure('status', text=('Russisch antwoord verschijnt vanzelf…' if reverse else 'Betekenis verschijnt vanzelf…'))
        # Alleen Volgende gebruikt de bestaande positie, ook als de cursor
        # ondertussen naar de antwoordknoppen bewogen is.
        if preserve_position and self.position_initialized:
            # Zowel hoogte als positie blijven exact behouden bij Volgende.
            x, y = self.win.winfo_x(), self.win.winfo_y()
            self.win.geometry(f'{self.WIDTH}x{self.current_height}{x:+d}{y:+d}')
        else:
            self.reposition()
        self.win.deiconify()
        try:
            self.win.wm_attributes('-topmost', True)
            # Op Linux werkt alpha bij sommige vensterbeheerders pas na deiconify().
            opacity = min(1.0, max(0.2, float(self.settings.get('popup_opacity', 0.85))))
            self.win.wm_attributes('-alpha', opacity)
        except (tk.TclError, TypeError, ValueError):
            pass
        # De popup is zichtbaar, maar het leren begint pas NA de uitspraak.
        # Ook het moment waarop de Nederlandse betekenis verschijnt schuift mee.
        if self.settings.get('play_audio_automatically', True) and self.direction == 'ru-nl':
            self.awaiting_initial_audio = True
            self.audio_wait_started_at = time.monotonic()
            self.canvas.itemconfigure('countdown-label', text='Luisteren…')
            self.canvas.itemconfigure('countdown-fill', fill='#52a56d')
            self.canvas.coords('countdown-fill', self.BAR_LEFT, self.BAR_TOP, self.BAR_RIGHT, self.BAR_BOTTOM)
            if not self.play_cached_voice(word):
                # Als de MP3 wel bestaat maar geen speler werkt, wacht niet
                # 20 seconden op een uitspraak die niet kan starten.
                cached = audio_path_for_word(word) or voice_cache_path(
                    spoken_russian(word), str(self.settings['voice']))
                if cached.is_file():
                    self.begin_card_countdown()
                else:
                    self.voice_requested = True
                    self.canvas.itemconfigure('status', text='Uitspraak wordt klaargemaakt…')
                    self.ensure_audio(word, play_when_ready=True)
            self.poll_initial_audio()
        else:
            # Zonder automatische spraak begint de afteller direct.
            self.begin_card_countdown()
            self.ensure_audio(word, play_when_ready=False)

    def begin_card_countdown(self):
        """Start de volledige leertijd pas als de eerste audio afgelopen is."""
        self.awaiting_initial_audio = False
        self.audio_wait_started_at = None
        if self.audio_wait_timer_id is not None:
            try:
                self.root.after_cancel(self.audio_wait_timer_id)
            except tk.TclError:
                pass
            self.audio_wait_timer_id = None
        if not self.active_word or self.rated_result or self.revealed:
            return
        self.card_shown_at = time.monotonic()
        seconds = max(0.1, float(self.settings['hide_after_seconds']))
        self.hide_deadline = self.card_shown_at + seconds
        if self._pause_requested():
            # De muis kan al boven de knop staan terwijl TTS nog bezig is.
            self._suspend_countdown()
        else:
            self.schedule_reveal()
            self._schedule_hide()
            self.update_countdown()
        self.canvas.itemconfigure('status', text=('Russisch antwoord verschijnt vanzelf…' if self.direction == 'nl-ru' else 'Betekenis verschijnt vanzelf…'))

    def poll_initial_audio(self):
        """Niet-blokkerend wachten: controleer of ffplay/mpv/cvlc is afgerond.

        Als een online spraakaanvraag mislukt of blijft hangen, start na
        maximaal 20 seconden toch de oefening, zonder late autoplay.
        Een al spelend audiobestand mag wel zijn volledige duur afmaken.
        """
        self.audio_wait_timer_id = None
        if not self.active_word or not self.awaiting_initial_audio:
            return
        proc = self.audio_process
        if proc is not None:
            try:
                ended = proc.poll() is not None
            except OSError:
                ended = True
            if ended:
                code = proc.poll()
                self.audio_process = None
                if code not in (0, None):
                    self.audio_failure_hint = 'Geen geluid'
                self.begin_card_countdown()
                return
        elif not self.voice_requested:
            self.begin_card_countdown()
            return
        elif self.audio_wait_started_at is not None and (
                time.monotonic() - self.audio_wait_started_at >= 20.0):
            self.voice_requested = False  # Een late MP3 mag de oefening niet onderbreken.
            self.audio_failure_hint = 'Audio te laat'
            self.begin_card_countdown()
            return
        self.audio_wait_timer_id = self.root.after(120, self.poll_initial_audio)

    def _pause_requested(self):
        return self.pause_locked or (self.pause_hover and not self.pause_hover_suppressed)

    def _refresh_pause_button(self):
        # Shutdown() can be called from <Destroy> after Tk has already deleted
        # the canvas command. In that case there is nothing left to repaint.
        try:
            if not self.canvas.find_withtag('pause-label'):
                return
            active = self._pause_requested()
            self.canvas.itemconfigure('pause-label', text='Hervat' if self.pause_locked else 'Pauzeer',
                                      fill='#ffffff' if active else '#435a78')
            self.canvas.itemconfigure('pause-bg', fill='#486b94' if active else '#e9ecf5')
            self.canvas.configure(cursor='hand2' if self.pause_hover else '')
        except tk.TclError:
            return

    def on_pause_motion(self, event):
        """Hover onderbreekt de kaarttimer, zonder muisklik of nieuw venster."""
        hovering = bool(self.active_word and not self.revealed
                        and 207 <= event.x <= 360 and 243 <= event.y <= 279)
        if hovering != self.pause_hover:
            self.pause_hover = hovering
            self.pause_hover_suppressed = False
            self._sync_countdown_pause()

    def on_pause_leave(self, event=None):
        if self.pause_hover:
            self.pause_hover = False
            self.pause_hover_suppressed = False
            self._sync_countdown_pause()

    def toggle_countdown_pause(self, event=None):
        """Klik vergrendelt de pauze; opnieuw klikken hervat meteen."""
        if not self.active_word or self.revealed:
            return 'break'
        self.pause_locked = not self.pause_locked
        self.pause_hover_suppressed = not self.pause_locked
        self._sync_countdown_pause()
        return 'break'

    def _cancel_one_timer(self, ident):
        if ident is None:
            return
        try:
            self.root.after_cancel(ident)
        except tk.TclError:
            pass
        if ident in self.timer_ids:
            self.timer_ids.remove(ident)

    def _stop_card_clock(self):
        """Zet alle klokkaalarmen stil zonder de resterende tijd te wissen."""
        self._cancel_one_timer(self.reveal_timer_id)
        self._cancel_one_timer(self.hide_timer_id)
        self._cancel_one_timer(self.countdown_timer_id)
        self.reveal_timer_id = None
        self.hide_timer_id = None
        self.countdown_timer_id = None

    def _suspend_countdown(self):
        if self.hide_deadline is None or self.countdown_paused_at is not None:
            return
        self.countdown_paused_at = time.monotonic()
        self._stop_card_clock()
        self.update_countdown()

    def _schedule_hide(self):
        if self.hide_deadline is None or self.countdown_paused_at is not None:
            return
        milliseconds = max(0, math.ceil((self.hide_deadline - time.monotonic()) * 1000))
        self.hide_timer_id = self.root.after(milliseconds, self.hide)
        self.timer_ids.append(self.hide_timer_id)

    def _sync_countdown_pause(self):
        self._refresh_pause_button()
        if self.hide_deadline is None:
            # In de audiofase begint de klok pas na de uitspraak.
            return
        if self._pause_requested():
            self._suspend_countdown()
        elif self.countdown_paused_at is not None:
            paused_for = time.monotonic() - self.countdown_paused_at
            self.countdown_paused_at = None
            self.hide_deadline += paused_for
            if self.card_shown_at is not None:
                self.card_shown_at += paused_for
            self.schedule_reveal()
            self._schedule_hide()
            self.update_countdown()

    def schedule_reveal(self):
        """De onthulvertraging volgt altijd de actuele totale afteltijd.

        Bij wijzigen van de afteltijd tijdens een kaart wordt gerekend vanaf
        het moment waarop die kaart getoond werd. Bij 'Toon antwoord' verschijnt
        de betekenis direct, zonder de score of historie te wijzigen.
        """
        if self.reveal_timer_id is not None:
            try:
                self.root.after_cancel(self.reveal_timer_id)
            except tk.TclError:
                pass
            if self.reveal_timer_id in self.timer_ids:
                self.timer_ids.remove(self.reveal_timer_id)
            self.reveal_timer_id = None
        if (not self.active_word or self.revealed or self.card_shown_at is None
                or self.countdown_paused_at is not None):
            return
        target = self.card_shown_at + reveal_delay_seconds(
            self.settings['hide_after_seconds'])
        remaining_ms = max(0, math.ceil((target - time.monotonic()) * 1000))
        self.reveal_timer_id = self.root.after(remaining_ms, self.reveal)
        self.timer_ids.append(self.reveal_timer_id)

    def update_countdown(self):
        """Laat de gekleurde balk gedurende de héle kaartsessie leeg lopen.

        De kleur gaat alleen vóór de onthulling van groen via geel naar rood.
        Vanaf de onthulling blijft de balk rood, tot hij op 0 s leeg is.
        Tekst toont uitsluitend seconden tot antwoord; daarna blijft hij leeg.
        Hoveren of vergrendeld pauzeren bevriest breedte, kleur én tekst.
        """
        if self.hide_deadline is None or not self.active_word:
            return
        duration = max(0.1, float(self.settings['hide_after_seconds']))
        reveal_delay = reveal_delay_seconds(duration)
        reference = (self.countdown_paused_at if self.countdown_paused_at is not None
                     else time.monotonic())
        remaining = min(duration, max(0.0, self.hide_deadline - reference))
        elapsed = max(0.0, duration - remaining)
        if not self.revealed:
            until_answer = max(0.0, reveal_delay - elapsed)
            answer_seconds = math.ceil(until_answer)
            label = f'Antwoord over {answer_seconds} s'
            color = countdown_color(elapsed, reveal_delay)
        else:
            # Na tonen van het antwoord blijft alleen de krimpende rode balk staan.
            label = ''
            color = '#d6404c'
        self.canvas.itemconfigure('countdown-fill', fill=color)
        self.canvas.itemconfigure('countdown-label', text=label)
        self.canvas.coords('countdown-fill', self.BAR_LEFT, self.BAR_TOP,
                           self.BAR_LEFT + (self.BAR_RIGHT - self.BAR_LEFT)
                           * (remaining / duration), self.BAR_BOTTOM)
        if self.countdown_paused_at is None:
            self.countdown_timer_id = self.root.after(150, self.update_countdown)
        else:
            self.countdown_timer_id = None

    def cancel_auto_close(self):
        """Stop de sluitingsafteller, maar laat een geplande onthulling intact."""
        self.hide_deadline = None
        if self.hide_timer_id is not None:
            try:
                self.root.after_cancel(self.hide_timer_id)
            except tk.TclError:
                pass
            if self.hide_timer_id in self.timer_ids:
                self.timer_ids.remove(self.hide_timer_id)
            self.hide_timer_id = None
        if self.countdown_timer_id is not None:
            try:
                self.root.after_cancel(self.countdown_timer_id)
            except tk.TclError:
                pass
            self.countdown_timer_id = None
        self.canvas.itemconfigure('countdown-label', text='')
        self.canvas.itemconfigure('countdown-track', fill='#e2e8f0')
        self.canvas.coords('countdown-fill', self.BAR_LEFT, self.BAR_TOP, self.BAR_LEFT, self.BAR_BOTTOM)

    def set_countdown_seconds(self, seconds):
        """Direct geldig: lopende onbeoordeelde kaart krijgt nieuwe aftelling."""
        self.settings['hide_after_seconds'] = seconds
        if not self.active_word:
            return
        # Na 'Toon antwoord' is de kaart onthuld maar nog NIET beoordeeld.
        # Laat de gebruiker rustig Goed/Fout kiezen, ook bij wijziging van de
        # afteltijd via het systeemvakmenu.
        if self.rated_result or self.hide_deadline is None:
            # Tijdens het luisteren geldt de nieuwe instelling zodra de audio
            # stopt, zonder alvast met aftellen te beginnen.
            return
        self._stop_card_clock()
        now = time.monotonic()
        self.card_shown_at = now
        self.hide_deadline = now + seconds
        if self._pause_requested():
            self.countdown_paused_at = now
        else:
            self.countdown_paused_at = None
            self.schedule_reveal()
            self._schedule_hide()
        self.update_countdown()

    def cancel_timers(self):
        self.pause_hover = False
        self.pause_locked = False
        self.pause_hover_suppressed = False
        self.countdown_paused_at = None
        self._refresh_pause_button()
        self.awaiting_initial_audio = False
        self.audio_wait_started_at = None
        if self.audio_wait_timer_id is not None:
            try:
                self.root.after_cancel(self.audio_wait_timer_id)
            except tk.TclError:
                pass
            self.audio_wait_timer_id = None
        self.hide_deadline = None
        self.reveal_timer_id = None
        self.card_shown_at = None
        if self.countdown_timer_id is not None:
            try:
                self.root.after_cancel(self.countdown_timer_id)
            except tk.TclError:
                pass
            self.countdown_timer_id = None
        if self.delayed_hide_timer_id is not None:
            try:
                self.root.after_cancel(self.delayed_hide_timer_id)
            except tk.TclError:
                pass
            self.delayed_hide_timer_id = None
        for ident in self.timer_ids:
            try:
                self.root.after_cancel(ident)
            except tk.TclError:
                pass
        self.timer_ids = []
        self.hide_timer_id = None

    def reveal(self):
        word = self.active_word
        if not word or self.revealed or self.countdown_paused_at is not None:
            return
        self.revealed = True
        self.pause_hover = False
        self.pause_locked = False
        self.pause_hover_suppressed = False
        self.canvas.itemconfigure('pause', state='hidden')
        self.reveal_timer_id = None
        # Op het automatische onthulmoment: bij 9 s totaal blijft exact
        # 6/9 van de rode balk over. Bij handmatige onthulling zonder
        # sluitdeadline is de balk leeg en verdwijnt de afteltekst.
        self.canvas.itemconfigure('countdown-fill', fill='#d6404c')
        if self.hide_deadline is not None:
            duration = max(0.1, float(self.settings['hide_after_seconds']))
            remaining = min(duration, max(0.0, self.hide_deadline - time.monotonic()))
            self.canvas.coords('countdown-fill', self.BAR_LEFT, self.BAR_TOP,
                               self.BAR_LEFT + (self.BAR_RIGHT - self.BAR_LEFT)
                               * remaining / duration, self.BAR_BOTTOM)
            self.canvas.itemconfigure('countdown-label', text='')
        else:
            self.canvas.coords('countdown-fill', self.BAR_LEFT, self.BAR_TOP,
                               self.BAR_LEFT, self.BAR_BOTTOM)
            self.canvas.itemconfigure('countdown-label', text='')
        if self.picture_available:
            self.canvas.itemconfigure('placeholder', state='hidden')
            path = Path(word['image'])
            if not path.is_absolute():
                path = BASE / path
            try:
                original_image = tk.PhotoImage(file=str(path))
                # Tkinter alleen: zoom + subsample zonder Pillow-afhankelijkheid.
                # Kies de grootste passende afbeelding, ook bij originele 160px PNG's.
                edge = max(original_image.width(), original_image.height())
                scales = ((z, d, edge*z/d) for z in range(1, 7) for d in range(1, 9))
                zoom, divisor, _ = max((v for v in scales if v[2] <= 150),
                                        key=lambda v: (v[2], -v[0]), default=(1, max(1, math.ceil(edge/150)), 0))
                self.file_image = original_image.zoom(zoom, zoom).subsample(divisor, divisor)
                self.canvas.create_image(483, 137, image=self.file_image,
                                         tags=('revealed-image',))
            except (tk.TclError, OSError):
                pass
        reverse = self.direction == 'nl-ru'
        self.canvas.itemconfigure('translation',
                                  text=(displayed_russian(word) if reverse else word['nl']),
                                  state='normal')
        if self.context_mode:
            self.canvas.itemconfigure('context-nl',
                                      text=(word['context_ru'] if reverse else word['context_nl']),
                                      state='normal')
        # In de omgekeerde richting zou de uitspraak vóór onthullen de
        # oplossing verklappen. Pas na de onthulling spreken we Russisch.
        if reverse and self.settings.get('play_audio_automatically', True):
            self.reverse_audio_requested_at = time.monotonic()
            self.voice_requested = True
            if self.play_cached_voice(word):
                self.reverse_audio_started = True
            else:
                self.ensure_audio(word, play_when_ready=True)
        # De ik-vorm staat al naast de infinitief vanaf het begin; bij
        # onthullen verandert alleen de Nederlandse vertaling.
        self.canvas.itemconfigure('status', text='Controleer je antwoord · kies Goed of Fout')
        self.canvas.itemconfigure('know', state='hidden')
        self.canvas.itemconfigure('rating', state='normal')


    def close_current_card(self, event=None):
        # Rechtsklik en × slaan de beoordeling over.
        self.hide(result='dismissed')
        return 'break'

    def rate(self, result):
        # Beoordeel uitsluitend na tonen van de betekenis. "Toon antwoord" is
        # alleen een onthulactie en schrijft nooit zelf een score weg.
        if not self.active_word or not self.revealed or self.rated_result == result:
            return 'break'
        if callable(self.on_rated):
            self.on_rated(self.active_word, result)
            self.rating_saved = True
        self.rated_result = result
        self.show_rating_selection(result)
        self.cancel_timers()
        # Na beoordeling toont rating-feedback hier het gekozen antwoord.
        self.canvas.itemconfigure('countdown-label', text='')
        self.canvas.coords('countdown-fill', self.BAR_LEFT, self.BAR_TOP, self.BAR_LEFT, self.BAR_BOTTOM)
        self.canvas.itemconfigure('status', text=('Goed' if result == 'good' else 'Fout')
                                  + ' opgeslagen · Volgende →')
        return 'break'

    def mark_known(self, event=None):
        """Toon de vertaling meteen, maar wacht op een expliciete beoordeling."""
        if not self.active_word or self.revealed or self.rated_result:
            return 'break'
        # De gebruiker moet rustig kunnen controleren. Niet automatisch sluiten;
        # het oude onthulmoment en de countdown worden ook geannuleerd.
        self.cancel_timers()
        self.canvas.itemconfigure('countdown-label', text='')
        self.canvas.coords('countdown-fill', self.BAR_LEFT, self.BAR_TOP, self.BAR_LEFT, self.BAR_BOTTOM)
        self.reveal()   # Toont meteen de vertaling en BEIDE Goed/Fout-knoppen.
        return 'break'

    def mark_good(self, event=None):
        return self.rate('good')

    def mark_wrong(self, event=None):
        return self.rate('wrong')

    def next_card(self, event=None):
        # Immediately request another card; this one was shown but not rated.
        self.hide(result='next')
        return 'break'

    def click_audio(self, event):
        # Optional: clicking is never required to continue work or reveal the answer.
        # De onderste rij is voor beoordelen; daarop klikken mag géén audio starten.
        if not self.active_word or event.y < 35 or event.y >= 242:
            return
        if self.direction == 'nl-ru' and not self.revealed:
            return  # Geen verklappende Russische spraak vóór het antwoord.
        self.voice_requested = True
        word = self.active_word
        if self.play_cached_voice(word):
            self.canvas.itemconfigure('status', text='Uitspraak wordt afgespeeld 🔊')
        else:
            self.canvas.itemconfigure('status', text='Uitspraak wordt klaargemaakt…')
            self.ensure_audio(word, play_when_ready=True)

    def stop_audio(self):
        proc = self.audio_process
        self.audio_process = None
        if proc is not None:
            try:
                if proc.poll() is None:
                    proc.terminate()  # × onderbreekt niet alleen de kaart, maar ook de stem.
                    if hasattr(proc, 'wait'):
                        try:
                            proc.wait(timeout=0.25)
                        except subprocess.TimeoutExpired:
                            if hasattr(proc, 'kill'):
                                proc.kill()
            except OSError:
                pass

    def play_cached_voice(self, word):
        p = audio_path_for_word(word)
        if p is None:
            p = voice_cache_path(spoken_russian(word), str(self.settings['voice']))
        if not p.exists():
            return False
        self.stop_audio()  # Opnieuw klikken vervangt de uitspraak, zonder overlap.
        self.audio_process = play_audio(p)
        return self.audio_process is not None

    def ensure_audio(self, word, play_when_ready=False):
        if audio_path_for_word(word):
            return
        p = voice_cache_path(spoken_russian(word), str(self.settings['voice']))
        if p.is_file():
            if play_when_ready:
                self.play_cached_voice(word)
            return
        if p in self.pending_audio:
            return
        self.pending_audio.add(p)
        ru = spoken_russian(word)
        voice = str(self.settings['voice'])
        def worker():
            error = None
            try:
                asyncio.run(make_voice(ru, voice, p))
            except Exception as ex:
                error = str(ex)
            # Worker must NEVER interact with tkinter, even through `after`.
            self.audio_result_queue.append((p, ru, error))
        threading.Thread(target=worker, daemon=True).start()

    def check_audio_results(self):
        while self.audio_result_queue:
            p, ru, error = self.audio_result_queue.pop(0)
            self.pending_audio.discard(p)
            if self.active_word and spoken_russian(self.active_word) == ru and self.voice_requested:
                if not error and p.is_file() and self.play_cached_voice(self.active_word):
                    if self.direction == 'nl-ru' and self.revealed:
                        self.reverse_audio_started = True
                    self.canvas.itemconfigure('status', text='Uitspraak wordt afgespeeld 🔊')
                else:
                    self.audio_failure_hint = 'Geen audio'
                    self.canvas.itemconfigure('status', text='Spraakdienst of speler niet beschikbaar')
                    if self.awaiting_initial_audio:
                        self.begin_card_countdown()
                self.voice_requested = False
        self.audio_poll_id = self.root.after(200, self.check_audio_results)

    def on_window_destroy(self, event):
        # Tk laat een callback nog staan als de root elders wordt afgesloten.
        if event.widget is self.win:
            self.shutdown()

    def shutdown(self):
        if self.edit_dialog is not None:
            try:
                self.edit_dialog.destroy()
            except tk.TclError:
                pass
            self.edit_dialog = None
        self.cancel_timers()
        self.stop_audio()
        if self.audio_poll_id is not None:
            try:
                self.root.after_cancel(self.audio_poll_id)
            except tk.TclError:
                pass
            self.audio_poll_id = None

    def hide(self, result='exposed'):
        """Stop the popup. A chosen rating survives timeout, ×, and Next.

        Bij automatisch onthulde NL→RU-kaarten laat de Russische uitspraak
        uitspelen en geef de gebruiker daarna nog twee seconden. De knop ×,
        rechtermuisklik en Volgende sluiten altijd onmiddellijk.
        """
        if result == 'exposed' and self.countdown_paused_at is not None:
            return  # Bescherm tegen een al in de event-queue beland timer-event.
        if (result == 'exposed' and self.active_word and self.direction == 'nl-ru'
                and self.reverse_audio_requested_at is not None
                and not self.rated_result):
            proc = self.audio_process
            if proc is not None and proc.poll() is None:
                self.canvas.itemconfigure('countdown-label', text='Luisteren…')
                self.delayed_hide_timer_id = self.root.after(
                    200, lambda: self.hide(result='exposed'))
                return
            if self.voice_requested and time.monotonic() - self.reverse_audio_requested_at < 20:
                self.canvas.itemconfigure('countdown-label', text='Uitspraak laden…')
                self.delayed_hide_timer_id = self.root.after(
                    200, lambda: self.hide(result='exposed'))
                return
            # Na timeout mag geen late audio het volgende woord verstoren.
            self.voice_requested = False
            if self.reverse_audio_done_at is None:
                self.reverse_audio_done_at = time.monotonic()
            elapsed = time.monotonic() - self.reverse_audio_done_at
            if elapsed < 2.0:
                self.canvas.itemconfigure('countdown-label', text='Nog 2 s')
                self.delayed_hide_timer_id = self.root.after(
                    max(50, int((2.0 - elapsed) * 1000)),
                    lambda: self.hide(result='exposed'))
                return
        if self.rated_result:
            result = ('next:' + self.rated_result) if result == 'next' else self.rated_result
        self.cancel_timers()
        self.voice_requested = False
        self.stop_audio()
        self.drag_origin = None
        self.drag_moved = False
        self.win.withdraw()
        word = self.active_word
        self.active_word = None
        self.rated_result = None
        self.revealed = False
        callback = self.on_hidden
        self.on_hidden = None
        if callback:
            callback(word, result)


class Application:
    def __init__(self, root, settings, demo=False, once=False):
        self.root, self.settings, self.demo, self.once = root, settings, demo, once
        # Demo en once versnellen alleen de weergave. Geen aparte nepgeschiedenis.
        self.sched = Scheduler(all_words(), direction=settings.get('direction', 'ru-nl'))
        self.popup = Popup(root, settings)
        self.popup.set_vocabulary_score(self.sched.vocabulary_score())
        self.popup.on_rated = self.save_rating_immediately
        self.popup.on_edit = self.save_word_edit
        self.rating_card_identity = None
        self.rating_baseline = None
        self.popup.check_audio_results()
        # Bereid de volgende kaart voor terwijl de app toch wacht op het interval.
        self.prefetched_word = None
        self.prefetch_job_id = None
        self.session_active = False
        self.stats_window = None
        self.stats_score_variable = None
        self.stats_ru_score = None
        self.stats_nl_score = None
        self.stats_shown_variable = None
        self.stats_introduced_variable = None
        self.stats_ratings_variable = None
        self.control_server = None
        self.control_poll_id = None
        self.tray_process = None
        self.restart_requested = False
        self.next_due_at = time.monotonic() + (1.0 if demo or once else max(1, float(settings['interval_minutes']))*60)
        self.tick_id = root.after(500, self.tick)
        # Een nieuw kaartje hoeft niet eerst op online TTS te wachten.
        self.schedule_prefetch()

    def schedule_prefetch(self):
        """Bereid maximaal één volgende kaart voor; nooit de UI blokkeren."""
        if self.prefetch_job_id is None and not self.demo and not self.once:
            self.prefetch_job_id = self.root.after(100, self.prefetch_next)

    def prefetch_next(self):
        self.prefetch_job_id = None
        if self.popup.active_word or not self.settings.get('play_audio_automatically', True):
            return
        if self.settings.get('direction') != 'ru-nl':
            return
        candidate = self.sched.choose(self.settings)
        if candidate is None:
            return
        self.prefetched_word = candidate
        # Asynchroon: bestaande MP3 wordt hergebruikt, anders gegenereerd.
        self.popup.ensure_audio(candidate, play_when_ready=False)

    def shutdown(self):
        if self.prefetch_job_id is not None:
            try:
                self.root.after_cancel(self.prefetch_job_id)
            except tk.TclError:
                pass
            self.prefetch_job_id = None
        if self.tick_id is not None:
            try:
                self.root.after_cancel(self.tick_id)
            except tk.TclError:
                pass
            self.tick_id = None
        if self.control_poll_id is not None:
            try:
                self.root.after_cancel(self.control_poll_id)
            except tk.TclError:
                pass
            self.control_poll_id = None
        if self.control_server is not None:
            self.control_server.close()
            self.control_server = None
            CONTROL_SOCKET.unlink(missing_ok=True)
        if self.tray_process is not None:
            try:
                if self.tray_process.poll() is None:
                    self.tray_process.terminate()
            except OSError:
                pass
            self.tray_process = None
        self.popup.shutdown()

    def start_controls(self):
        """One owner process with a local command socket; tray is only a client."""
        CONTROL_SOCKET.unlink(missing_ok=True)  # remove stale socket after a crash
        server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        try:
            server.bind(str(CONTROL_SOCKET))
            os.chmod(CONTROL_SOCKET, 0o600)
            server.listen(8)
            server.setblocking(False)
        except OSError:
            server.close()
            raise
        self.control_server = server
        self.poll_controls()
        helper = BASE / 'tray_icon.py'
        # The app may run inside its edge-tts venv. GI usually exists only in
        # the distro Python, so launch the tray helper separately with that one.
        distro_python = '/usr/bin/python3' if Path('/usr/bin/python3').exists() else sys.executable
        if helper.is_file():
            try:
                self.tray_process = subprocess.Popen(
                    [distro_python, str(helper), str(CONTROL_SOCKET), str(PAUSE_FILE)],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                    stdin=subprocess.DEVNULL, start_new_session=True)
            except OSError:
                self.tray_process = None

    def poll_controls(self):
        if self.control_server is None:
            return
        while True:
            try:
                conn, _ = self.control_server.accept()
            except BlockingIOError:
                break
            except OSError:
                break
            with conn:
                conn.settimeout(0.2)
                try:
                    command = conn.recv(128).decode('ascii').strip().lower()
                    self.handle_command(command)
                    conn.sendall(b'OK\n')
                except (OSError, ValueError, UnicodeError):
                    pass
        self.control_poll_id = self.root.after(125, self.poll_controls)

    def show_now(self):
        if self.popup.active_word:
            self.popup.win.deiconify()
            self.popup.win.lift()
        else:
            self.try_popup(manual=True)

    def start_session(self):
        self.session_active = True
        self.show_now()

    def end_session(self):
        self.session_active = False
        self.next_due_at = time.monotonic() + max(1, float(self.settings['interval_minutes']))*60

    def refresh_scores(self, update_popup=True):
        """Keep popup, statistics and direction-specific scores synchronized."""
        if update_popup:
            self.popup.set_vocabulary_score(self.sched.vocabulary_score())
        if self.stats_score_variable is not None:
            self.stats_score_variable.set(str(self.sched.vocabulary_score()))
        if getattr(self, 'stats_ru_score', None) is not None:
            self.stats_ru_score.set(str(self.sched.vocabulary_score('ru-nl')))
            self.stats_nl_score.set(str(self.sched.vocabulary_score('nl-ru')))
        state = self.sched.state
        if self.stats_shown_variable is not None:
            self.stats_shown_variable.set(str(state.get('shown_total', 0)))
            entries = [e for e in state.get('words', {}).values() if isinstance(e, dict)]
            self.stats_introduced_variable.set(str(len(entries)))
            successes = sum(int(e.get('successes', 0)) for e in entries)
            failures = sum(int(e.get('failures', 0)) for e in entries)
            self.stats_ratings_variable.set(f'{successes} / {failures}')

    def show_statistics(self):
        """Show separate scores for comprehension and production."""
        if self.stats_window and self.stats_window.winfo_exists():
            self.refresh_scores()
            self.stats_window.lift()
            return
        state = self.sched.state
        entries = [e for e in state.get('words', {}).values() if isinstance(e, dict)]
        successes = sum(int(e.get('successes', 0)) for e in entries)
        failures = sum(int(e.get('failures', 0)) for e in entries)
        self.stats_window = tk.Toplevel(self.root)
        window = self.stats_window
        window.title('Russische Woordflitser — leerstatistieken')
        window.geometry('420x415')
        window.configure(bg='#f9fbff')
        wrapper = tk.Frame(window, bg='#f9fbff', padx=24, pady=19)
        wrapper.pack(fill='both', expand=True)
        tk.Label(wrapper, text='🇷🇺  Leerstatistieken', font=('DejaVu Sans', 14, 'bold'),
                 bg='#f9fbff', fg='#182439').pack(anchor='w', pady=(0, 14))
        self.stats_score_variable = tk.StringVar(value=str(self.sched.vocabulary_score()))
        self.stats_ru_score = tk.StringVar(value=str(self.sched.vocabulary_score('ru-nl')))
        self.stats_nl_score = tk.StringVar(value=str(self.sched.vocabulary_score('nl-ru')))
        self.stats_shown_variable = tk.StringVar(value=str(state.get('shown_total', 0)))
        self.stats_introduced_variable = tk.StringVar(value=str(len(entries)))
        self.stats_ratings_variable = tk.StringVar(value=f'{successes} / {failures}')
        tk.Label(wrapper, text='Goed/Fout en herhalingen worden per richting apart bijgehouden.',
                 font=('DejaVu Sans', 9), bg='#f9fbff', fg='#59677a',
                 wraplength=370, justify='left').pack(anchor='w', pady=(0, 10))
        rows = [
            ('RU → NL: bekende woorden', self.stats_ru_score),
            ('NL → RU: bekende woorden', self.stats_nl_score),
            ('Bekend in huidige richting', self.stats_score_variable),
            ('Getoonde kaarten (huidige richting)', self.stats_shown_variable),
            ('Geïntroduceerd (huidige richting)', self.stats_introduced_variable),
            ('Totaal Goed / Fout (huidige richting)', self.stats_ratings_variable),
            ('Automatische popups', 'Gepauzeerd' if is_paused() else 'Actief'),
        ]
        for name, value in rows:
            row = tk.Frame(wrapper, bg='#f9fbff')
            row.pack(fill='x', pady=4)
            tk.Label(row, text=name, bg='#f9fbff', fg='#59677a').pack(side='left')
            options = {'textvariable': value} if isinstance(value, tk.Variable) else {'text': str(value)}
            tk.Label(row, **options, bg='#f9fbff', fg='#182439',
                     font=('DejaVu Sans', 10, 'bold')).pack(side='right')
        tk.Button(wrapper, text='Sluiten', command=window.destroy).pack(anchor='e', pady=(15, 0))
        window.lift()

    def set_interval(self, minutes: int):
        """Persist the new automatic interval and apply it in the running app."""
        if minutes not in INTERVAL_CHOICES:
            raise ValueError('Onbekend interval')
        # Work with current on-disk settings to preserve customized options.
        path = BASE / 'settings.json'
        stored = load_json(path, {})
        if not isinstance(stored, dict):
            stored = {}
        stored['interval_minutes'] = minutes
        save_json(path, stored)
        self.settings['interval_minutes'] = minutes
        # Reset from now: the prior 30-minute deadline must not linger.
        # In an active manual session the fast practice cadence is unaffected.
        if not self.session_active:
            self.next_due_at = time.monotonic() + minutes * 60

    def set_countdown(self, seconds: int):
        """Bewaar en activeer de sluitingsaftelling vanuit het systeemvak."""
        if seconds not in COUNTDOWN_CHOICES:
            raise ValueError('Ongeldige afteltijd')
        path = BASE / 'settings.json'
        stored = load_json(path, {})
        if not isinstance(stored, dict):
            stored = {}
        stored['hide_after_seconds'] = seconds
        save_json(path, stored)
        self.settings['hide_after_seconds'] = seconds
        self.popup.set_countdown_seconds(seconds)

    def set_new_word_every(self, every: int):
        """Sla nieuwe/herhaling-verhouding op zonder voortgang te wissen."""
        if every not in NEW_WORD_EVERY_CHOICES:
            raise ValueError('Ongeldige verhouding nieuwe/herhalingswoorden')
        path = BASE / 'settings.json'
        stored = load_json(path, {})
        if not isinstance(stored, dict):
            stored = {}
        stored['new_word_every'] = every
        save_json(path, stored)
        self.settings['new_word_every'] = every
        self.prefetched_word = None
        self.schedule_prefetch()
        # De scheduler haalt deze waarde iedere kaart opnieuw uit settings.
        # De kaartteller en leerhistorie blijven intact.

    def _save_preferences(self, updates: dict):
        path = BASE / 'settings.json'
        saved = load_json(path, {})
        if not isinstance(saved, dict):
            saved = {}
        saved.update(updates)
        save_json(path, saved)
        self.settings.update(updates)

    def set_direction(self, direction: str):
        if direction not in DIRECTIONS:
            raise ValueError('Ongeldige oefenrichting')
        self._save_preferences({'direction': direction})
        self.prefetched_word = None
        if not self.popup.active_word:
            self.sched.set_direction(direction)
            self.refresh_scores()
        # Een al getoonde kaart houdt zijn oude richting (en score) tot sluiting.
        self.schedule_prefetch()
        # De lopende kaart mag rustig afgemaakt worden; Volgende gebruikt
        # de nieuwe richting en geeft geen hint van een verborgen antwoord.

    def set_theme(self, theme: str, enabled: bool):
        if theme not in THEME_IDS:
            raise ValueError('Onbekend thema')
        selected = set(self.settings.get('selected_themes', THEME_IDS))
        if enabled:
            selected.add(theme)
        else:
            selected.discard(theme)
        # Met 0 thema's toont de popup geen kaarten; laatste thema blijft aan.
        if not selected:
            raise ValueError('Minstens één thema moet actief blijven')
        self._save_preferences({'selected_themes': [k for k in THEME_IDS if k in selected]})
        self.prefetched_word = None
        self.schedule_prefetch()

    def handle_command(self, command):
        """All GUI actions execute on Tk's main thread, never in GTK."""
        if command.startswith('direction:'):
            self.set_direction(command.partition(':')[2])
        elif command.startswith('theme:'):
            try:
                theme, enabled = command.split(':')[1:]
            except ValueError as exc:
                raise ValueError('Ongeldige themakeuze') from exc
            if enabled not in ('0', '1'):
                raise ValueError('Ongeldige themastand')
            self.set_theme(theme, enabled == '1')
        elif command.startswith('newratio:'):
            try:
                every = int(command.partition(':')[2])
            except ValueError as exc:
                raise ValueError('Ongeldige verhouding') from exc
            self.set_new_word_every(every)
        elif command.startswith('countdown:'):
            try:
                seconds = int(command.partition(':')[2])
            except ValueError as exc:
                raise ValueError('Ongeldige afteltijd') from exc
            self.set_countdown(seconds)
        elif command.startswith('interval:'):
            try:
                minutes = int(command.partition(':')[2])
            except ValueError as exc:
                raise ValueError('Ongeldige intervalkeuze') from exc
            self.set_interval(minutes)
        elif command == 'show':
            self.show_now()
        elif command == 'session':
            self.start_session()
        elif command == 'end-session':
            self.end_session()
        elif command == 'pause':
            PAUSE_FILE.write_text('inf', encoding='utf-8')
        elif command == 'resume':
            PAUSE_FILE.unlink(missing_ok=True)
            self.next_due_at = time.monotonic() + max(1, float(self.settings['interval_minutes']))*60
        elif command == 'stats':
            self.show_statistics()
        elif command == 'restart':
            # Stop de Tk-lus eerst; herstart pas na volledige shutdown.
            # Zo draait er nooit een tweede app naast de eerste.
            self.restart_requested = True
            self.root.quit()
        elif command == 'quit':
            self.root.quit()
        else:
            raise ValueError('Onbekende actie')

    def tick(self):
        if time.monotonic() >= self.next_due_at and not self.popup.active_word:
            self.try_popup(manual=self.session_active, preserve_position=self.session_active)
        self.tick_id = self.root.after(500 if self.demo or self.session_active else 2500, self.tick)

    def try_popup(self, manual=False, exclude=None, preserve_position=False):
        if self.popup.active_word:
            return
        if not (self.demo or self.once or manual):
            if is_paused() or is_quiet_now(datetime.now(), self.settings) or fullscreen_on_x11():
                self.next_due_at = time.monotonic() + 30
                return
            idle = idle_seconds()
            if idle is not None and idle < float(self.settings.get('idle_seconds', 12)):
                self.next_due_at = time.monotonic() + 15
                return
        if self.sched.direction != self.settings.get('direction', 'ru-nl'):
            self.sched.set_direction(self.settings['direction'])
            self.refresh_scores()
        # Gebruik de kaart die tijdens de wachttijd al een MP3 heeft gekregen.
        # Bij themaverandering of Volgende-met-uitsluiting opnieuw selecteren.
        queued = self.prefetched_word
        self.prefetched_word = None
        if (queued is not None and (exclude is None or word_key(queued) != exclude)
                and self.settings.get('direction') == 'ru-nl'
                and self.settings.get('play_audio_automatically', True)
                and any(word_key(queued) == word_key(x) for x in eligible_words(self.sched.words, self.settings))):
            word = queued
        else:
            word = self.sched.choose(self.settings, exclude=exclude, manual=manual)
        if not word:
            self.next_due_at = time.monotonic() + max(1, float(self.settings['interval_minutes']))*60
            return
        # Count every shown word, even if the learner immediately skips/dismisses.
        self.sched.note_shown(word)
        self.refresh_scores()
        self.rating_card_identity = None
        self.rating_baseline = None
        self.popup.show(word, self.after_hide, preserve_position=preserve_position)
        self.next_due_at = time.monotonic() + 10000

    def save_word_edit(self, word, changes):
        """Dezelfde correctie geldt voor RU→NL en NL→RU, niet voor de scores."""
        persist_word_edit(word, changes)
        # Prefetch verwijst meestal naar hetzelfde woordobject, maar een nieuwe
        # selectie is veiliger als de Nederlandse betekenis is veranderd.
        self.prefetched_word = None

    def save_rating_immediately(self, word, result):
        # Cruciaal: schrijven zodra op Goed/Fout is gedrukt, ook als de
        # gebruiker daarna afsluit in plaats van op Volgende te klikken.
        previous = self.sched.vocabulary_score()
        key = word_key(word)
        entry = self.sched.state['words'].get(key, {})
        identity = (key, entry.get('last_card_number'))
        if self.rating_card_identity != identity:
            # Beginstand na note_shown() en vóór de eerste beoordeling.
            # Hiermee wordt een correctie geen tweede of derde beoordeling.
            self.rating_card_identity = identity
            self.rating_baseline = copy.deepcopy(entry)
        else:
            # Vorige beoordeling van DEZELFDE kaart geheel terugdraaien:
            # ook successes/failures, good_streak en geplande herhaling.
            self.sched.state['words'][key] = copy.deepcopy(self.rating_baseline)
        self.sched.record_result(word, result)
        current = self.sched.vocabulary_score()
        self.popup.set_vocabulary_score(current, current - previous)
        self.refresh_scores(update_popup=False)

    def after_hide(self, word, result):
        advance = result == 'next' or result.startswith('next:')
        rating = result.partition(':')[2] if result.startswith('next:') else ('exposed' if result == 'next' else result)
        if word and not (rating in ('good', 'wrong') and self.popup.rating_saved):
            self.sched.record_result(word, rating)
        # De vorige beoordeling werd in de oorspronkelijke richting opgeslagen.
        # Pas nu mag een eventueel gewijzigde menu-richting actief worden.
        new_direction = self.settings.get('direction', 'ru-nl')
        if self.sched.direction != new_direction:
            self.sched.set_direction(new_direction)
            self.refresh_scores()
        if advance:
            # Explicit Next must also work in --once preview mode.  Otherwise
            # the app quits before it can show the next card.
            exclude = word_key(word) if word else None
            self.root.after(0, lambda: self.try_popup(manual=True, exclude=exclude, preserve_position=True))
        elif self.session_active:
            if result == 'dismissed':
                # A deliberate close ends an exercise session.
                self.end_session()
            else:
                self.next_due_at = time.monotonic() + 1.5
        elif self.once:
            self.root.quit()
        elif self.demo:
            self.next_due_at = time.monotonic() + 4
        else:
            jitter = random.uniform(.9, 1.1)
            self.next_due_at = time.monotonic() + max(1, float(self.settings['interval_minutes']))*60*jitter
        if not advance:
            self.schedule_prefetch()


def prepare_audio(words, settings):
    try:
        import edge_tts
    except ImportError:
        print('edge-tts ontbreekt. Voer eerst ./start.sh --prepare-audio uit (installeert automatisch).')
        return 1
    print(f'Natuurlijke Russische vrouwenstem voorbereiden voor {len(words)} woorden...')
    successful, failed = 0, 0
    for i, w in enumerate(words, 1):
        p = audio_path_for_word(w) or voice_cache_path(spoken_russian(w), str(settings['voice']))
        if p.is_file():
            successful += 1
            continue
        try:
            asyncio.run(make_voice(spoken_russian(w), str(settings['voice']), p))
            successful += 1
            print(f'  {i:2}/{len(words)} {w["ru"]} ✓')
        except Exception as ex:
            failed += 1
            print(f'  {i:2}/{len(words)} {w["ru"]} — niet gelukt: {ex}')
    print(f'Klaar: {successful} audiobestanden beschikbaar, {failed} mislukt.')
    return int(failed > 0)


def import_csv(path: Path, replace=False):
    """Anki: Exporteren > notities in platte tekst (tab-gescheiden), eerste twee velden ru/nl.

    Also accepts a regular CSV with headers russian,dutch,image,audio,emoji.
    """
    path = path.expanduser().resolve()
    if not path.exists():
        raise ValueError(f'CSV/TSV bestaat niet: {path}')
    with path.open(encoding='utf-8-sig', newline='') as f:
        sample = f.read(2048)
        f.seek(0)
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters='\t;,')
            delimiter = dialect.delimiter
        except csv.Error:
            delimiter = '\t' if '\t' in sample else ','
        rows = list(csv.reader(f, delimiter=delimiter))
    rows = [r for r in rows if r and not r[0].startswith('#')]
    if not rows:
        raise ValueError('Bestand bevat geen woorden.')
    headers = [s.strip().casefold() for s in rows[0]]
    has_header = any(x in headers for x in ('russian','russisch','ru','nederlands','dutch','nl'))
    def field(row, aliases, fallback=''):
        for name in aliases:
            if name in headers:
                i = headers.index(name)
                return row[i] if i < len(row) else ''
        if fallback == 'russian':
            return row[0] if row else ''
        if fallback == 'dutch':
            return row[1] if len(row) > 1 else ''
        return ''
    def clean(s):
        s = re.sub(r'\[sound:[^]]+\]', '', s)
        s = re.sub(r'<[^>]+>', '', s)
        return s.replace('&nbsp;', ' ').strip()
    imported = []
    media_folder = DATA / 'imported_media'
    for row in rows[1:] if has_header else rows:
        ru = clean(field(row, ('ru','russian','russisch'), 'russian'))
        nl = clean(field(row, ('nl','dutch','nederlands'), 'dutch'))
        if not ru or not nl:
            continue
        item = {'ru': ru, 'nl': nl}
        # Legacy emoji column is accepted on import but deliberately not used
        # as an image fallback; images require a real local file.
        for attr, aliases in [('image', ('image','afbeelding')), ('audio', ('audio','geluid'))]:
            val = field(row, aliases).strip()
            if val:
                src = (path.parent / val).resolve() if not Path(val).is_absolute() else Path(val)
                if src.is_file():
                    media_folder.mkdir(parents=True, exist_ok=True)
                    name = hashlib.sha1(str(src).encode()).hexdigest()[:12] + src.suffix.lower()
                    dest = media_folder / name
                    shutil.copy2(src, dest)
                    item[attr] = str(dest)
        imported.append(item)
    old = [] if replace else load_json(EXTRA_FILE, [])
    merged = {word_key(w): w for w in old + imported if isinstance(w, dict) and 'ru' in w and 'nl' in w}
    save_json(EXTRA_FILE, list(merged.values()))
    return len(imported), len(merged)


def show_progress():
    storage = load_json(STATE_FILE, {})
    if not isinstance(storage, dict):
        storage = {}
    print('Opgeslagen voortgang:', STATE_FILE)
    for direction, label in [('ru-nl', 'RU → NL'), ('nl-ru', 'NL → RU')]:
        state = direction_progress(storage, direction)
        history = state.get('words', {})
        if not isinstance(history, dict):
            history = {}
        print(f'\n{label}:')
        print('  Totaal getoonde kaarten:', int(state.get('shown_total', 0)))
        print('  Geïntroduceerde woorden:', len(history))
        print('  Woordenschat-score:', vocabulary_score(storage, direction))
        print('  Laatst Goed:', sum(isinstance(e, dict) and e.get('last_result') == 'good' for e in history.values()))
        print('  Laatst Fout:', sum(isinstance(e, dict) and e.get('last_result') == 'wrong' for e in history.values()))
        rated = [(key, e) for key, e in history.items() if isinstance(e, dict)
                 and e.get('last_result') in ('good', 'wrong')]
        rated.sort(key=lambda item: item[1].get('last_seen', 0), reverse=True)
        shown = int(state.get('shown_total', 0))
        for key, entry in rated[:5]:
            remaining = max(0, int(entry.get('next_due_other_count', 0))
                            - (shown - int(entry.get('shown_count', 0))))
            status = 'Goed' if entry['last_result'] == 'good' else 'Fout'
            print(f'    {key}: {status}; na {remaining} andere kaarten')


def process_running():
    try:
        pid = int(PID_FILE.read_text().strip())
        # Validate against PID reuse; Linux /proc is accessible to the process owner.
        cmd = (Path(f'/proc/{pid}/cmdline').read_bytes().replace(b'\x00', b' ')).decode(errors='replace')
        return pid if 'russische_woordflitser.py' in cmd else None
    except (OSError, ValueError):
        return None


def send_control(command: str) -> bool:
    """Send a short command to the already running wordflitser."""
    try:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
            client.settimeout(0.7)
            client.connect(str(CONTROL_SOCKET))
            client.sendall((command + '\n').encode('ascii'))
            return client.recv(8).startswith(b'OK')
    except (OSError, ValueError):
        return False


def tray_check():
    py = '/usr/bin/python3' if Path('/usr/bin/python3').is_file() else sys.executable
    return subprocess.call([py, str(BASE / 'tray_icon.py'), '--check'])


def install_autostart():
    AUTOSTART.parent.mkdir(parents=True, exist_ok=True)
    start = BASE / 'start.sh'
    # Exec uses quoting as prescribed in desktop entry spec; $ characters not expected in path.
    AUTOSTART.write_text('[Desktop Entry]\nType=Application\nName=Russische woordflitser\n'
                         f'Exec="{start}" --background\n'
                         'Terminal=false\nX-GNOME-Autostart-enabled=true\n', encoding='utf-8')
    print('Autostart ingeschakeld:', AUTOSTART)


def main():
    parser = argparse.ArgumentParser(description='Russische woordflitser voor Linux')
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--demo', action='store_true', help='Test: verschijnt meteen en vervolgens snel')
    group.add_argument('--once', action='store_true', help='Toon één kaart en sluit')
    group.add_argument('--prepare-audio', action='store_true', help='Maak natuurlijke audio aan via internet')
    group.add_argument('--import-csv', metavar='FILE', type=Path, help='Importeer Anki TXT/TSV of CSV')
    group.add_argument('--stop', action='store_true', help='Stop de lopende achtergrondversie')
    group.add_argument('--pause', type=int, metavar='MINUTEN', help='Pauzeer zonder popups')
    group.add_argument('--resume', action='store_true', help='Hervat na pauze')
    group.add_argument('--status', action='store_true', help='Toon of de flitser draait')
    group.add_argument('--show', action='store_true', help='Toon onmiddellijk een woord in de lopende app')
    group.add_argument('--session', action='store_true', help='Start een oefensessie in de lopende app')
    group.add_argument('--end-session', action='store_true', help='Stop een oefensessie')
    group.add_argument('--stats', action='store_true', help='Open leerstatistieken in een venster')
    group.add_argument('--tray-check', action='store_true', help='Controleer systeemvak-ondersteuning')
    group.add_argument('--progress', action='store_true', help='Toon opgeslagen woorden en Goed/Fout-scores')
    group.add_argument('--frequency-status', action='store_true', help='Toon gebruikte corpusfrequenties')
    group.add_argument('--refresh-frequency', action='store_true', help='Haal Russische frequentiedata op voor de huidige woordenlijst')
    group.add_argument('--install-autostart', action='store_true')
    group.add_argument('--remove-autostart', action='store_true')
    group.add_argument('--background', action='store_true', help='Start op de achtergrond')
    parser.add_argument('--replace', action='store_true', help='Bij import: vervang eerder geïmporteerde woorden')
    args = parser.parse_args()
    if args.import_csv:
        try:
            n, total = import_csv(args.import_csv, args.replace)
        except ValueError as e:
            parser.error(str(e))
        print(f'{n} woorden geïmporteerd; {total} eigen woorden opgeslagen.')
        return 0
    if args.prepare_audio:
        return prepare_audio(all_words(), load_settings())
    if args.tray_check:
        return tray_check()
    if args.install_autostart:
        install_autostart(); return 0
    if args.remove_autostart:
        AUTOSTART.unlink(missing_ok=True)
        print('Autostart uitgeschakeld.'); return 0
    if args.pause is not None:
        PAUSE_FILE.write_text(str(time.time()+max(args.pause, 0)*60), encoding='utf-8')
        print(f'Pauze: {max(args.pause,0)} minuten.'); return 0
    if args.resume:
        PAUSE_FILE.unlink(missing_ok=True)
        print('Flitser hervat.'); return 0
    pid = process_running()
    # Na een herstart met os.execv is dit nog hetzelfde proces/PID.
    # Behandel de eigen PID niet als een tweede, al draaiende instantie.
    if pid == os.getpid():
        pid = None
    if args.stop:
        if pid:
            os.kill(pid, signal.SIGTERM)
            print('Stopverzoek verstuurd.'); return 0
        print('Er draait geen achtergrondversie.'); return 0
    if args.status:
        print(f'Draait (PID {pid})' if pid else 'Niet actief')
        if is_paused(): print('Momenteel gepauzeerd')
        return 0
    if args.refresh_frequency:
        try:
            data = frequentie.refresh_frequency(FREQUENCY_FILE, all_words())
            print(frequentie.summary(data, all_words()))
            print('Herstart de woordflitser om de nieuwe prioriteiten te gebruiken.')
        except RuntimeError as exc:
            print(f'{exc}\nDe ingebouwde offline-prioriteiten blijven werken.', file=sys.stderr)
            raise SystemExit(1)
        return
    if args.frequency_status:
        print(frequentie.summary(frequentie.load_cache(FREQUENCY_FILE), all_words()))
        return
    if args.progress:
        show_progress()
        return 0
    remote = 'show' if args.show else 'session' if args.session else 'end-session' if args.end_session else 'stats' if args.stats else None
    if remote:
        if not pid:
            if remote == 'end-session':
                print('De woordflitser draait niet.')
                return 0
            logfile = (DATA / 'log.txt').open('a', encoding='utf-8')
            try:
                subprocess.Popen([sys.executable, str(Path(__file__).resolve())], cwd=str(BASE),
                                 stdout=logfile, stderr=logfile, stdin=subprocess.DEVNULL,
                                 start_new_session=True)
            finally:
                logfile.close()
        for _ in range(35):
            if send_control(remote):
                print('Opdracht verstuurd:', remote)
                return 0
            time.sleep(0.1)
        print('Geen verbinding met de actieve woordflitser. Controleer ./start.sh --status.')
        return 1
    if args.background:
        if pid:
            print(f'Woordflitser draait al (PID {pid}).'); return 0
        logfile = (DATA / 'log.txt').open('a', encoding='utf-8')
        p = subprocess.Popen([sys.executable, str(Path(__file__).resolve())],
                             cwd=str(BASE), stdout=logfile, stderr=logfile,
                             stdin=subprocess.DEVNULL, start_new_session=True)
        print(f'Woordflitser gestart op de achtergrond (PID {p.pid}).')
        return 0
    if pid:
        print(f'Woordflitser draait al (PID {pid}); gebruik ./start.sh --stop '
              'voordat je een tweede sessie opent. Anders kan de voortgang overschreven worden.')
        return 1
    if not all_words():
        print('Geen Russische woorden in words.json of eigen_woorden.json.')
        return 1
    settings = load_settings()
    if not args.demo and not args.once:
        PID_FILE.write_text(str(os.getpid()), encoding='utf-8')
    root = tk.Tk(className='RussischeWoordflitser')
    root.withdraw()
    app = Application(root, settings, demo=args.demo, once=args.once)
    if not args.demo and not args.once:
        try:
            app.start_controls()
        except OSError as error:
            print(f'Systeemvakbediening niet gestart: {error}', file=sys.stderr)
        # SIGTERM from `--stop` should close the tray helper and its socket.
        signal.signal(signal.SIGTERM, lambda *_: root.quit())
    try:
        root.mainloop()
    finally:
        app.shutdown()
        if not args.demo and not args.once and not app.restart_requested:
            try:
                if int(PID_FILE.read_text()) == os.getpid():
                    PID_FILE.unlink(missing_ok=True)
            except (OSError, ValueError):
                pass
        root.destroy()
    if app.restart_requested:
        # os.execv vervangt DEZELFDE achtergrondprocess (PID blijft gelijk).
        # De socket/tray-helper zijn in app.shutdown() al netjes afgesloten.
        # Gebruik dezelfde Python (.venv met werkende spraak) en laad nu ook
        # nieuwe code nadat de gebruiker bestanden heeft gekopieerd.
        try:
            os.execv(sys.executable, [sys.executable, str(Path(__file__).resolve())])
        except OSError as exc:
            print(f'Automatisch herstarten mislukt: {exc}', file=sys.stderr)
            try:
                if int(PID_FILE.read_text()) == os.getpid():
                    PID_FILE.unlink(missing_ok=True)
            except (OSError, ValueError):
                pass
            return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())
