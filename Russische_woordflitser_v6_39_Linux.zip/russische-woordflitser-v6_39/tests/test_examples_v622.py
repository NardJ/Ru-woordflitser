"""v6.22: Dutch/Russian examples on every card, enlarged pictures, stable window."""
import json
import re
import sys
import tkinter as tk
from pathlib import Path
from unittest import TestCase
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import russische_woordflitser as app

class ExamplesV622(TestCase):
    @classmethod
    def setUpClass(cls):
        cls.words=json.loads((ROOT/'words.json').read_text(encoding='utf-8'))

    def test_all_words_have_two_examples_without_latin_russian(self):
        self.assertEqual(len(self.words),1090)
        for w in self.words:
            self.assertTrue(w['context_ru'],w['ru'])
            self.assertTrue(w['context_nl'],w['ru'])
            self.assertLess(len(w['context_ru']),180)
            self.assertLess(len(w['context_nl']),180)
            self.assertIsNone(re.search(r'[A-Za-zÀ-ÿ]',w['context_ru']),w['ru'])

    def test_popup_fixed_size_and_image_panel(self):
        root=tk.Tk();root.withdraw()
        opts={**app.DEFAULT_SETTINGS,'play_audio_automatically':False,'popup_opacity':1}
        p=app.Popup(root,opts)
        try:
            with patch.object(p,'ensure_audio'):
                w=next(w for w in self.words if app.word_key(w)=='горячий')
                p.show(w);root.update()
                self.assertTrue(p.context_mode)
                self.assertTrue(p.picture_available)
                self.assertEqual((p.win.winfo_width(),p.win.winfo_height()),(580,290))
                bb=p.canvas.bbox('image-panel')
                self.assertGreaterEqual(bb[2]-bb[0],95)
                p.reveal();root.update()
                self.assertTrue(p.canvas.find_withtag('revealed-image'))
                self.assertEqual(p.canvas.itemcget('context-nl','text'),w['context_nl'])
        finally:p.shutdown();root.destroy()

    def test_reverse_direction_doesnt_leak_russian(self):
        root=tk.Tk();root.withdraw()
        opts={**app.DEFAULT_SETTINGS,'play_audio_automatically':False,'direction':'nl-ru'}
        p=app.Popup(root,opts)
        try:
            with patch.object(p,'ensure_audio'):
                w=next(w for w in self.words if app.word_key(w)=='горячий')
                p.show(w);root.update()
                self.assertEqual(p.canvas.itemcget('context-ru','text'),w['context_nl'])
                self.assertEqual(p.canvas.itemcget('translation','text'),'')
                p.reveal()
                self.assertEqual(p.canvas.itemcget('context-nl','text'),w['context_ru'])
        finally:p.shutdown();root.destroy()
