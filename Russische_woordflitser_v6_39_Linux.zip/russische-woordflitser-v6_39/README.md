# Russische Woordflitser v6.39 (Linux)

Dit pakket bevat 1.066 gewone woordkaarten, 24 verwarringsoefeningen, 802 gekoppelde afbeeldingen, aparte leerstanden per oefenrichting en de verbeterde automatische uitspraak.

## Nieuw in v6.39 — Alleen aftellen tot het antwoord

Boven de voorbeeldzinnen staat tijdens het nadenken uitsluitend
**Antwoord over 3 s** (met de juiste resterende seconden).
Zodra het antwoord zichtbaar wordt, verdwijnt deze tekst volledig.
Er verschijnt nooit meer **weg over ...**, **Antwoord zichtbaar** of
**Blijft open** op deze plaats. Bij pauzeren bevriest het getal; de
pauzeknop toont de toestand. De groen-geel-rode balk loopt zoals in
v6.38 ongewijzigd terug tot de kaart verdwijnt. De kaart blijft
**580 × 290 pixels** en alle leerstanden blijven behouden.

## v6.38 — Afteller op kaartformaat 580 × 290

Bij een totale leertijd van 9 seconden heeft de **balk altijd de resterende
kaarttijd als breedte**: 9 s = 100% groen, 7,5 s = 83% geel, 6 s = 67% rood
(antwoord verschijnt), 3 s = 33% rood, 0 s = leeg (kaart verdwijnt).
De kleur glijdt vóór het antwoord geleidelijk van groen via geel naar rood,
en blijft daarna rood. De oorspronkelijke v6.38 toonde twee tijdstippen naast de voorbeeldzinnen;
in v6.39 is deze tijdtekst vereenvoudigd tot alleen de seconden tot het antwoord.
Geen nieuwe knoppen of grotere kaart: nog steeds **580 × 290 pixels**.
De bestaande hover-/klikpauze bevriest de balk, kleur en resterende tijd. Met
*Toon antwoord* wordt de afteller gestopt en blijft de kaart open. De
leerhistorie, audio en alle andere functies blijven behouden.

De volgende kaart krijgt zo veel mogelijk alvast een MP3 tijdens de wachttijd tussen popups. Dit vermindert het aantal stille kaarten wanneer de online spraakdienst langzaam reageert. Bij een fout of een te late spraakreactie toont de afteller een korte statusmelding. De app speelt geen late audio af nadat de popup is gesloten.

## Installatie

Pak het ZIP-bestand uit in een aparte map en voer uit:

```bash
./update_existing.sh /pad/naar/je/bestaande/russische-woordflitser
```

Bestaande beoordelingen, spraakbestanden, afbeeldingen, autostart en instellingen blijven behouden. Voor het genereren van nieuwe audio moet `edge-tts` geïnstalleerd zijn in de `.venv` van de app en moet internet beschikbaar zijn. `ffplay` of `mpv` verzorgt het afspelen.

## Controleren

```bash
./start.sh --stop
./start.sh --background
```

De gerichte tests voor richting, score, scheduler en systeemvak zijn in een virtuele Linux-desktop gedaan. Bij zeer trage of onbereikbare TTS kan een nieuw woord alsnog stil zijn; in dat geval verschijnt een melding in de afteller.

## v6.30 — twee onafhankelijke leerstanden

De woorden zijn dezelfde, maar RU→NL (herkennen) en NL→RU (zelf Russisch
produceren) hebben elk hun eigen bekende woorden, Goed/Fout-beoordelingen,
kaartteller en herhaalschema. Schakel via **Oefenrichting** in het systeemvak.
De score bovenaan de kaart en de twee scores in het systeemvak worden apart
getoond. `./start.sh --progress` geeft beide overzichten.

**Migratie:** tot en met v6.29 was er één gedeelde voortgang zonder informatie
over de historische oefenrichting. Deze oude voortgang blijft volledig bestaan
als RU→NL; NL→RU begint met een eigen, lege voortgang. Een reservekopie van
`progress.json` wordt door de updater gemaakt. Verwijder of reset je
historie niet; de huidige audio-cache blijft ook gedeeld.

## v6.31 — Tekst aanpassen op de kaart

Klik op het potloodje **✎** in de rechterbovenhoek van een kaart. Bewerk
de Nederlandse betekenis en eventueel beide voorbeeldzinnen. Kies Opslaan
of Annuleren. Via *Standaard herstellen* kun je terug naar de oorspronkelijke
vertaling en voorbeeldzinnen. De kaart wordt tijdens het bewerken niet
automatisch gesloten en krijgt daarna opnieuw leertijd (of blijft open als
de vertaling al zichtbaar was).

Wijzigingen worden apart opgeslagen in
`~/.local/share/russische-woordflitser/woordcorrecties.json`, gedeeld voor
beide oefenrichtingen. Ze blijven behouden na updates en beïnvloeden
Goed/Fout, je scores en geplande herhalingen niet. De Russische woordvorm
is voorlopig niet te wijzigen: die fungeert als vaste sleutel voor je voortgang
en audio-cache. De eerdere vertaling bij **свой** is standaard verduidelijkt
naar **mijn/jouw/zijn/haar eigen**.

## v6.32 — Ondoorzichtig, versleepbaar bewerkvenster

Het bewerkvenster heeft altijd 100% dekking, onafhankelijk van de ingestelde
transparantie van de gewone woordkaart. Het is een zelfstandig venster met
vensterbalk (de extra blauwe sleepgreep is vervallen in v6.34).
Alle leerstanden, woordcorrecties, audio en popupinstellingen blijven ongewijzigd.


## v6.33 — Bewerken zonder overlap

De woordkaart gebruikt een speciaal X11-notificatievenster dat boven een
gewone editor kon blijven hangen. Dit gaf de indruk dat het bewerkvenster
transparant was. Tijdens het bewerken wordt alleen de woordkaart tijdelijk
verborgen; na Opslaan, Annuleren of sluiten verschijnt dezelfde kaart
weer op dezelfde plaats en met dezelfde transparantie. De editor zelf
blijft volledig ondoorzichtig en verplaatsbaar via de titelbalk. Scores, tekstcorrecties en voortgang blijven behouden.


## v6.34 — Vereenvoudigd bewerkvenster

De overbodige lichtblauwe balk met “Sleep hier om het venster te verplaatsen”
is verwijderd. De gewone titelbalk blijft aanwezig en is voldoende om het
bewerkvenster te verplaatsen. De vertaling staat daardoor hoger in het venster.
De gewone woordkaart, transparantie, score en bediening blijven onveranderd.


## v6.35 — Verwarringswoorden (NL → RU)

In **Thema’s oefenen** kun je **Verwarringswoorden (NL → RU)** aan- of uitzetten.
Kies als oefenrichting **NL → RU**. De kaart toont in het gewone vraaggedeelte
een Nederlandse betekenis met drie Russische opties in willekeurige volgorde.
De Nederlandse voorbeeldzin is direct zichtbaar. De correcte Russische vorm
en Russische voorbeeldzin verschijnen tijdens het onthulmoment. De kaartgrootte
blijft 580×290 en Goed/Fout en Volgende werken hetzelfde als voorheen.
De oefenvragen hebben ieder hun eigen herhaalhistorie; de gewone woordkaarten
en de 'bekende woorden'-score blijven onafhankelijk. Het thema is in RU → NL
bewust niet beschikbaar, zodat dezelfde Russische woorden niet dubbel worden
aangeboden.

Om nog meer oefenvragen toe te voegen: nieuwe objecten met `theme` 'verwarring',
`exercise_id` (uniek), `ru` (juiste antwoord), `nl` (opdracht), `choices` (drie
Russische opties) en `context_nl` / `context_ru` aan `words.json` toevoegen.
Het programma hoeft daarvoor niet te worden gewijzigd.


## v6.36 — Afteller pauzeren op de kaart

Naast **Toon antwoord** staat nu **Pauzeer**. Je kunt met de muis boven
**Pauzeer** blijven hangen: zolang de aanwijzer erboven staat, stoppen
zowel het automatisch onthullen als het sluiten van de kaart. Beweeg de
muis eraf om verder te tellen vanaf dezelfde resterende tijd.

Een **klik** zet de pauze vast, zodat je de muis kunt verplaatsen zonder
de aftelling te hervatten. De knop heet dan **Hervat**; nogmaals klikken
start de klok weer, ook als de muis nog op de knop staat. **Toon antwoord**
blijft tijdens een pauze werken. Na onthullen verdwijnen Toon antwoord
en Pauzeer zoals voorheen ten gunste van Goed/Fout. Een nieuwe kaart
begint altijd ongepauzeerd. De kaart blijft **580 × 290 pixels**.

De pauze is uitsluitend voor de huidige kaart; de instelling
**Automatische popups pauzeren** via het systeemvak blijft apart.


## v6.37 — Twee momenten op de afteller

Tijdens het nadenken toont de kleine tijdregel zowel de seconden tot het
antwoord (*Antw.*) als tot het verdwijnen van de kaart (*Weg*). In v6.37 werd de balk eerst rood gevuld en daarna korter;
in v6.38 loopt de breedte vanaf het eerste moment doorlopend terug,
terwijl de kleur van groen via geel naar rood gaat. De knop
**Pauzeer** bevriest zowel de tijden als de balk. Het bestaande kaartformaat
(580 × 290) is ongewijzigd. Na **Toon antwoord** blijft de kaart open.
