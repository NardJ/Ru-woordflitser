#!/usr/bin/env python3
"""Gtk 3 / XApp tray helper with AppIndicator fallback.

The GTK helper never reads or writes progress.json. It sends tiny local IPC
commands to the single Tk process, avoiding mixed GTK and Tk event loops.
Uses system Python with python3-gi; no pip package is required.
"""
from __future__ import annotations
import argparse
import json
import os
from pathlib import Path
import socket
import sys

APP_VERSION = '6.59'
BASE = Path(__file__).resolve().parent
ICON = BASE / 'images' / 'tray_icon.png'
SETTINGS_FILE = BASE / 'settings.json'
PROGRESS_FILE = Path(os.environ.get('XDG_DATA_HOME', str(Path.home() / '.local/share'))) / 'russische-woordflitser/progress.json'
INTERVAL_CHOICES = (1, 2, 5, 10, 15, 30, 60)
COUNTDOWN_CHOICES = (5, 7, 9, 11, 13, 15)
NEW_WORD_EVERY_CHOICES = (2, 3, 4, 5, 6, 8, 10, 15, 20)
THEME_CHOICES = (
    ('mensen', 'Mensen & relaties'), ('thuis', 'Huis & spullen'),
    ('eten', 'Eten & drinken'), ('natuur', 'Natuur & dieren'),
    ('reizen', 'Reizen & vervoer'), ('gezondheid', 'Lichaam & gezondheid'),
    ('werk', 'Werk & leren'), ('kleding', 'Kleding'),
    ('tijd', 'Tijd & getallen'), ('handelingen', 'Werkwoorden & handelingen'),
    ('eigenschappen', 'Eigenschappen'), ('grammatica', 'Kleine woorden & grammatica'),
    ('zinnen', 'Veelgebruikte zinnen'), ('verwarring', 'Verwarringswoorden (NL → RU)'),
    ('naamvallen', 'Naamvallen herkennen (RU-zinnen)'),
    ('overig', 'Eigen / overige woorden'),
)
THEME_IDS = tuple(name for name, _ in THEME_CHOICES)
DIRECTIONS = ('ru-nl', 'nl-ru')


def selected_direction():
    try:
        choice = json.loads(SETTINGS_FILE.read_text(encoding='utf-8')).get('direction', 'ru-nl')
        return choice if choice in DIRECTIONS else 'ru-nl'
    except (OSError, ValueError, TypeError, AttributeError):
        return 'ru-nl'


def selected_themes():
    try:
        chosen = json.loads(SETTINGS_FILE.read_text(encoding='utf-8')).get('selected_themes')
        return set(THEME_IDS if chosen is None else chosen)
    except (OSError, ValueError, TypeError, AttributeError):
        return set(THEME_IDS)



def selected_example_speech():
    try:
        return bool(json.loads(SETTINGS_FILE.read_text(encoding='utf-8')).get(
            'speak_examples_automatically', True))
    except (OSError, ValueError, TypeError, AttributeError):
        return True


def selected_countdown():
    try:
        value = int(json.loads(SETTINGS_FILE.read_text(encoding='utf-8')).get('hide_after_seconds', 9))
        return min(COUNTDOWN_CHOICES, key=lambda item: (abs(item-value), item))
    except (OSError, ValueError, TypeError, AttributeError):
        return 9


def selected_new_word_every():
    try:
        value = int(json.loads(SETTINGS_FILE.read_text(encoding='utf-8')).get('new_word_every', 5))
        return value if value in NEW_WORD_EVERY_CHOICES else 5
    except (OSError, ValueError, TypeError, AttributeError):
        return 5


def selected_interval():
    """Current persisted selection; never changes or writes the config."""
    try:
        import json
        value = json.loads(SETTINGS_FILE.read_text(encoding='utf-8')).get('interval_minutes', 5)
        value = int(value)
        return value if value in INTERVAL_CHOICES else 5
    except (OSError, ValueError, TypeError, AttributeError):
        return 5



def selected_audio_normalization() -> bool:
    try:
        return bool(json.loads(SETTINGS_FILE.read_text(encoding='utf-8')).get('normalize_audio', True))
    except (OSError, ValueError, TypeError, AttributeError):
        return True


def selected_volume() -> int:
    """Read only: de hoofdapp bewaart de echte instelling."""
    try:
        value = json.loads(SETTINGS_FILE.read_text(encoding='utf-8')).get('audio_volume', 75)
        value = int(value)
        return value if 0 <= value <= 200 else 75
    except (OSError, ValueError, TypeError, AttributeError, OverflowError):
        return 75


def read_vocabulary_score(direction='ru-nl') -> int:
    """Read the latest saved ratings; the GTK helper never changes them."""
    try:
        state = json.loads(PROGRESS_FILE.read_text(encoding='utf-8'))
        substate = state.get('nl_ru', {}) if direction == 'nl-ru' else state
        words = substate.get('words', {}) if isinstance(substate, dict) else {}
        if not isinstance(words, dict):
            return 0
        return sum(isinstance(entry, dict) and entry.get('last_result') == 'good'
                   and not str(key).startswith(('verwarring:', 'naamvallen:'))
                   for key, entry in words.items())
    except (OSError, ValueError, AttributeError):
        return 0


def gtk_modules():
    try:
        import gi
        gi.require_version('Gtk', '3.0')
        from gi.repository import Gtk, GLib
        indicator = None
        for lib in ('AyatanaAppIndicator3', 'AppIndicator3'):
            try:
                gi.require_version(lib, '0.1')
                indicator = __import__('gi.repository', fromlist=[lib]).__dict__[lib]
                break
            except (ImportError, ValueError, AttributeError):
                continue
        return Gtk, GLib, indicator
    except (ImportError, ValueError) as exc:
        raise RuntimeError('GTK3/PyGObject ontbreekt (python3-gi en gir1.2-gtk-3.0)') from exc


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('socket', nargs='?', type=Path)
    parser.add_argument('pause_file', nargs='?', type=Path)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    try:
        Gtk, GLib, Indicator = gtk_modules()
    except RuntimeError as exc:
        print(f'Systeemvak niet beschikbaar: {exc}', file=sys.stderr)
        print('Ubuntu/Debian: sudo apt install python3-gi gir1.2-gtk-3.0 gir1.2-ayatanaappindicator3-0.1', file=sys.stderr)
        return 1
    if args.check:
        try:
            import gi
            gi.require_version('XApp', '1.0')
            from gi.repository import XApp
            backend = 'XApp.StatusIcon + ingebouwd GTK-volumemenu'
        except (ImportError, ValueError, OSError, AttributeError):
            backend = ('AppIndicator + compacte volume-popup' if Indicator else
                       'Gtk.StatusIcon (X11) + compacte volume-popup')
        print('GTK3 gevonden. Voorkeursbackend:', backend)
        print('Een werkelijk zichtbaar icoon hangt af van de desktopomgeving.')
        return 0
    if not args.socket or not args.pause_file:
        parser.error('socket en pause_file zijn vereist')
    initialized = Gtk.init_check()
    success = initialized[0] if isinstance(initialized, tuple) else initialized
    if not success:
        print('Geen grafische Gtk-sessie beschikbaar.', file=sys.stderr)
        return 2

    def send(command: str):
        try:
            with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
                client.settimeout(0.35)
                client.connect(str(args.socket))
                client.sendall((command + '\n').encode('ascii'))
                # De Tk-hoofdapp verwerkt de opdracht asynchroon.
        except OSError:
            # Bij afsluiten van de hoofdapp verdwijnt ook dit menu.
            if not args.socket.exists():
                Gtk.main_quit()

    # Op Linux Mint/Cinnamon dezelfde werkwijze als BluePlayer v2.7:
    # XApp.StatusIcon + een zelfstandig GTK-venster met een ECHTE slider.
    # Bij ontbrekende XApp-ondersteuning houden we het geteste oude menu.
    try:
        import gi
        gi.require_version('XApp', '1.0')
        from gi.repository import Gdk, XApp
    except (ImportError, ValueError, OSError, AttributeError):
        XApp = None
    if XApp is not None:
        try:
            from tray_xapp import XAppMenu
            xapp_panel = XAppMenu(Gtk, Gdk, GLib, XApp, send,
                                  args.socket, args.pause_file)
        except Exception as exc:
            # Laat een kapotte menuvariant nooit de hele woordflitser stoppen.
            print(f'XApp-menu kon niet starten; oud menu wordt gebruikt: {exc}',
                  file=sys.stderr)
        else:
            Gtk.main()
            return 0

    menu = Gtk.Menu()

    def add(label: str, command: str):
        item = Gtk.MenuItem.new_with_label(label)
        item.connect('activate', lambda _item: send(command))
        item.show()
        menu.append(item)
        return item

    add('Toon nu een woord', 'show')
    add('Start oefensessie', 'session')
    add('Stop oefensessie', 'end-session')
    score_item = Gtk.MenuItem.new_with_label(f'Bekend RU→NL: {read_vocabulary_score("ru-nl")}  |  NL→RU: {read_vocabulary_score("nl-ru")}')
    score_item.set_sensitive(False)
    score_item.show()
    menu.append(score_item)
    separator = Gtk.SeparatorMenuItem()
    separator.show()
    menu.append(separator)
    pause_item = add('Pauzeer automatische popups', 'pause')
    resume_item = add('Hervat automatische popups', 'resume')
    add('Leerstatistieken', 'stats')
    examples_item = Gtk.CheckMenuItem.new_with_label('Voorbeeldzinnen automatisch uitspreken')
    examples_item.connect('toggled', lambda widget: (
        None if synchronizing[0] else send(f'examplespeech:{int(widget.get_active())}')))
    examples_item.show()
    menu.append(examples_item)


    normalization_item = Gtk.CheckMenuItem.new_with_label('Spraakvolume automatisch normaliseren')
    normalization_item.connect('toggled', lambda widget: (
        None if synchronizing[0] else send(f'normalizespeech:{int(widget.get_active())}')))
    normalization_item.show()
    menu.append(normalization_item)

    # Houd AppIndicator als primaire backend: dit zorgt dat het RU-icoon op
    # dezelfde plek blijft staan als in v6.48. DBusMenu kan geen Gtk.Scale
    # exporteren. Een kleine versieringsloze, *echte* Gtk.Window werkt wel:
    # die is interactief en blijft zichtbaar als het tray-menu dichtgaat.
    volume_window = [None]
    volume_pending = [None]
    volume_timeout = [None]
    volume_item = Gtk.MenuItem.new_with_label(f'Uitspraakvolume… ({selected_volume()}%)')

    def flush_volume():
        volume_timeout[0] = None
        value = volume_pending[0]
        volume_pending[0] = None
        if value is not None:
            send(f'volume:{value}')
            volume_item.set_label(f'Uitspraakvolume… ({value}%)')
        return False

    def close_volume(*_unused):
        if volume_timeout[0] is not None:
            GLib.source_remove(volume_timeout[0])
            volume_timeout[0] = None
        flush_volume()  # Ook de laatste stand opslaan bij sluiten.
        volume_window[0] = None
        return False

    def show_volume_popup():
        if volume_window[0] is not None:
            volume_window[0].present()
            return False
        window = Gtk.Window(type=Gtk.WindowType.TOPLEVEL)
        window.set_title('Uitspraakvolume')
        window.set_decorated(False)
        window.set_skip_taskbar_hint(True)
        window.set_default_size(340, 115)
        window.set_resizable(False)
        window.set_position(Gtk.WindowPosition.MOUSE)
        window.set_keep_above(True)

        # Gtk.Window mag maar één rechtstreekse child hebben. De extra add()
        # uit v6.49 maakte deze popup onbruikbaar.
        frame = Gtk.Frame()
        window.add(frame)
        wrapper = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=8)
        wrapper.set_border_width(12)
        frame.add(wrapper)

        title = Gtk.Label(label='Uitspraakvolume')
        title.set_xalign(0)
        wrapper.pack_start(title, False, False, 0)
        current = selected_volume()
        value_label = Gtk.Label(label=f'{current}%')
        value_label.set_xalign(1)
        scale_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=10)
        scale = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 200, 1)
        scale.set_draw_value(False)
        scale.add_mark(100, Gtk.PositionType.BOTTOM, '100%')
        scale.set_hexpand(True)
        scale.set_value(current)
        volume_window[0] = window

        def changed(widget):
            value = int(widget.get_value())
            value_label.set_text(f'{value}%')
            volume_pending[0] = value
            if volume_timeout[0] is not None:
                GLib.source_remove(volume_timeout[0])
            volume_timeout[0] = GLib.timeout_add(120, flush_volume)

        scale.connect('value-changed', changed)
        scale_row.pack_start(Gtk.Label(label='0'), False, False, 0)
        scale_row.pack_start(scale, True, True, 0)
        scale_row.pack_start(Gtk.Label(label='200'), False, False, 0)
        scale_row.pack_start(value_label, False, False, 0)
        wrapper.pack_start(scale_row, False, False, 0)
        note = Gtk.Label(label='Boven 100% = extra versterking')
        note.set_xalign(0)
        wrapper.pack_start(note, False, False, 0)
        close_button = Gtk.Button.new_with_label('Sluiten')
        close_button.connect('clicked', lambda _button: window.destroy())
        wrapper.pack_start(close_button, False, False, 0)
        window.connect('key-press-event', lambda win, event: (
            win.destroy() or True) if event.keyval == 0xff1b else False)
        window.connect('destroy', close_volume)
        window.show_all()
        window.present()
        return False

    def open_volume(_item):
        # Geef het AppIndicator-menu tijd zijn input-grab vrij te geven.
        # Zo ontvangt de slider ook werkelijk muisklikken en sleepacties.
        GLib.timeout_add(80, show_volume_popup)

    volume_item.connect('activate', open_volume)
    volume_item.show()
    menu.append(volume_item)

    # Radio submenu: only selecting an option sends IPC. Refreshes from the
    # same settings file that the Tk owner writes, never from GTK itself.
    interval_parent = Gtk.MenuItem.new_with_label('Interval automatische popups')
    interval_menu = Gtk.Menu()
    interval_items = {}
    synchronizing = [False]
    first_item = None
    for minutes in INTERVAL_CHOICES:
        label = f'Elke {minutes} minuut' if minutes == 1 else (
            'Elk uur' if minutes == 60 else f'Elke {minutes} minuten')
        item = Gtk.RadioMenuItem.new_with_label_from_widget(first_item, label)
        if first_item is None:
            first_item = item
        def changed(widget, selected_minutes):
            if widget.get_active() and not synchronizing[0]:
                send(f'interval:{selected_minutes}')
        item.connect('toggled', changed, minutes)
        item.show()
        interval_menu.append(item)
        interval_items[minutes] = item
    interval_parent.set_submenu(interval_menu)
    interval_parent.show()
    menu.append(interval_parent)

    countdown_parent = Gtk.MenuItem.new_with_label('Afteltijd popup')
    countdown_menu = Gtk.Menu()
    countdown_items = {}
    first_countdown = None
    for seconds in COUNTDOWN_CHOICES:
        item = Gtk.RadioMenuItem.new_with_label_from_widget(
            first_countdown, f'{seconds} seconden')
        if first_countdown is None:
            first_countdown = item
        def countdown_changed(widget, selected_seconds):
            if widget.get_active() and not synchronizing[0]:
                send(f'countdown:{selected_seconds}')
        item.connect('toggled', countdown_changed, seconds)
        item.show()
        countdown_menu.append(item)
        countdown_items[seconds] = item
    countdown_parent.set_submenu(countdown_menu)
    countdown_parent.show()
    menu.append(countdown_parent)

    ratio_parent = Gtk.MenuItem.new_with_label('Nieuwe woorden / herhalingen')
    ratio_menu = Gtk.Menu()
    ratio_items = {}
    first_ratio = None
    for every in NEW_WORD_EVERY_CHOICES:
        repeats = every - 1
        label = f'1 nieuw + {repeats} herhaling' if repeats == 1 else f'1 nieuw + {repeats} herhalingen'
        item = Gtk.RadioMenuItem.new_with_label_from_widget(first_ratio, label)
        if first_ratio is None:
            first_ratio = item
        def ratio_changed(widget, selected_every):
            if widget.get_active() and not synchronizing[0]:
                send(f'newratio:{selected_every}')
        item.connect('toggled', ratio_changed, every)
        item.show()
        ratio_menu.append(item)
        ratio_items[every] = item
    ratio_parent.set_submenu(ratio_menu)
    ratio_parent.show()
    menu.append(ratio_parent)

    theme_parent = Gtk.MenuItem.new_with_label('Thema’s oefenen')
    theme_menu = Gtk.Menu()
    theme_items = {}

    def set_all_themes(enabled: bool):
        # Eén IPC-opdracht en één instellingenschrijfbeurt, niet 15 aparte.
        send('themes:all' if enabled else 'themes:none')
        synchronizing[0] = True
        try:
            for item in theme_items.values():
                item.set_active(enabled)
        finally:
            synchronizing[0] = False

    for label, enabled in [('Alle thema’s aan', True), ('Alle thema’s uit', False)]:
        bulk_item = Gtk.MenuItem.new_with_label(label)
        bulk_item.connect('activate', lambda _item, value=enabled: set_all_themes(value))
        bulk_item.show()
        theme_menu.append(bulk_item)
    theme_separator = Gtk.SeparatorMenuItem()
    theme_separator.show()
    theme_menu.append(theme_separator)

    for theme_id, theme_label in THEME_CHOICES:
        item = Gtk.CheckMenuItem.new_with_label(theme_label)
        def theme_changed(widget, key):
            if not synchronizing[0]:
                send(f'theme:{key}:{int(widget.get_active())}')
        item.connect('toggled', theme_changed, theme_id)
        item.show()
        theme_menu.append(item)
        theme_items[theme_id] = item
    theme_parent.set_submenu(theme_menu)
    theme_parent.show()
    menu.append(theme_parent)

    direction_parent = Gtk.MenuItem.new_with_label('Oefenrichting')
    direction_menu = Gtk.Menu()
    direction_items = {}
    first_direction = None
    for direction, label in [('ru-nl', 'Russisch → Nederlands'),
                             ('nl-ru', 'Nederlands → Russisch')]:
        item = Gtk.RadioMenuItem.new_with_label_from_widget(first_direction, label)
        if first_direction is None:
            first_direction = item
        def direction_changed(widget, key):
            if widget.get_active() and not synchronizing[0]:
                send(f'direction:{key}')
        item.connect('toggled', direction_changed, direction)
        item.show()
        direction_menu.append(item)
        direction_items[direction] = item
    direction_parent.set_submenu(direction_menu)
    direction_parent.show()
    menu.append(direction_parent)

    separator2 = Gtk.SeparatorMenuItem()
    separator2.show()
    menu.append(separator2)
    add('Woordflitser herstarten', 'restart')
    add('Afsluiten', 'quit')

    def is_paused():
        if not args.pause_file.is_file():
            return False
        try:
            import time
            return float(args.pause_file.read_text().strip()) > time.time()
        except (OSError, ValueError):
            return False

    def update_menu():
        score_item.set_label(f'Bekend RU→NL: {read_vocabulary_score("ru-nl")}  |  NL→RU: {read_vocabulary_score("nl-ru")}')
        paused = is_paused()
        pause_item.set_sensitive(not paused)
        resume_item.set_sensitive(paused)
        # Sync active radio option after restart and after a failed IPC send.
        # The guard prevents programmatic changes from sending commands back.
        selected = selected_interval()
        if not interval_items[selected].get_active():
            synchronizing[0] = True
            try:
                interval_items[selected].set_active(True)
            finally:
                synchronizing[0] = False
        chosen_countdown = selected_countdown()
        if not countdown_items[chosen_countdown].get_active():
            synchronizing[0] = True
            try:
                countdown_items[chosen_countdown].set_active(True)
            finally:
                synchronizing[0] = False
        chosen_ratio = selected_new_word_every()
        if not ratio_items[chosen_ratio].get_active():
            synchronizing[0] = True
            try:
                ratio_items[chosen_ratio].set_active(True)
            finally:
                synchronizing[0] = False
        # Bij een open popup is de slider leidend, ook als de tray elke 2 s leest.
        if volume_window[0] is None and volume_pending[0] is None:
            volume_item.set_label(f'Uitspraakvolume… ({selected_volume()}%)')
        chosen_example_speech = selected_example_speech()
        chosen_normalization = selected_audio_normalization()
        selected = selected_themes()
        direction = selected_direction()
        synchronizing[0] = True
        try:
            if normalization_item.get_active() != chosen_normalization:
                normalization_item.set_active(chosen_normalization)
            if examples_item.get_active() != chosen_example_speech:
                examples_item.set_active(chosen_example_speech)
            for theme_id, item in theme_items.items():
                if item.get_active() != (theme_id in selected):
                    item.set_active(theme_id in selected)
            if not direction_items[direction].get_active():
                direction_items[direction].set_active(True)
        finally:
            synchronizing[0] = False
        if not args.socket.exists():
            Gtk.main_quit()
            return False
        return True

    update_menu()
    menu.show_all()
    GLib.timeout_add_seconds(2, update_menu)

    # De status van v6.48 is hersteld: AppIndicator eerst, slechts bij
    # ontbrekende ondersteuning terugvallen op het oude Gtk.StatusIcon.
    if Indicator:
        icon_name = str(ICON) if ICON.is_file() else 'applications-education'
        indicator = Indicator.Indicator.new('russische-woordflitser', icon_name,
                                            Indicator.IndicatorCategory.APPLICATION_STATUS)
        indicator.set_menu(menu)
        indicator.set_status(Indicator.IndicatorStatus.ACTIVE)
    else:
        icon = (Gtk.StatusIcon.new_from_file(str(ICON)) if ICON.is_file()
                else Gtk.StatusIcon.new_from_icon_name('applications-education'))
        icon.set_tooltip_text('Russische Woordflitser')
        icon.set_visible(True)
        icon.connect('activate', lambda *_: send('show'))
        def popup_menu(icon, button, when):
            menu.popup(None, None, Gtk.StatusIcon.position_menu, icon, button, when)
        icon.connect('popup-menu', popup_menu)
    Gtk.main()
    return 0


if __name__ == '__main__':
    sys.exit(main())
