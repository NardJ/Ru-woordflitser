"""v6.61: losse toelichting, grotere audiozones en statusterugkoppeling."""
import json
import tempfile
import tkinter as tk
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import unittest
import russische_woordflitser as wf

class NotePersistenceTests(unittest.TestCase):
    def test_note_separate_from_translation_and_restore(self):
        with tempfile.TemporaryDirectory() as tmp:
            base=Path(tmp)
            original={'ru':'который','nl':'welke; die','context_ru':'Дом, который я вижу, большой.',
                      'context_nl':'Het huis dat ik zie is groot.','context_nl_literal':'Huis, dat ik zie, [is] groot.'}
            (base/'words.json').write_text(json.dumps([original],ensure_ascii=False),encoding='utf-8')
            with patch.object(wf,'BASE',base),patch.object(wf,'EXTRA_FILE',base/'extra.json'),patch.object(wf,'EDITS_FILE',base/'edits.json'):
                word=wf.all_words()[0]
                changes={key:word[key] for key in ('nl','context_ru','context_nl','context_nl_literal')}
                changes['toelichting']='Een betrekkelijk voornaamwoord.\nExtra uitleg op eigen regel.'
                wf.persist_word_edit(word,changes)
                loaded=wf.all_words()[0]
                self.assertEqual(loaded['nl'],'welke; die')
                self.assertEqual(loaded['toelichting'],changes['toelichting'])
                self.assertNotIn('Extra uitleg',loaded['context_nl_literal'])
                wf.persist_word_edit(word,None)
                self.assertNotIn('Extra uitleg',wf.all_words()[0].get('toelichting',''))

class NoteAudioGuiTests(unittest.TestCase):
    def setUp(self):
        self.root=tk.Tk();self.root.withdraw();self.addCleanup(self.root.destroy)
        self.word={'ru':'кото́рый','nl':'welke; die','toelichting':'Verwijzend naar een eerder genoemd woord.\nVoorbeeld van extra uitleg.',
                   'context_ru':'Дом, который я вижу, большой.','context_nl':'Het huis dat ik zie is groot.',
                   'context_nl_literal':'Huis, dat ik zie, [is] groot.'}
        self.opts={**wf.DEFAULT_SETTINGS,'play_audio_automatically':False}
    def popup(self,direction='ru-nl',word=None):
        p=wf.Popup(self.root,{**self.opts,'direction':direction});self.addCleanup(p.shutdown)
        with patch.object(p,'ensure_audio'):
            p.show(word if word is not None else self.word)
        self.root.update();return p
    def test_note_separate_layout_shifts_example_footer_and_copy(self):
        p=self.popup();self.assertGreater(p.current_height,wf.Popup.HEIGHT)
        self.assertEqual(p.canvas.itemcget('toelichting','state'),'hidden')
        p.reveal();self.assertIn('eerder genoemd',p.canvas.itemcget('toelichting','text'))
        self.assertEqual(p.canvas.itemcget('translation','text'),'welke; die')
        self.assertLess(p.canvas.bbox('toelichting')[3],p.canvas.bbox('context-ru')[1])
        self.assertLess(p.canvas.bbox('context-nl')[3],p.bar_top)
        self.assertTrue(p._copy_example_hit(SimpleNamespace(x=220,y=153+p.note_extra_height)))
        p.copy_russian_example();self.assertEqual(self.root.clipboard_get(),self.word['context_ru'])
        self.assertGreater(p.canvas.bbox('rating')[1],p.canvas.bbox('context-nl')[3])
    def test_card_without_note_is_original_size(self):
        p=self.popup(word={k:v for k,v in self.word.items() if k!='toelichting'})
        self.assertEqual(p.current_height,290)
        self.assertEqual(p.bar_top,281)
        self.assertEqual(p.canvas.itemcget('toelichting', 'state'), 'hidden')
    def test_two_audio_buttons_show_status_and_do_not_rate(self):
        p=self.popup()
        self.assertEqual(p.canvas.itemcget('audio-word-status','text'),'Woord')
        self.assertEqual(p.canvas.itemcget('audio-example-status','text'),'Zin')
        self.assertTrue(p._audio_button_hit(SimpleNamespace(x=535,y=75)))
        self.assertTrue(p._audio_button_hit(SimpleNamespace(x=535,y=190+p.note_extra_height)))
        class FakeProcess:
            def __init__(self):self.done=False
            def poll(self):return 0 if self.done else None
        process=FakeProcess()
        def speak(mode):
            p.audio_process=process
            p._set_audio_feedback(mode,'playing')
            return True
        with patch.object(p,'play_cached_voice',side_effect=lambda *a,**k:speak('word')) as word_play,patch.object(p,'play_cached_example',side_effect=lambda *a,**k:speak('example')) as example_play:
            self.assertEqual(p._click_audio_button('word'),'break')
            self.assertEqual(p.canvas.itemcget('audio-word-status','text'),'Speelt')
            self.assertEqual(p.canvas.itemcget('audio-example-status','text'),'Zin')
            word_play.assert_called_once()
            self.assertEqual(p._click_audio_button('example'),'break')
            self.assertEqual(p.canvas.itemcget('audio-example-status','text'),'Speelt')
            example_play.assert_called_once()
            process.done=True
            p._audio_feedback_poll()
            self.assertEqual(p.canvas.itemcget('audio-example-status','text'),'Zin')
        self.assertIsNone(p.rated_result)
    def test_reverse_audio_hidden_before_reveal(self):
        p=self.popup(direction='nl-ru')
        self.assertEqual(p.canvas.itemcget('audio-word','state'),'hidden')
        self.assertEqual(p.canvas.itemcget('audio-example','state'),'hidden')
        p.reveal()
        self.assertEqual(p.canvas.itemcget('audio-word','state'),'normal')
        self.assertEqual(p.canvas.itemcget('audio-example','state'),'normal')
    def test_refresh_note_add_remove_preserves_rating(self):
        w={k:v for k,v in self.word.items() if k!='toelichting'}
        p=self.popup(word=w)
        p.reveal();p.mark_good();self.assertEqual(p.current_height,290)
        w['toelichting']='Nieuwe toelichting in eigen vak.'
        p.refresh_card_text()
        self.assertEqual(p.current_height,290)  # Korte uitleg past onder betekenis.
        self.assertEqual(p.canvas.itemcget('rating','state'),'normal')
        self.assertEqual(p.canvas.itemcget('toelichting','state'),'normal')
        self.assertGreater(p.canvas.bbox('toelichting')[1], p.canvas.bbox('translation')[3])
        self.assertEqual(p.canvas.itemcget('translation','text'),w['nl'])
        w['toelichting']=''
        p.refresh_card_text()
        self.assertEqual(p.current_height,290)
        self.assertEqual(p.canvas.itemcget('rating','state'),'normal')
        self.assertEqual(p.rated_result,'good')

if __name__=='__main__':unittest.main()
