"""v6.63: audio vooruitladen, doorlopend woord→zin, compactere kaartindeling."""
import tkinter as tk
from unittest import TestCase
from unittest.mock import patch
import russische_woordflitser as wf

class FakeProcess:
    def __init__(self): self.rc=None
    def poll(self): return self.rc
    def terminate(self): self.rc=-15
    def wait(self, timeout=None): return self.rc

class CompactAudioTests(TestCase):
    def setUp(self):
        self.root=tk.Tk(); self.root.withdraw(); self.addCleanup(self.root.destroy)
        self.word={'ru':'ве́рить', 'nl':'geloven', 'toelichting':'test',
                   'context_ru':'Я хочу́ ве́рить.', 'context_nl':'Ik wil geloven.',
                   'context_nl_literal':'Ik wil geloven.'}
        self.settings={**wf.DEFAULT_SETTINGS, 'direction':'ru-nl','play_audio_automatically':False}
        self.p=wf.Popup(self.root,self.settings);self.addCleanup(self.p.shutdown)

    def show(self,word=None):
        with patch.object(self.p,'ensure_audio'):
            self.p.show(word or self.word)
        self.p.reveal()

    def test_short_note_fits_without_extra_window_height(self):
        self.show()
        self.assertEqual(self.p.current_height,wf.Popup.HEIGHT)
        self.assertGreaterEqual(self.p.canvas.bbox('toelichting')[1], self.p.canvas.bbox('translation')[3])
        self.assertLess(self.p.canvas.bbox('toelichting')[3],145)
        self.assertFalse(self.p.canvas.find_withtag('note-title'))
        self.assertEqual(self.p.canvas.bbox('context-nl')[1] - self.p.canvas.bbox('context-ru')[3],2)

    def test_long_note_increases_only_required_space(self):
        long=dict(self.word,toelichting='Dit verwijst naar een eerder zelfstandig naamwoord en verbindt twee bijzinnen.\nVoorbeeld van een lange extra uitleg.')
        self.show(long)
        self.assertGreater(self.p.note_extra_height,0)
        self.assertLess(self.p.note_extra_height,80)
        self.assertLess(self.p.canvas.bbox('toelichting')[3],self.p.canvas.bbox('context-ru')[1])

    def test_rating_feedback_is_near_header_not_off_right(self):
        self.show()
        self.p.mark_wrong()
        x1,_,x2,_=self.p.canvas.bbox('rating-feedback')
        self.assertLessEqual(x2,392)
        self.assertGreater(x1,280)
        self.assertIn('Opgeslagen',self.p.canvas.itemcget('rating-feedback','text'))

    def test_square_image_panel(self):
        word=next(w for w in wf.all_words() if w.get('image') and w.get('context_ru'))
        self.show(word)
        b=self.p.canvas.bbox('image-panel')
        self.assertLessEqual(abs((b[2]-b[0])-(b[3]-b[1])),1)
        img=self.p.canvas.bbox('revealed-image')
        self.assertLessEqual(img[2]-img[0],89)
        self.assertLessEqual(img[3]-img[1],89)

    def test_example_is_prefetched_before_word_finishes(self):
        self.p.active_word=self.word
        self.p.context_mode=True
        calls=[]
        proc=FakeProcess()
        def request(mode, keep_sequence=False):
            calls.append(('play',mode))
            self.p.audio_process=proc
            self.p.audio_feedback_state='playing'
            self.p.audio_feedback_mode=mode
        def ensure(word, play_when_ready=False,mode='auto'):
            calls.append(('prepare',mode,play_when_ready))
        with patch.object(self.p,'_request_audio', side_effect=request),patch.object(self.p,'ensure_audio',side_effect=ensure):
            self.p._start_audio_sequence(['word','example'])
        self.assertEqual(calls,[('prepare','example',False),('play','word')])

    def test_countdown_not_started_between_word_and_example(self):
        p=self.p; p.active_word=self.word; p.context_mode=True
        p.awaiting_initial_audio=True; p.audio_wait_started_at=wf.time.monotonic()
        calls=[]
        procs=[]
        def request(mode, keep_sequence=False):
            process=FakeProcess();procs.append(process)
            p.audio_process=process; p.audio_feedback_state='playing';p.audio_feedback_mode=mode
            calls.append(mode)
        with patch.object(p,'_request_audio', side_effect=request), patch.object(p,'ensure_audio') as ensure,patch.object(p,'begin_card_countdown') as countdown:
            p._start_audio_sequence(['word','example'])
            self.assertEqual(calls,['word'])
            procs[0].rc=0
            p.poll_initial_audio()
            self.assertEqual(calls,['word','example'])
            countdown.assert_not_called()
            self.assertEqual(p.audio_feedback_mode,'example')
            procs[1].rc=0
            p.poll_initial_audio()
            countdown.assert_called_once()

    def test_delayed_prefetch_result_does_not_replay_next_card(self):
        p=self.p;p.active_word=self.word;p.context_mode=True
        p.voice_requested=False;p.requested_audio_text=None
        p.audio_result_queue.append((wf.speech_path(self.word,p.settings,'example'), self.word['context_ru'],None))
        with patch.object(p,'play_cached_example') as play:
            p.check_audio_results()
        play.assert_not_called()
