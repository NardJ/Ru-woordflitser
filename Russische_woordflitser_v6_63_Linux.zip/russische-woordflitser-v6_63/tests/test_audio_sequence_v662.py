import tkinter as tk
import unittest
from types import SimpleNamespace
from unittest.mock import patch
import russische_woordflitser as wf

class FakeProcess:
    def __init__(self, rc=None):
        self.rc = rc
        self.terminated = False
    def poll(self):
        return self.rc
    def terminate(self):
        self.terminated = True
        self.rc = -15
    def wait(self, timeout=None):
        return self.rc
    def kill(self):
        self.rc = -9

class AudioSequenceTests(unittest.TestCase):
    def setUp(self):
        self.root = tk.Tk(); self.root.withdraw(); self.addCleanup(self.root.destroy)
        self.word = {'ru':'до', 'nl':'tot', 'context_ru':'До вечера!', 'context_nl':'Tot vanavond!', 'context_nl_literal':'Tot avond!'}
        self.settings = {**wf.DEFAULT_SETTINGS, 'play_audio_automatically': True, 'direction': 'ru-nl'}

    def popup(self):
        p = wf.Popup(self.root, self.settings); self.addCleanup(p.shutdown)
        return p

    def test_auto_sequence_activates_word_then_example(self):
        p = self.popup()
        p.active_word = self.word
        p.context_mode = True
        p.redraw_base()
        calls = []
        def fake_request(mode, keep_sequence=False):
            calls.append((mode, keep_sequence))
            p.audio_feedback_mode = mode
            p.audio_feedback_state = 'playing'
            p.audio_process = FakeProcess(None)
            p._refresh_audio_indicators()
        with patch.object(p, '_request_audio', side_effect=fake_request):
            p._start_audio_sequence(['word', 'example'])
            self.assertEqual(calls[0], ('word', True))
            self.assertEqual(p.canvas.itemcget('audio-word-status', 'text'), 'Speelt')
            self.assertEqual(p.canvas.itemcget('audio-example-status', 'text'), 'Zin')
            p.audio_process.rc = 0
            p._audio_feedback_poll()
            self.assertEqual(calls[1], ('example', True))
            self.assertEqual(p.canvas.itemcget('audio-word-status', 'text'), 'Woord')
            self.assertEqual(p.canvas.itemcget('audio-example-status', 'text'), 'Speelt')

    def test_manual_stop_does_not_leave_error(self):
        p = self.popup()
        p.active_word = self.word
        p.audio_feedback_mode = 'word'
        p.audio_feedback_state = 'playing'
        p.audio_process = FakeProcess(None)
        p.stop_audio()
        p._audio_feedback_poll()
        self.assertEqual(p.audio_feedback_state, 'idle')

    def test_manual_click_cancels_sequence(self):
        p = self.popup()
        p.active_word = self.word
        p.context_mode = True
        p.audio_sequence = ['example']
        p.audio_sequence_active = True
        with patch.object(p, 'play_cached_voice', return_value=False), patch.object(p, 'ensure_audio'):
            p._request_audio('word')
        self.assertFalse(p.audio_sequence_active)
        self.assertEqual(p.audio_sequence, [])

if __name__ == '__main__':
    unittest.main()
