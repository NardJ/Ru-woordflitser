"""Audio prefetch is separate from ratings and shouldn't block the popup."""
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch
import unittest
import tkinter as tk
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE))
import russische_woordflitser as wf

WORDS = [{'ru': 'приве́т', 'nl':'hallo', 'theme':'zinnen', 'context_ru':'Приве́т!', 'context_nl':'Hallo!'},
         {'ru': 'мир', 'nl':'wereld', 'theme':'natuur', 'context_ru':'Э́то мир.', 'context_nl':'Dit is de wereld.'}]

class Prefetch(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory()
        self.patch_state=patch.object(wf,'STATE_FILE',Path(self.temp.name)/'progress.json')
        self.patch_words=patch.object(wf,'all_words',return_value=WORDS)
        self.patch_state.start(); self.patch_words.start()
        self.root=tk.Tk(); self.root.withdraw()
        self.ensure_calls=[]
        self.patch_audio=patch.object(wf.Popup,'ensure_audio', lambda popup, word, play_when_ready=False, mode='auto': self.ensure_calls.append((wf.word_key(word),play_when_ready)))
        self.patch_play=patch.object(wf.Popup,'play_cached_voice',return_value=False)
        self.patch_audio.start(); self.patch_play.start()
    def tearDown(self):
        self.patch_play.stop();self.patch_audio.stop();self.root.destroy();self.patch_words.stop();self.patch_state.stop();self.temp.cleanup()
    def test_prefetch_and_reuse(self):
        settings={**wf.DEFAULT_SETTINGS,'play_audio_automatically':True, 'direction':'ru-nl'}
        app=wf.Application(self.root,settings)
        try:
            app.prefetch_next()
            self.assertIsNotNone(app.prefetched_word)
            key=wf.word_key(app.prefetched_word)
            self.assertIn((key,False),self.ensure_calls)
            app.try_popup(manual=True)
            self.assertEqual(wf.word_key(app.popup.active_word),key)
            self.assertEqual(app.sched.state['shown_total'],1)
        finally:app.shutdown()
    def test_no_prefetch_when_audio_is_off(self):
        settings={**wf.DEFAULT_SETTINGS,'play_audio_automatically':False}
        app=wf.Application(self.root,settings)
        try:
            app.prefetch_next()
            self.assertIsNone(app.prefetched_word)
            self.assertFalse(self.ensure_calls)
        finally:app.shutdown()

if __name__=='__main__': unittest.main()
