"""v6.40: Russische voorbeeldspraak in beide richtingen zonder antwoordlek."""
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import tkinter as tk
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as rf


WORD = {'ru': 'ко́шка', 'nl': 'kat', 'context_ru': 'Ко́шка спит.',
        'context_nl': 'De kat slaapt.'}


class ExampleSpeechTests(unittest.TestCase):
    def setUp(self):
        self.root = tk.Tk()
        self.root.withdraw()
        self.settings = {**rf.DEFAULT_SETTINGS, 'play_audio_automatically': False}
        self.popup = rf.Popup(self.root, self.settings)

    def tearDown(self):
        self.popup.shutdown()
        self.root.destroy()

    def test_auto_sentence_uses_distinct_cache_and_stress_normalization(self):
        voice = self.settings['voice']
        all_text = rf.automatic_speech_text(WORD, self.settings)
        self.assertEqual(rf.plain_russian(all_text), 'кошка. Кошка спит.')
        self.assertNotEqual(rf.speech_path(WORD, self.settings),
                            rf.speech_path(WORD, self.settings, 'word'))
        self.assertNotEqual(rf.speech_path(WORD, self.settings),
                            rf.speech_path(WORD, self.settings, 'example'))
        self.assertEqual(rf.speech_path(WORD, self.settings, 'example'),
                         rf.voice_cache_path(WORD['context_ru'], voice))
        self.settings['speak_examples_automatically'] = False
        self.assertEqual(rf.automatic_speech_text(WORD, self.settings), WORD['ru'])
        self.assertEqual(rf.speech_path(WORD, self.settings),
                         rf.speech_path(WORD, self.settings, 'word'))

    def test_forward_sentence_click_plays_sentence_only(self):
        with patch.object(self.popup, 'ensure_audio'):
            self.popup.show(WORD)
        self.assertEqual(self.popup.canvas.itemcget('audio-example', 'state'), 'normal')
        with patch.object(self.popup, 'play_cached_example', return_value=True) as example, \
             patch.object(self.popup, 'play_cached_voice') as word:
            self.popup.click_audio(type('Click', (), {'x': 134, 'y': 154})())
            example.assert_called_once_with(WORD)
            word.assert_not_called()
        with patch.object(self.popup, 'play_cached_voice', return_value=True) as word:
            self.popup.click_audio(type('Click', (), {'x': 35, 'y': 73})())
            word.assert_called_once_with(WORD, only_word=True)

    def test_reverse_russian_stays_silent_and_invisible_before_answer(self):
        self.popup.settings['direction'] = 'nl-ru'
        with patch.object(self.popup, 'ensure_audio'):
            self.popup.show(WORD)
        self.assertEqual(self.popup.canvas.itemcget('audio-example', 'state'), 'hidden')
        with patch.object(self.popup, 'play_cached_example') as sample:
            self.popup.click_audio(type('Click', (), {'x': 130, 'y': 154})())
            sample.assert_not_called()
        with patch.object(self.popup, 'play_cached_voice', return_value=True):
            self.popup.reveal()
        self.assertEqual(self.popup.canvas.itemcget('audio-example', 'state'), 'normal')
        with patch.object(self.popup, 'play_cached_example', return_value=True) as sample:
            self.popup.click_audio(type('Click', (), {'x': 130, 'y': 154})())
            sample.assert_called_once_with(WORD)

    def test_missing_sample_request_synthesizes_only_sample(self):
        with patch.object(self.popup, 'ensure_audio'):
            self.popup.show(WORD)
        with patch.object(self.popup, 'play_cached_example', return_value=False), \
             patch.object(self.popup, 'ensure_audio') as generate:
            self.popup.click_audio(type('Click', (), {'x': 128, 'y': 153})())
            generate.assert_called_once_with(WORD, play_when_ready=True, mode='example')

    def test_can_persist_switch_without_altering_learning_history(self):
        with tempfile.TemporaryDirectory() as tmp:
            target = Path(tmp) / 'settings.json'
            target.write_text('{"direction": "ru-nl"}', encoding='utf-8')
            with patch.object(rf, 'BASE', Path(tmp)), \
                 patch.object(rf, 'STATE_FILE', Path(tmp) / 'progress.json'), \
                 patch.object(rf, 'all_words', return_value=[WORD]):
                app = rf.Application(self.root, dict(self.settings))
                try:
                    app.handle_command('examplespeech:0')
                    self.assertFalse(app.settings['speak_examples_automatically'])
                    self.assertIn('"speak_examples_automatically": false',
                                  target.read_text())
                    app.handle_command('examplespeech:1')
                    self.assertTrue(app.settings['speak_examples_automatically'])
                finally:
                    app.shutdown()


if __name__ == '__main__':
    unittest.main()
