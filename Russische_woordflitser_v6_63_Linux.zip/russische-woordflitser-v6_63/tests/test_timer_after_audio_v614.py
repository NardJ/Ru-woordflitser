"""v6.14: leertijd begint na einde van de automatische uitspraak."""
import sys
import time
import tkinter as tk
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as rf


class FakeAudio:
    def __init__(self):
        self.finished = False
        self.terminated = False

    def poll(self):
        return 0 if self.finished else None

    def terminate(self):
        self.terminated = True
        self.finished = True


class TimerAfterAudio(unittest.TestCase):
    def setUp(self):
        self.root = tk.Tk()
        self.root.withdraw()
        self.word = {'ru': 'Я немно́го говорю́ по-ру́сски.', 'nl': 'Ik spreek een beetje Russisch'}
        self.settings = {**rf.DEFAULT_SETTINGS, 'hide_after_seconds': 9, 'play_audio_automatically': True}
        self.popup = rf.Popup(self.root, self.settings)

    def tearDown(self):
        self.popup.shutdown()
        self.root.destroy()

    def update_after_poll(self):
        time.sleep(0.18)
        self.root.update()

    def show_with_playing_audio(self):
        player = FakeAudio()
        def cached(_, only_word=False):
            self.popup.audio_process = player
            return True
        with patch.object(self.popup, 'play_cached_voice', side_effect=cached):
            self.popup.show(self.word)
        return player

    def test_long_audio_does_not_use_up_any_countdown_or_reveal_time(self):
        player = self.show_with_playing_audio()
        self.assertIsNone(self.popup.hide_deadline)
        self.assertIsNone(self.popup.card_shown_at)
        self.assertIsNone(self.popup.reveal_timer_id)
        self.assertEqual(self.popup.canvas.itemcget('countdown-label', 'text'), 'Luisteren…')
        self.update_after_poll()
        self.assertIsNone(self.popup.hide_deadline)
        self.assertFalse(self.popup.revealed)
        player.finished = True
        self.update_after_poll()
        self.assertIsNotNone(self.popup.hide_deadline)
        self.assertAlmostEqual(self.popup.hide_deadline - time.monotonic(), 9.0, delta=.4)
        self.assertEqual(self.popup.canvas.itemcget('countdown-label', 'text'), 'Antwoord over 3 s')
        self.assertFalse(self.popup.revealed)

    def test_new_generated_voice_waits_until_generated_audio_is_complete(self):
        player = FakeAudio()
        p = rf.voice_cache_path(rf.spoken_russian(self.word), str(self.settings['voice']))
        with patch.object(self.popup, 'play_cached_voice', return_value=False), \
             patch.object(self.popup, 'ensure_audio') as request:
            self.popup.show(self.word)
        request.assert_called_once()
        self.assertTrue(self.popup.voice_requested)
        self.assertIsNone(self.popup.hide_deadline)
        def now_plays(_, only_word=False):
            self.popup.audio_process = player
            return True
        with patch.object(self.popup, 'play_cached_voice', side_effect=now_plays), \
             patch.object(rf.Path, 'is_file', return_value=True):
            self.popup.audio_result_queue.append((p, rf.spoken_russian(self.word), None))
            self.popup.check_audio_results()
        self.assertFalse(self.popup.voice_requested)
        self.assertIsNone(self.popup.hide_deadline)
        self.update_after_poll()
        self.assertIsNone(self.popup.hide_deadline)
        player.finished = True
        self.update_after_poll()
        self.assertIsNotNone(self.popup.hide_deadline)

    def test_no_audio_generation_after_timeout_starts_countdown_without_late_autoplay(self):
        with patch.object(self.popup, 'play_cached_voice', return_value=False), \
             patch.object(self.popup, 'ensure_audio'):
            self.popup.show(self.word)
        self.popup.audio_wait_started_at = time.monotonic() - 21
        self.popup.poll_initial_audio()
        self.assertIsNotNone(self.popup.hide_deadline)
        self.assertFalse(self.popup.voice_requested)
        self.assertFalse(self.popup.awaiting_initial_audio)

    def test_failed_audio_generation_immediately_starts_countdown(self):
        with patch.object(self.popup, 'play_cached_voice', return_value=False), \
             patch.object(self.popup, 'ensure_audio'):
            self.popup.show(self.word)
        self.popup.audio_result_queue.append((rf.speech_path(self.word, self.settings, mode='word'), rf.spoken_russian(self.word), 'failed'))
        self.popup.check_audio_results()
        self.assertIsNotNone(self.popup.hide_deadline)
        self.assertFalse(self.popup.voice_requested)

    def test_know_during_audio_stops_countdown_and_reveals(self):
        player = self.show_with_playing_audio()
        self.popup.mark_known()
        self.assertTrue(self.popup.revealed)
        self.assertIsNone(self.popup.hide_deadline)
        self.assertIsNone(self.popup.audio_wait_timer_id)
        player.finished = True
        self.update_after_poll()
        self.assertIsNone(self.popup.hide_deadline)
        self.assertEqual(self.popup.canvas.itemcget('countdown-label', 'text'), '')
        self.assertIsNone(self.popup.rated_result)

    def test_next_or_right_click_during_audio_cancels_all_callbacks(self):
        player = self.show_with_playing_audio()
        self.popup.next_card()
        self.assertTrue(player.terminated)
        self.assertIsNone(self.popup.active_word)
        self.assertIsNone(self.popup.audio_wait_timer_id)
        self.update_after_poll()
        self.assertIsNone(self.popup.hide_deadline)

    def test_countdown_choice_while_listening_applies_after_audio(self):
        player = self.show_with_playing_audio()
        self.popup.set_countdown_seconds(15)
        self.assertIsNone(self.popup.hide_deadline)
        player.finished = True
        self.update_after_poll()
        self.assertAlmostEqual(self.popup.hide_deadline - time.monotonic(), 15, delta=.4)

    def test_autoplay_disabled_starts_immediately(self):
        self.settings['play_audio_automatically'] = False
        with patch.object(self.popup, 'ensure_audio'):
            self.popup.show(self.word)
        self.assertIsNotNone(self.popup.hide_deadline)
        self.assertIsNotNone(self.popup.reveal_timer_id)

if __name__ == '__main__':
    unittest.main()
