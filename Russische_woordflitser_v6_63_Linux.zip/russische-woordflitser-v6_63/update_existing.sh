#!/usr/bin/env bash
# Upgrade an existing installation without touching saved audio or word progress.
set -euo pipefail
if [[ $# -ne 1 ]]; then
  echo 'Gebruik: ./update_existing.sh /pad/naar/bestaande/russische-woordflitser' >&2
  exit 2
fi
SOURCE="$(cd -- "$(dirname -- "$0")" && pwd -P)"
# Eerst alle Python-bestanden valideren; een onvolledig pakket mag de oude
# werkende installatie niet uitschakelen.
python3 -m py_compile "$SOURCE/russische_woordflitser.py" \
  "$SOURCE/tray_icon.py" "$SOURCE/tray_xapp.py" \
  "$SOURCE/settings_migration.py"
TARGET="$(cd -- "$1" && pwd -P)"
if [[ "$SOURCE" == "$TARGET" ]]; then
  echo 'Geef de map van de *oude* installatie op, niet de nieuwe uitgepakte map.' >&2
  exit 2
fi
if [[ ! -f "$TARGET/russische_woordflitser.py" || ! -f "$TARGET/start.sh" || ! -f "$TARGET/settings.json" ]]; then
  echo "Geen bestaande woordflitser-installatie gevonden in: $TARGET" >&2
  exit 2
fi
RUNNING=0
if ( cd "$TARGET" && ./start.sh --status ) | grep -q '^Draait'; then
  RUNNING=1
  ( cd "$TARGET" && ./start.sh --stop )
  for i in {1..20}; do
    if ! ( cd "$TARGET" && ./start.sh --status ) | grep -q '^Draait'; then
      break
    fi
    sleep .25
  done
  if ( cd "$TARGET" && ./start.sh --status ) | grep -q '^Draait'; then
    echo 'Oude woordflitser draait nog; update gestopt om problemen te voorkomen.' >&2
    exit 1
  fi
fi
STAMP="$(date +%Y%m%d-%H%M%S)"
# Bewaar ook de echte leerhistorie, buiten de installatiemap.
DATA_ROOT="${XDG_DATA_HOME:-$HOME/.local/share}"
PROGRESS="$DATA_ROOT/russische-woordflitser/progress.json"
if [[ -f "$PROGRESS" ]]; then
  cp -p -- "$PROGRESS" "$PROGRESS.backup-$STAMP"
  echo "Reservekopie leerhistorie: $PROGRESS.backup-$STAMP"
fi
cp -p -- "$TARGET/russische_woordflitser.py" "$TARGET/russische_woordflitser.py.backup-$STAMP"
cp -p -- "$TARGET/settings.json" "$TARGET/settings.json.backup-$STAMP"
# Eigen wijzigingen staan apart in ~/.local/share; laat ze onaangeroerd.
CORRECTIONS="$DATA_ROOT/russische-woordflitser/woordcorrecties.json"
if [[ -f "$CORRECTIONS" ]]; then
  cp -p -- "$CORRECTIONS" "$CORRECTIONS.backup-$STAMP"
  echo "Reservekopie eigen woordcorrecties: $CORRECTIONS.backup-$STAMP"
fi
# Maak ook een reservekopie van de oude woordenlijst. Voeg nieuwe woorden toe
# zonder ooit eerder opgeslagen kaarten of handmatig toegevoegde woorden te wissen.
if [[ -f "$TARGET/words.json" ]]; then
  cp -p -- "$TARGET/words.json" "$TARGET/words.json.backup-$STAMP"
fi
python3 - "$TARGET/words.json" "$SOURCE/words.json" "$SOURCE/BEELDCONTROLE_V6_18.json" "$SOURCE/MIGRATIE_LABELS_V6_17.json" <<'PYWORDS'
import json, pathlib, sys, re
old_path, new_path, audit_path, labels_path = (pathlib.Path(x) for x in sys.argv[1:])
audit = json.loads(audit_path.read_text(encoding='utf-8'))
removed_images = {item['ru'].replace('\u0301','').casefold(): item['oude_afbeelding'] for item in audit['aangepaste_koppelingen']}
previous_labels = json.loads(labels_path.read_text(encoding='utf-8'))
old = json.loads(old_path.read_text(encoding='utf-8')) if old_path.exists() else []
new = json.loads(new_path.read_text(encoding='utf-8'))
if not isinstance(old, list) or not isinstance(new, list):
    raise SystemExit('words.json bevat geen lijst; update gestopt')
def key(w):
    if w.get('theme') == 'verwarring' and w.get('exercise_id'):
        return 'verwarring:' + str(w['exercise_id'])
    raw = w['ru'].replace('\u0301', '').strip().casefold()
    # Oude cursusfout раста́ть / я расту́ was bedoeld als расти́.
    if raw == 'растать' and w.get('nl') == 'groeien' and w.get('ik') == 'я расту́':
        return 'расти'
    return raw
result = []
keys = set()
# De nieuwe basislijst bepaalt de volgorde; bestaande versies van dezelfde
# woorden behouden hun eerdere betekenis/illustratie en dus hun leerhistorie.
old_by_key = {key(w): w for w in old if isinstance(w, dict) and w.get('ru') and w.get('nl')}
for word in new + old:
    if not isinstance(word, dict) or not word.get('ru') or not word.get('nl'):
        continue
    k = key(word)
    if k in keys:
        continue
    old_word = old_by_key.get(k)
    # Nieuwe voorbeelden worden toegevoegd, maar bestaande eigen gegevens blijven bewaard.
    merged = {**word, **old_word} if old_word else dict(word)
    # v6.60 geeft alle standaardvoorbeelden nieuwe leervertalingen. Het
    # oude gegevensveld mag deze uitbreiding niet overschrijven (ook niet
    # bij de 48 kaarten die al in v6.59 een letterlijke vertaling hadden).
    # Heeft iemand de Russische voorbeeldzin zelf gewijzigd, dan hoort de
    # nieuwe standaardvertaling niet meer bij die aangepaste zin.
    if old_word:
        if old_word.get('context_ru') == word.get('context_ru'):
            merged['context_nl_literal'] = word.get('context_nl_literal', '')
        else:
            if 'context_nl_literal' not in old_word:
                merged.pop('context_nl_literal', None)
    # Persoonlijke wijzigingen in woordcorrecties.json worden niet geraakt.

    # Verfijningen uit de gecontroleerde basislijst mogen oude onjuiste labels
    # en standaardillustraties vervangen. Persoonlijke vertalingen en eigen
    # afbeeldingen blijven intact.
    if old_word:
        previous_label = old_word.get('nl', '').strip().lower()
        if k == 'свой' and previous_label == 'eigen; zijn eigen':
            merged['nl'] = word['nl']
        if k == 'опять' and previous_label == 'weer':
            merged['nl'] = word['nl']
        if k == 'бежать' and previous_label == 'rennen':
            merged['nl'] = word['nl']
        if k == 'бегать' and previous_label in ('hardlopen; rennen (herhaald)',
                                                  'herhaald rennen'):
            merged['nl'] = word['nl']
        # Vervang alleen standaardvertalingen; een zelf aangepaste vertaling
        # blijft ongewijzigd.
        if k in previous_labels and old_word.get('nl') == previous_labels[k]:
            merged['nl'] = word['nl']
        # Grammaticale correctie: behoud leer-ID via afzonderlijke migratie.
        if k == 'расти' and old_word.get('ru', '').replace('\u0301','') == 'растать':
            merged['ru'] = word['ru']
            merged['ik'] = word['ik']
        old_image = old_word.get('image', '')
        new_image = word.get('image', '')
        if k in removed_images and old_image == removed_images[k]:
            merged.pop('image', None)
        elif new_image and (not old_image or
                          re.match(r'^images/(?:n_\d{3}|v_\d{4})\.png$', old_image)):
            merged['image'] = new_image
    result.append(merged)
    keys.add(k)
tmp = old_path.with_suffix('.json.tmp')
tmp.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
tmp.replace(old_path)
print(f'Woordenlijst bijgewerkt: {len(result)} unieke items (bestaande woorden behouden)')
PYWORDS
# Geen bestaande instellingen aanpassen, ook geen automatische thematoevoeging.
# Controleer eerst de JSON; bij een fout wordt de update afgebroken.
python3 "$SOURCE/settings_migration.py" "$TARGET/settings.json"
cp -- "$SOURCE/russische_woordflitser.py" "$TARGET/russische_woordflitser.py"
cp -- "$SOURCE/frequentie.py" "$TARGET/frequentie.py"
cp -- "$SOURCE/tray_icon.py" "$TARGET/tray_icon.py"
cp -- "$SOURCE/tray_xapp.py" "$TARGET/tray_xapp.py"
cp -- "$SOURCE/naamvallen_oefeningen.json" "$TARGET/naamvallen_oefeningen.json"
cp -- "$SOURCE/naamvallen.md" "$TARGET/naamvallen.md"
cp -- "$SOURCE/settings_migration.py" "$TARGET/settings_migration.py"
mkdir -p -- "$TARGET/images"
# Neem alle meegeleverde PNG-afbeeldingen mee; bestaande eigen afbeeldingen
# blijven intact. Illustratiebestanden met een nieuw versienummer krijgen
# een andere naam, waardoor andere persoonlijke assets niet worden overschreven.
added_images=0
for image in "$SOURCE"/images/*.png; do
  name="${image##*/}"
  if [[ ! -f "$TARGET/images/$name" ]]; then
    cp -- "$image" "$TARGET/images/$name"
    added_images=$((added_images + 1))
  fi
done
# De tray-afbeelding is een app-asset en mag wel worden bijgewerkt.
cp -- "$SOURCE/images/tray_icon.png" "$TARGET/images/tray_icon.png"
printf '%s nieuwe afbeeldingen toegevoegd.\n' "$added_images"
cp -- "$SOURCE/README.md" "$TARGET/README.md"
cp -- "$SOURCE/AFBEELDINGEN_EN_LICENTIES.md" "$TARGET/AFBEELDINGEN_EN_LICENTIES.md"
# Zet de ene foutief gespelde Russische vorm ook om in opgeslagen scores.
# De update heeft hierboven een reservekopie gemaakt.
if [[ -f "$PROGRESS" ]]; then
  python3 - "$PROGRESS" <<'PYPROGRESS'
import json, pathlib, sys
path = pathlib.Path(sys.argv[1]); state = json.loads(path.read_text(encoding='utf-8'))
words = state.get('words', {})
if isinstance(words, dict) and 'растать' in words:
    old = words.pop('растать')
    if 'расти' not in words or old.get('last_seen', 0) > words['расти'].get('last_seen', 0):
        words['расти'] = old
    state['recent_keys'] = [('расти' if x == 'растать' else x)
                            for x in state.get('recent_keys', [])]
    tmp = path.with_suffix('.json.tmp')
    tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    tmp.replace(path)
    print('Leerhistorie van de gecorrigeerde vorm расти́ behouden.')
PYPROGRESS
fi

# De rangschikking wordt buiten de popup uit een echte corpusbron geladen.
# Bij een netwerkstoring blijft de bestaande leerhistorie intact en wordt een
# kleine, handmatig gecontroleerde offline-rangschikking gebruikt.
printf 'Frequentiegegevens ophalen (eenmalig, internet nodig)...\n'
if ( cd "$TARGET" && ./start.sh --refresh-frequency ); then
  echo 'Corpusfrequenties voor huidige kaarten geactiveerd.'
else
  echo 'Waarschuwing: internetbron tijdelijk niet bereikbaar. Offline topwoorden actief.'
  echo 'Probeer later: ./start.sh --refresh-frequency'
fi
printf 'Bijgewerkt: %s\n' "$TARGET"
printf 'Oude code en instellingen zijn als .backup-%s bewaard.\n' "$STAMP"
if [[ "$RUNNING" -eq 1 ]]; then
  ( cd "$TARGET" && ./start.sh --background )
fi
echo 'v6.63 geïnstalleerd: audio woord→zin wordt vooruitgeladen, compacte toelichting en vierkant afbeeldingsvak; voortgang en instellingen behouden.' 
echo 'Voortgang bekijken: cd "<bestaande-map>" && ./start.sh --progress'
