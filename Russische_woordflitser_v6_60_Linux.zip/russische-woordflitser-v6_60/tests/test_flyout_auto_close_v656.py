"""v6.56: submenu flyouts dismiss on pointer exit, with no 'Terug' row."""
import unittest
from types import SimpleNamespace
from test_xapp_menu_v651 import TestMenu

class TestFlyoutAutoClose(unittest.TestCase):
    def setUp(self):
        self.fixture = TestMenu(methodName='test_single_icon_and_all_pages')
        self.fixture.setUp()
        self.menu = self.fixture.menu
        self.menu.toggle(900, 20, self.menu.Gtk.PositionType.TOP)
        self.menu.opening = False
        self.menu.navigate('themes')

    def tearDown(self):
        self.fixture.tearDown()

    def fire_pending(self):
        ident = self.menu.flyout_close_source
        self.assertIsNotNone(ident)
        callback = self.fixture.sources.pop(ident)
        callback()

    def test_back_rows_removed_and_timing_inline(self):
        pages = [self.menu.home_page] + self.menu.stack.children
        def all_widgets(w):
            yield w
            for child in w.children:
                yield from all_widgets(child)
            if w.child is not None:
                yield from all_widgets(w.child)
        labels = [w.label for page in pages for w in all_widgets(page)]
        self.assertFalse(any('Terug' in label for label in labels))
        self.assertEqual(len(self.menu.stack.children), 4)
        self.assertEqual(set(self.menu.timing_expanders), {'countdown','ratio'})
        self.assertEqual(len(self.menu.countdown_buttons),6)
        self.assertEqual(len(self.menu.ratio_buttons),9)
        self.menu.timing_expanders['countdown'].set_expanded(True)
        self.menu.timing_expanders['ratio'].set_expanded(True)
        self.assertFalse(self.menu.timing_expanders['countdown'].get_expanded())
        self.assertTrue(self.menu.timing_expanders['ratio'].get_expanded())

    def test_hover_another_root_without_flyout_closes_only_flyout(self):
        root = next(widget for widget in self.menu.home_page.children
                    if widget is not self.menu.menu_anchors['themes']
                    and 'enter-notify-event' in widget.connections
                    and widget not in self.menu.menu_anchors.values())
        root.emit('enter-notify-event', SimpleNamespace())
        self.assertEqual(self.menu.active_page,'home')
        self.assertFalse(self.menu.flyout_window.get_visible())
        self.assertTrue(self.menu.window.get_visible())
        self.assertFalse(self.fixture.commands)

    def test_hover_another_submenu_switches_in_place(self):
        x,y=self.menu.window.get_position()
        self.menu.menu_anchors['speech'].emit('enter-notify-event', SimpleNamespace())
        self.assertEqual(self.menu.active_page,'speech')
        self.assertTrue(self.menu.flyout_visible)
        self.assertEqual(self.menu.window.get_position(),(x,y))

    def test_pointer_outside_both_closes_after_short_delay(self):
        self.menu._pointer_position=lambda: (20,900)
        self.menu.on_menu_leave()
        self.assertTrue(self.menu.flyout_visible) # no premature collapse
        self.fire_pending()
        self.assertFalse(self.menu.flyout_visible)
        self.assertFalse(self.menu.window.get_visible())

    def test_crossing_from_main_anchor_to_flyout_does_not_close(self):
        self.menu._pointer_position=lambda: (20,900)
        self.menu.menu_anchors['themes'].emit('leave-notify-event',SimpleNamespace())
        self.assertIsNotNone(self.menu.flyout_close_source)
        self.menu.on_flyout_enter()
        self.assertIsNone(self.menu.flyout_close_source)
        self.assertTrue(self.menu.flyout_visible)

    def test_pointer_inside_flyout_does_not_close(self):
        wx,wy=self.menu.flyout_window.get_position()
        self.menu._pointer_position=lambda: (wx+10,wy+10)
        self.menu.on_menu_leave()
        self.fire_pending()
        self.assertTrue(self.menu.flyout_visible)

    def test_timing_settings_still_send_commands(self):
        self.menu.navigate('timing')
        self.menu.timing_expanders['countdown'].set_expanded(True)
        self.menu.countdown_buttons[13].set_active(True)
        self.assertIn('countdown:13',self.fixture.commands)
        self.menu.timing_expanders['ratio'].set_expanded(True)
        self.menu.ratio_buttons[4].set_active(True)
        self.assertIn('newratio:4',self.fixture.commands)

if __name__ == '__main__':unittest.main()
