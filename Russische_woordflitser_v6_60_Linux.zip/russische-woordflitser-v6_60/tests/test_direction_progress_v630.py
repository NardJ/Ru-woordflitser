"""v6.30: NL→RU and RU→NL have independent scores, due dates and review counts."""
import contextlib
import io
import tempfile
import tkinter as tk
import unittest
from pathlib import Path
from unittest.mock import patch
import russische_woordflitser as rf
import tray_icon

WORDS = [{'ru': 'ко́шка', 'nl': 'kat'}, {'ru': 'соба́ка', 'nl': 'hond'},
         {'ru': 'дом', 'nl': 'huis'}, {'ru': 'окно́', 'nl': 'raam'}]


class SeparateDirectionsTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.progress = Path(self.temp.name) / 'progress.json'
        self.patches = [patch.object(rf, 'STATE_FILE', self.progress),
                        patch.object(tray_icon, 'PROGRESS_FILE', self.progress)]
        for p in self.patches: p.start()

    def tearDown(self):
        for p in reversed(self.patches): p.stop()
        self.temp.cleanup()

    def test_legacy_migration_keeps_all_original_progress(self):
        old = {'shown_total': 100, 'cards_since_new': 2, 'words': {
            'кошка': {'last_result': 'good', 'successes': 3, 'good_streak': 2,
                      'shown_count': 5, 'next_due_other_count': 120},
            'собака': {'last_result': 'wrong', 'failures': 2, 'shown_count': 3}},
            'recent_keys': ['кошка', 'собака'], 'scheduler_version': 2}
        rf.save_json(self.progress, old)
        reverse = rf.Scheduler(WORDS, direction='nl-ru')
        self.assertEqual(reverse.vocabulary_score(), 0)
        self.assertEqual(reverse.introduced(), 0)
        self.assertEqual(reverse.state['shown_total'], 0)
        stored = rf.load_json(self.progress, {})
        for key, old_value in old['words'].items():
            self.assertEqual(stored['words'][key], old_value)
        self.assertEqual(stored['shown_total'], 100)
        self.assertEqual(stored['recent_keys'], old['recent_keys'])
        self.assertEqual(reverse.vocabulary_score('ru-nl'), 1)

    def test_same_word_has_independent_ratings_count_and_repeats(self):
        s = rf.Scheduler(WORDS)
        key = rf.word_key(WORDS[0])
        s.note_shown(WORDS[0]); s.record_result(WORDS[0], 'good')
        self.assertEqual(s.vocabulary_score(), 1)
        self.assertEqual(s.state['words'][key]['next_due_other_count'], 10)
        s.set_direction('nl-ru')
        self.assertEqual(s.vocabulary_score(), 0)
        self.assertIn(key, [rf.word_key(w) for w in WORDS if rf.word_key(w) not in s.state['words']])
        s.note_shown(WORDS[0]); s.record_result(WORDS[0], 'wrong')
        self.assertEqual(s.state['words'][key]['next_due_other_count'], 3)
        self.assertEqual(s.state['shown_total'], 1)
        self.assertEqual(s.vocabulary_score('ru-nl'), 1)
        self.assertEqual(s.vocabulary_score('nl-ru'), 0)
        s.set_direction('ru-nl')
        self.assertEqual(s.state['words'][key]['last_result'], 'good')
        self.assertEqual(s.state['words'][key]['next_due_other_count'], 10)
        self.assertEqual(s.state['shown_total'], 1)
        s2 = rf.Scheduler(WORDS, direction='nl-ru')
        self.assertEqual(s2.state['words'][key]['last_result'], 'wrong')
        s2.record_result(WORDS[0], 'good')
        self.assertEqual(s2.vocabulary_score('nl-ru'), 1)
        self.assertEqual(s2.vocabulary_score('ru-nl'), 1)
        self.assertEqual(tray_icon.read_vocabulary_score('ru-nl'), 1)
        self.assertEqual(tray_icon.read_vocabulary_score('nl-ru'), 1)

    def test_cli_shows_two_directions(self):
        s = rf.Scheduler(WORDS)
        s.note_shown(WORDS[0]); s.record_result(WORDS[0], 'good')
        s.set_direction('nl-ru')
        s.note_shown(WORDS[1]); s.record_result(WORDS[1], 'wrong')
        out = io.StringIO()
        with contextlib.redirect_stdout(out): rf.show_progress()
        content = out.getvalue()
        self.assertIn('RU → NL:', content)
        self.assertIn('NL → RU:', content)
        self.assertEqual(content.count('Woordenschat-score:'), 2)

    def test_switch_while_card_open_saves_rating_to_old_direction(self):
        base = Path(self.temp.name)
        (base/'settings.json').write_text('{"direction":"ru-nl"}')
        root = tk.Tk(); root.withdraw()
        settings = {**rf.DEFAULT_SETTINGS, 'play_audio_automatically': False}
        with patch.object(rf, 'BASE', base), patch.object(rf, 'all_words', return_value=WORDS):
            app = rf.Application(root, settings, once=True)
            try:
                with patch.object(app.popup, 'ensure_audio'):
                    app.try_popup(manual=True)
                word = app.popup.active_word
                self.assertEqual(app.popup.direction, 'ru-nl')
                app.set_direction('nl-ru')
                self.assertEqual(app.sched.direction, 'ru-nl')
                app.popup.reveal(); app.popup.mark_good()
                self.assertEqual(app.sched.vocabulary_score('ru-nl'), 1)
                self.assertEqual(app.sched.vocabulary_score('nl-ru'), 0)
                app.popup.hide(result='dismissed')
                self.assertEqual(app.sched.direction, 'nl-ru')
                self.assertEqual(app.popup.vocabulary_count, 0)
                with patch.object(app.popup, 'ensure_audio'):
                    app.try_popup(manual=True)
                self.assertEqual(app.popup.direction, 'nl-ru')
                self.assertEqual(app.popup.vocabulary_count, 0)
                app.popup.reveal(); app.popup.mark_wrong()
                self.assertEqual(app.sched.vocabulary_score('ru-nl'), 1)
                self.assertEqual(app.sched.vocabulary_score('nl-ru'), 0)
            finally:
                app.shutdown(); root.destroy()

    def test_switch_from_nl_ru_to_ru_nl_does_not_change_first_rating(self):
        base = Path(self.temp.name)
        (base/'settings.json').write_text('{"direction":"nl-ru"}')
        root = tk.Tk(); root.withdraw()
        settings = {**rf.DEFAULT_SETTINGS, 'direction': 'nl-ru', 'play_audio_automatically': False}
        with patch.object(rf, 'BASE', base), patch.object(rf, 'all_words', return_value=WORDS):
            app = rf.Application(root, settings, once=True)
            try:
                with patch.object(app.popup, 'ensure_audio'):
                    app.try_popup(manual=True)
                app.popup.reveal()
                app.set_direction('ru-nl')
                app.popup.mark_good()
                self.assertEqual(app.sched.vocabulary_score('nl-ru'), 1)
                self.assertEqual(app.sched.vocabulary_score('ru-nl'), 0)
                app.popup.hide(result='dismissed')
                self.assertEqual(app.sched.direction, 'ru-nl')
                self.assertEqual(app.popup.vocabulary_count, 0)
            finally:
                app.shutdown(); root.destroy()


if __name__ == '__main__': unittest.main()
