"""Regressies voor verslepen zonder conflicten met audio en knoppen."""
import sys
import tempfile
import tkinter as tk
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as rf


class DragTests(unittest.TestCase):
    def setUp(self):
        self.root = tk.Tk()
        self.root.withdraw()
        opts = {**rf.DEFAULT_SETTINGS,
                'play_audio_automatically': False,
                'hide_after_seconds': 30,
                'reveal_after_seconds': 3}
        self.popup = rf.Popup(self.root, opts)
        self.results = []
        with patch.object(self.popup, 'ensure_audio'):
            self.popup.show({'ru': 'до́м', 'nl': 'huis'},
                            lambda word, result: self.results.append(result))
        self.root.update()

    def tearDown(self):
        self.popup.shutdown()
        self.root.destroy()

    @staticmethod
    def e(x, y, root_x, root_y):
        return SimpleNamespace(x=x, y=y, x_root=root_x, y_root=root_y)

    def test_drag_moves_popup_without_playing_audio(self):
        self.popup.win.geometry('420x235+150+135')
        self.root.update()
        with patch.object(self.popup, 'click_audio') as audio:
            self.popup.begin_drag(self.e(40, 19, 190, 154))
            self.popup.drag_motion(self.e(80, 60, 290, 229))
            self.popup.end_drag(self.e(80, 60, 290, 229))
            self.root.update()
            self.assertEqual((self.popup.win.winfo_x(), self.popup.win.winfo_y()), (250, 210))
            audio.assert_not_called()
        self.assertTrue(self.popup.position_initialized)
        self.assertIsNotNone(self.popup.active_word)

    def test_normal_click_still_plays_audio(self):
        with patch.object(self.popup, 'click_audio') as audio:
            self.popup.begin_drag(self.e(160, 67, 220, 160))
            self.popup.end_drag(self.e(160, 67, 220, 160))
            audio.assert_called_once()

    def test_small_mouse_jitter_is_click(self):
        with patch.object(self.popup, 'click_audio') as audio:
            self.popup.begin_drag(self.e(160, 67, 220, 160))
            self.popup.drag_motion(self.e(162, 69, 222, 162))
            self.popup.end_drag(self.e(162, 69, 222, 162))
            audio.assert_called_once()

    def test_rating_button_does_not_start_drag(self):
        self.popup.reveal()
        self.popup.canvas.event_generate('<ButtonPress-1>', x=246, y=270)
        self.root.update()
        self.assertEqual(self.popup.rated_result, 'good')
        self.assertIsNone(self.popup.drag_origin)
        self.popup.canvas.event_generate('<ButtonRelease-1>', x=246, y=270)
        self.root.update()
        self.assertIsNotNone(self.popup.active_word)

    def test_right_click_still_dismisses(self):
        self.popup.canvas.event_generate('<ButtonPress-3>', x=40, y=19)
        self.root.update()
        self.assertIsNone(self.popup.active_word)
        self.assertEqual(self.results, ['dismissed'])

    def test_next_preserves_moved_position(self):
        self.popup.win.geometry('420x235+100+100')
        self.root.update()
        self.popup.begin_drag(self.e(40, 19, 140, 119))
        self.popup.drag_motion(self.e(65, 44, 220, 185))
        self.popup.end_drag(self.e(65, 44, 220, 185))
        self.root.update()
        position = self.popup.win.geometry()
        with patch.object(self.popup, 'ensure_audio'):
            self.popup.show({'ru': 'окно́', 'nl': 'raam'},
                            preserve_position=True)
        self.root.update()
        self.assertEqual(self.popup.win.geometry(), position)

    def test_canvas_real_event_sequence_moves_window(self):
        """Controleer Tk eventafhandeling, niet alleen directe methode-aanroepen."""
        self.popup.win.geometry('420x235+200+200')
        self.root.update()
        self.popup.canvas.event_generate('<ButtonPress-1>', x=32, y=20,
                                         rootx=232, rooty=220)
        self.popup.canvas.event_generate('<B1-Motion>', x=92, y=80,
                                         rootx=292, rooty=280, state=256)
        self.popup.canvas.event_generate('<ButtonRelease-1>', x=92, y=80,
                                         rootx=292, rooty=280)
        self.root.update()
        self.assertEqual((self.popup.win.winfo_x(), self.popup.win.winfo_y()), (260, 260))

    def test_next_button_still_fires(self):
        self.popup.canvas.event_generate('<ButtonPress-1>', x=405, y=270)
        self.root.update()
        self.assertIsNone(self.popup.active_word)
        self.assertEqual(self.results, ['next'])


if __name__ == '__main__':
    unittest.main()
