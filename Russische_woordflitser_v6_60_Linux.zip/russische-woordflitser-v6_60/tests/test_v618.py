import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import tkinter as tk
import unittest

from PIL import Image

HERE = Path(__file__).resolve().parent.parent
OLD = Path('/mnt/data/woordflitser-dev/russische-woordflitser-v6_17')


def clean(s):
    return s.replace('\u0301', '').casefold()


class Upgrade618(unittest.TestCase):
    def setUp(self):
        self.words = json.loads((HERE/'words.json').read_text(encoding='utf8'))
        self.lookup = {clean(w['ru']):w for w in self.words if w.get('theme') != 'verwarring'}

    def test_1000_words_and_29_verb_contexts(self):
        self.assertEqual(len(self.words),1090)
        self.assertEqual(len(self.lookup),1066)
        self.assertEqual(sum(w.get('type')=='functiewoord / bijwoord' and bool(w.get('context_ru')) for w in self.words),150)
        self.assertGreaterEqual(sum(w.get('type')=='werkwoord' and bool(w.get('context_ru')) for w in self.words),29)
        for key in ('бежать','бегать','идти','ходить','ехать','ездить','лететь','летать','плыть','плавать','нести','носить','слушать','слышать','смотреть','видеть','одеть','надеть'):
            word=self.lookup[key]
            self.assertTrue(word.get('context_ru'))
            self.assertTrue(word.get('context_nl'))
        self.assertEqual(self.lookup['расти']['ik'],'я расту́')
        self.assertNotIn('растать',self.lookup)

    def test_illustration_integrity_and_review(self):
        audit=json.loads((HERE/'BEELDCONTROLE_V6_18.json').read_text())
        self.assertEqual(audit['gecontroleerde_koppelingen'],757)
        self.assertEqual(len(audit['aangepaste_koppelingen']),30)
        self.assertEqual(sum(bool(w.get('image')) for w in self.words),802)
        for bad in audit['aangepaste_koppelingen']:
            self.assertNotEqual(self.lookup[clean(bad['ru'])].get('image'), bad['oude_afbeelding'])
        for w in self.words:
            if w.get('image'):
                path=HERE/w['image']
                self.assertTrue(path.is_file(),w['ru'])
                with Image.open(path) as im:
                    self.assertEqual(im.width,im.height)
                    self.assertGreaterEqual(im.width,164)
                    im.verify()

    def test_popup_label_is_neutral_and_reveal_not_rating(self):
        s=(HERE/'russische_woordflitser.py').read_text()
        self.assertNotIn("text='Ik weet het'",s)
        self.assertIn("text='Toon antwoord'",s)
        spec=importlib.util.spec_from_file_location('russian_v618',HERE/'russische_woordflitser.py')
        m=importlib.util.module_from_spec(spec)
        sys.modules[spec.name]=m
        spec.loader.exec_module(m)
        rt=tk.Tk();rt.withdraw()
        try:
            settings=m.load_settings();settings['play_audio_automatically']=False
            p=m.Popup(rt,settings)
            try:
                events=[]
                p.on_rated=lambda word,result:events.append(result)
                p.show(self.lookup['тот'])
                rt.update_idletasks()
                self.assertEqual(p.canvas.itemcget('translation','text'),'')
                self.assertTrue(p.canvas.find_withtag('know'))
                p.mark_known();rt.update_idletasks()
                self.assertEqual(p.canvas.itemcget('translation','text'),self.lookup['тот']['nl'])
                self.assertFalse(events)
                p.mark_wrong();self.assertEqual(events,['wrong'])
            finally:p.shutdown()
        finally:rt.destroy()

    @unittest.skipUnless((OLD / "russische_woordflitser.py").is_file(), "historische v6.17-testbestanden ontbreken")
    def test_updater_preserves_custom_and_migrates_misprint(self):
        with tempfile.TemporaryDirectory() as td:
            tmp=Path(td);target=tmp/'old';target.mkdir()
            for f in ('russische_woordflitser.py','start.sh','settings.json'):
                shutil.copy2(OLD/f,target/f)
            # Use fake start to avoid the live desktop app.
            (target/'start.sh').write_text('#!/bin/sh\necho "Niet actief"\n')
            (target/'start.sh').chmod(0o755)
            oldwords=json.loads((OLD/'words.json').read_text())
            for w in oldwords:
                if clean(w['ru'])=='ходить':w['nl']='MIJN EIGEN VERTALING'
            oldwords.append({'ru':'тестово́е','nl':'eigen woord','image':'images/zelf.png'})
            (target/'words.json').write_text(json.dumps(oldwords,ensure_ascii=False))
            (target/'images').mkdir()
            (target/'images'/'zelf.png').write_bytes(b'custom')
            folder=tmp/'data'/'russische-woordflitser';folder.mkdir(parents=True)
            progress={'shown_total':61,'recent_keys':['растать','кошка'], 'words':{
                'растать': {'last_result':'good','shown_count':3, 'successes':2,'last_seen':11},
                'кошка': {'last_result':'wrong','shown_count':4}}}
            (folder/'progress.json').write_text(json.dumps(progress,ensure_ascii=False))
            result=subprocess.run([str(HERE/'update_existing.sh'),str(target)],
                env={**os.environ,'XDG_DATA_HOME':str(tmp/'data')},capture_output=True,text=True,timeout=45)
            self.assertEqual(result.returncode,0,(result.stdout,result.stderr))
            after=json.loads((target/'words.json').read_text())
            self.assertEqual(len(after),1067)
            d={clean(w['ru']):w for w in after}
            self.assertEqual(d['ходить']['nl'],'MIJN EIGEN VERTALING')
            self.assertTrue(d['ходить'].get('context_ru'))
            self.assertEqual(d['идти']['nl'],'lopen / gaan (nu, één richting)')
            self.assertEqual(d['расти']['ik'],'я расту́')
            self.assertNotIn('растать',d)
            self.assertFalse(d['пятница'].get('image'))
            self.assertFalse(d['шея'].get('image'))
            self.assertEqual(d['тестовое']['image'],'images/zelf.png')
            self.assertEqual((target/'images'/'zelf.png').read_bytes(),b'custom')
            updated_progress=json.loads((folder/'progress.json').read_text())
            self.assertEqual(updated_progress['shown_total'],61)
            self.assertEqual(updated_progress['words']['расти']['last_result'],'good')
            self.assertNotIn('растать',updated_progress['words'])
            self.assertTrue(list(folder.glob('progress.json.backup-*')))

if __name__=='__main__':unittest.main()
