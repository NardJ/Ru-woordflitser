"""v6.7: tray interval commands persist and re-schedule without a restart."""
from pathlib import Path
import sys
import tempfile
import threading
import time
import tkinter as tk
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as rf
import tray_icon

WORDS = [{'ru': f'слово{i}', 'nl': f'woord{i}'} for i in range(12)]

class IntervalSettingsTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.base = Path(self.temp.name)
        (self.base/'settings.json').write_text('''{"interval_minutes": 30, "popup_opacity": 0.72,
                "voice": "ru-RU-SvetlanaNeural", "my_extra_option": true}''')
        self.patches = [
            patch.object(rf, 'BASE', self.base),
            patch.object(rf, 'STATE_FILE', self.base/'progress.json'),
            patch.object(rf, 'PAUSE_FILE', self.base/'pause.txt'),
            patch.object(rf, 'CONTROL_SOCKET', self.base/'control.sock'),
            patch.object(rf, 'all_words', return_value=WORDS),
            patch.object(tray_icon, 'SETTINGS_FILE', self.base/'settings.json'),
        ]
        for obj in self.patches:
            obj.start()
        self.root = tk.Tk()
        self.root.withdraw()
        self.app = rf.Application(self.root, {**rf.DEFAULT_SETTINGS, 'interval_minutes': 30,
                                              'play_audio_automatically': False})
        self.mock_audio = patch.object(self.app.popup, 'ensure_audio')
        self.mock_audio.start()

    def tearDown(self):
        self.mock_audio.stop()
        self.app.shutdown()
        self.root.destroy()
        for obj in reversed(self.patches):
            obj.stop()
        self.temp.cleanup()

    def test_immediate_persist_keep_other_settings(self):
        old_due = self.app.next_due_at
        self.app.handle_command('interval:5')
        self.assertEqual(self.app.settings['interval_minutes'], 5)
        self.assertGreater(old_due, self.app.next_due_at)
        self.assertAlmostEqual(self.app.next_due_at - time.monotonic(), 300, delta=1.0)
        data = rf.load_settings()
        self.assertEqual(data['interval_minutes'], 5)
        self.assertEqual(data['popup_opacity'], 0.72)
        self.assertEqual(rf.load_json(self.base/'settings.json', {})['my_extra_option'], True)
        self.assertEqual(tray_icon.selected_interval(), 5)
        # Restart: new App inherits saved config.
        self.assertEqual(rf.load_settings()['interval_minutes'], 5)

    def test_all_valid_intervals_and_bad_commands(self):
        for value in rf.INTERVAL_CHOICES:
            self.app.handle_command('interval:' + str(value))
            self.assertEqual(self.app.settings['interval_minutes'], value)
            self.assertEqual(tray_icon.selected_interval(), value)
        for bad in ('interval:-1', 'interval:999', 'interval:hello', 'interval:'):
            with self.assertRaises(ValueError):
                self.app.handle_command(bad)
        self.assertEqual(self.app.settings['interval_minutes'], 60)

    def test_session_and_learned_progress_unaffected(self):
        self.app.sched.note_shown(WORDS[0])
        self.app.sched.record_result(WORDS[0], 'good')
        before = rf.load_json(rf.STATE_FILE, {})['words'][rf.word_key(WORDS[0])].copy()
        self.app.handle_command('session')
        due_before = self.app.next_due_at
        self.app.handle_command('interval:2')
        self.assertEqual(self.app.next_due_at, due_before)
        self.app.handle_command('end-session')
        self.assertAlmostEqual(self.app.next_due_at - time.monotonic(), 120, delta=1.0)
        self.assertEqual(rf.load_json(rf.STATE_FILE, {})['words'][rf.word_key(WORDS[0])], before)

    def test_socket_from_tray_to_owner(self):
        with patch.object(rf.subprocess, 'Popen'):
            self.app.start_controls()
        result = []
        worker = threading.Thread(target=lambda: result.append(rf.send_control('interval:10')))
        worker.start()
        for _ in range(40):
            self.root.update()
            if result:
                break
            time.sleep(.01)
        worker.join(timeout=1)
        self.assertEqual(result, [True])
        self.assertEqual(self.app.settings['interval_minutes'], 10)
        self.assertEqual(tray_icon.selected_interval(), 10)

if __name__ == '__main__':
    unittest.main()
