"""Regression for visible countdown, Good/Fout cancellation, cursor position after Next."""
import sys
import tempfile
import time
from pathlib import Path
import tkinter as tk
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as rf

class CountdownTests(unittest.TestCase):
    def setUp(self):
        self.root = tk.Tk()
        self.root.withdraw()
        self.settings = {**rf.DEFAULT_SETTINGS,
                         'play_audio_automatically': False,
                         'reveal_after_seconds': 0.03,
                         'hide_after_seconds': 2.3}
        self.popup = rf.Popup(self.root, self.settings)
        self.events = []
        with patch.object(self.popup, 'ensure_audio'):
            self.popup.show({'ru': 'ко́шка', 'nl': 'kat'},
                            lambda word, result: self.events.append(result))
        self.root.update()

    def tearDown(self):
        self.popup.shutdown()
        self.root.destroy()

    def test_countdown_visible_and_decreases(self):
        self.assertEqual(self.popup.canvas.itemcget('countdown-label', 'text'), 'Antwoord over 1 s')
        self.assertAlmostEqual(self.popup.canvas.coords('countdown-fill')[2], self.popup.BAR_RIGHT, delta=3)
        time.sleep(1.35)
        self.root.update()
        self.root.after(175, self.root.quit)
        self.root.mainloop()
        self.assertEqual(self.popup.canvas.itemcget('countdown-label', 'text'), '')
        self.assertTrue(100 < self.popup.canvas.coords('countdown-fill')[2] < 438)
        self.assertIsNotNone(self.popup.active_word)

    def test_good_halts_countdown_until_user_closes(self):
        self.popup.reveal()
        self.popup.mark_good()
        self.assertIsNone(self.popup.hide_deadline)
        self.assertIsNone(self.popup.countdown_timer_id)
        self.assertEqual(self.popup.canvas.itemcget('countdown-label', 'text'), '')
        self.assertEqual(self.popup.canvas.itemcget('rating-feedback', 'state'), 'normal')
        self.popup.next_card()
        self.root.update()
        self.assertEqual(self.events, ['next:good'])

    def test_wrong_halts_countdown_until_user_closes(self):
        self.popup.reveal()
        self.popup.mark_wrong()
        self.assertEqual(self.popup.canvas.itemcget('countdown-label', 'text'), '')
        self.assertEqual(self.popup.canvas.itemcget('rating-feedback', 'state'), 'normal')
        self.assertIsNone(self.popup.countdown_timer_id)

class FixedPositionTests(unittest.TestCase):
    def test_next_stays_at_same_place_after_pointer_moves_and_timer_resets(self):
        words = [{'ru': f'слово{i}', 'nl': f'woord{i}'} for i in range(5)]
        with tempfile.TemporaryDirectory() as tmp, \
             patch.object(rf, 'STATE_FILE', Path(tmp)/'progress.json'), \
             patch.object(rf, 'all_words', return_value=words):
            root = tk.Tk()
            root.withdraw()
            options = {**rf.DEFAULT_SETTINGS, 'play_audio_automatically': False,
                       'hide_after_seconds': 9}
            app = rf.Application(root, options)
            try:
                with patch.object(app.popup, 'ensure_audio'), \
                     patch.object(root, 'winfo_pointerxy', return_value=(150, 180)), \
                     patch.object(rf, 'monitor_under_pointer', return_value=(0, 0, 1800, 1000)):
                    app.try_popup(manual=True)
                root.update()
                position = app.popup.win.geometry()
                first_deadline = app.popup.hide_deadline
                first = rf.word_key(app.popup.active_word)
                with patch.object(root, 'winfo_pointerxy', return_value=(1100, 700)), \
                     patch.object(rf, 'monitor_under_pointer', return_value=(0, 0, 1800, 1000)):
                    app.popup.next_card()
                    root.update()
                self.assertEqual(app.popup.win.geometry(), position)
                self.assertNotEqual(rf.word_key(app.popup.active_word), first)
                self.assertIsNotNone(app.popup.countdown_timer_id)
                self.assertGreater(app.popup.hide_deadline, first_deadline)
                self.assertEqual(app.popup.canvas.itemcget('countdown-label', 'text'), 'Antwoord over 3 s')
            finally:
                app.shutdown()
                root.destroy()

if __name__ == '__main__':
    unittest.main()
