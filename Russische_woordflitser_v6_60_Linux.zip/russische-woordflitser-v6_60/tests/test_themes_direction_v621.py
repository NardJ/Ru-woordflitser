"""Themakeuze, voorbeeldzinnen en veilige NL->RU richting."""
import json
import tempfile
from pathlib import Path
from unittest import TestCase, main
from unittest.mock import patch
import tkinter as tk
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as app
import tray_icon

BASE = Path(__file__).resolve().parents[1]

class ThemesAndDirectionTests(TestCase):
    def test_1000_tagged_and_phrase_separate(self):
        data = json.loads((BASE/'words.json').read_text())
        self.assertEqual(len(data), 1090)
        self.assertEqual(len({app.word_key(w) for w in data}), 1090)
        self.assertTrue(all(w['theme'] in app.THEME_IDS for w in data))
        self.assertEqual(sum(w['theme']=='zinnen' for w in data),101)
        self.assertEqual(sum(w['theme']=='handelingen' for w in data),252)
        self.assertEqual(len(app.eligible_words(data,{'selected_themes':['zinnen']})),101)
        self.assertEqual(len(app.eligible_words(data,{'selected_themes':['handelingen']})),252)
        self.assertGreater(len(app.eligible_words(data,{'selected_themes':['reizen']})),43)
        self.assertEqual(len(app.eligible_words(data,{'selected_themes':['eten','reizen']})),len({app.word_key(w) for w in app.eligible_words(data,{'selected_themes':['eten','reizen']})}))
        self.assertFalse(any(w['theme']=='zinnen' for w in app.eligible_words(data,{'selected_themes':['eten','reizen']})))
        self.assertEqual(len(app.eligible_words(data,{'selected_themes':[]})),0)
        self.assertEqual(len(app.eligible_words(data,{})),1066)  # RU→NL negeert verwarringsvragen

    def test_scheduler_only_offers_enabled_theme_without_losing_scores(self):
        words=json.loads((BASE/'words.json').read_text())
        with tempfile.TemporaryDirectory() as td, patch.object(app,'STATE_FILE', Path(td)/'history.json'):
            sched=app.Scheduler(words)
            sched.note_shown(words[0])
            sched.record_result(words[0],'good')
            previous=sched.vocabulary_score()
            for theme in ('zinnen','natuur','grammatica'):
                for _ in range(14):
                    chosen=sched.choose({'new_word_every':3,'selected_themes':[theme]},manual=True)
                    self.assertIn(theme,chosen.get('themes',[chosen['theme']]))
                    sched.note_shown(chosen)
            self.assertEqual(previous,1)
            self.assertEqual(sched.state['words'][app.word_key(words[0])]['last_result'],'good')

    def test_live_settings_are_persistent_without_resetting_progress(self):
        with tempfile.TemporaryDirectory() as td:
            root=tk.Tk();root.withdraw()
            target=Path(td)/'settings.json'
            target.write_text('{"interval_minutes": 5}')
            with patch.object(app,'BASE',Path(td)),patch.object(app,'STATE_FILE',Path(td)/'progress.json'), patch.object(app,'all_words',return_value=json.loads((BASE/'words.json').read_text())):
                instance=app.Application(root,app.load_settings())
                try:
                    instance.set_theme('zinnen',False)
                    instance.set_direction('nl-ru')
                    saved=json.loads(target.read_text())
                    self.assertEqual(saved['direction'],'nl-ru')
                    self.assertNotIn('zinnen',saved['selected_themes'])
                    self.assertEqual(saved['interval_minutes'],5)
                    self.assertRaises(ValueError, instance.set_direction,'foo')
                    for name in app.THEME_IDS:
                        if name != 'mensen':
                            instance.set_theme(name,False)
                    instance.set_theme('mensen',False)
                    self.assertEqual(instance.settings['selected_themes'], [])
                finally:
                    instance.shutdown();root.destroy()

    def test_reverse_prompt_hides_russian_audio_and_context_until_reveal(self):
        words=json.loads((BASE/'words.json').read_text())
        word=next(w for w in words if app.word_key(w)=='тот')
        root=tk.Tk();root.withdraw()
        settings={**app.DEFAULT_SETTINGS,'direction':'nl-ru', 'play_audio_automatically':True}
        with patch.object(app,'audio_path_for_word',return_value=None), patch.object(app,'voice_cache_path', return_value=BASE/'no-audio.mp3'):
            p=app.Popup(root,settings)
            try:
                with patch.object(p,'ensure_audio') as ensure, patch.object(p,'play_cached_voice',return_value=False) as play:
                    p.show(word)
                    root.update_idletasks()
                    self.assertEqual(p.canvas.itemcget('russian','text'), word['nl'])
                    self.assertEqual(p.canvas.itemcget('context-ru','text'),word['context_nl'])
                    self.assertEqual(p.canvas.itemcget('translation','text'),'')
                    self.assertEqual(p.canvas.itemcget('context-nl','text'),'')
                    self.assertFalse(p.awaiting_initial_audio)
                    self.assertFalse(play.called)
                    p.click_audio(type('Event',(),{'y':84,'x':52})())
                    self.assertFalse(play.called)
                    p.mark_known()
                    self.assertEqual(p.canvas.itemcget('translation','text'),app.displayed_russian(word))
                    self.assertEqual(p.canvas.itemcget('context-nl','text'),word['context_ru'])
                    self.assertTrue(play.called)
                    self.assertTrue(ensure.called)
                    self.assertIsNone(p.rated_result)
            finally:p.shutdown();root.destroy()

    def test_forward_prompt_and_audio_unchanged(self):
        words=json.loads((BASE/'words.json').read_text())
        word=next(w for w in words if app.word_key(w)=='тот')
        root=tk.Tk();root.withdraw()
        p=app.Popup(root,{**app.DEFAULT_SETTINGS,'direction':'ru-nl','play_audio_automatically':False})
        try:
            with patch.object(p,'ensure_audio'):
                p.show(word)
                self.assertEqual(p.canvas.itemcget('russian','text'),word['ru'])
                self.assertEqual(p.canvas.itemcget('context-ru','text'),word['context_ru'])
                p.reveal()
                self.assertEqual(p.canvas.itemcget('translation','text'),word['nl'])
                self.assertEqual(p.canvas.itemcget('context-nl','text'),word.get('context_nl_literal') or word['context_nl'])
        finally:p.shutdown();root.destroy()

if __name__=='__main__':main()
