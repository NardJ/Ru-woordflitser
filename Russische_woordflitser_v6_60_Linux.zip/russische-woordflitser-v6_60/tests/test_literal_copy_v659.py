"""v6.59: RU→NL letterlijke voorbeelden, kopieerknop en leerhistorie."""
import json
import tempfile
import tkinter as tk
from pathlib import Path
from types import SimpleNamespace
import unittest
from unittest.mock import patch

import russische_woordflitser as wf


class LiteralExampleTests(unittest.TestCase):
    def setUp(self):
        self.root = tk.Tk()
        self.root.withdraw()
        self.addCleanup(self.root.destroy)
        self.w = {
            'ru': 'весь', 'nl': 'heel; geheel; alle',
            'context_ru': 'Весь день идёт дождь.',
            'context_nl': 'Het regent de hele dag.',
            'context_nl_literal': 'Hele dag komt regen.',
        }
        self.opts = {**wf.DEFAULT_SETTINGS, 'play_audio_automatically': False}

    def popup(self, direction='ru-nl', word=None):
        p = wf.Popup(self.root, {**self.opts, 'direction': direction})
        self.addCleanup(p.shutdown)
        with patch.object(p, 'ensure_audio'):
            p.show(word or self.w)
        self.root.update()
        return p

    def test_ru_nl_shows_literal_not_natural(self):
        p = self.popup()
        p.reveal()
        self.assertEqual(p.canvas.itemcget('context-ru', 'text'), self.w['context_ru'])
        self.assertEqual(p.canvas.itemcget('context-nl', 'text'), self.w['context_nl_literal'])

    def test_fallback_without_literal(self):
        p = self.popup(word={k: v for k, v in self.w.items() if k != 'context_nl_literal'})
        p.reveal()
        self.assertEqual(p.canvas.itemcget('context-nl', 'text'), self.w['context_nl'])

    def test_reverse_uses_natural_and_hides_copy_before_reveal(self):
        p = self.popup(direction='nl-ru')
        self.assertEqual(p.canvas.itemcget('context-ru', 'text'), self.w['context_nl'])
        self.assertEqual(p.canvas.itemcget('copy-example', 'state'), 'hidden')
        p.copy_russian_example()
        p.reveal()
        self.assertEqual(p.canvas.itemcget('context-nl', 'text'), self.w['context_ru'])
        self.assertEqual(p.canvas.itemcget('copy-example', 'state'), 'normal')
        p.copy_russian_example()
        self.assertEqual(self.root.clipboard_get(), self.w['context_ru'])

    def test_copy_button_no_audio_or_drag_and_does_not_affect_rating(self):
        p = self.popup()
        self.assertFalse(p._copy_example_hit(SimpleNamespace(x=165,y=154)))
        self.assertTrue(p._copy_example_hit(SimpleNamespace(x=220,y=153)))
        with patch.object(p, 'click_audio') as speak:
            p.begin_drag(SimpleNamespace(x=220, y=153))
            self.assertIsNone(p.drag_origin)
            self.assertEqual(p.copy_russian_example(), 'break')
            p.end_drag(SimpleNamespace(x=220,y=153))
            speak.assert_not_called()
        self.assertEqual(self.root.clipboard_get(), self.w['context_ru'])
        self.assertEqual(p.canvas.itemcget('copy-example','text'),'✓ Gekopieerd')
        self.assertIsNone(p.rated_result)
        self.assertFalse(p.revealed)
        self.assertFalse(p.rating_saved)
        # Clicking the Canvas item really triggers the copy handler.
        p.canvas.itemconfigure('copy-example', text='⧉ Kopieer')
        p.canvas.event_generate('<ButtonPress-1>', x=220,y=155)
        self.root.update()
        self.assertEqual(p.canvas.itemcget('copy-example','text'),'✓ Gekopieerd')

    def test_case_exercise_copies_unmarked_original_sentence(self):
        case_word = {'ru':'naamval:test:1', 'nl':'instrumentalis', 'theme':'naamvallen',
                     'case':'I', 'target':'ма́мой', 'cue':'с + wie?',
                     'context_ru':'Я с ма́мой.', 'context_nl':'Ik ben met mama.',
                     'lemma':'мама', 'type':'vrouwelijk', 'why':'s + instrumentalis'}
        p = self.popup(word=case_word)
        self.assertIn('«', p.canvas.itemcget('context-ru','text'))
        p.copy_russian_example()
        self.assertEqual(self.root.clipboard_get(), 'Я с ма́мой.')


class LiteralEditTests(unittest.TestCase):
    def test_literal_persists_and_old_three_field_edits_remain_compatible(self):
        with tempfile.TemporaryDirectory() as folder:
            base=Path(folder)
            word={'ru':'весь', 'nl':'heel', 'context_ru':'Весь день идёт дождь.',
                  'context_nl':'Het regent de hele dag.',
                  'context_nl_literal':'Hele dag komt regen.'}
            (base/'words.json').write_text(json.dumps([word],ensure_ascii=False),encoding='utf-8')
            with patch.object(wf,'BASE',base), patch.object(wf,'EDITS_FILE',base/'woordcorrecties.json'), patch.object(wf,'EXTRA_FILE',base/'extra.json'):
                loaded=wf.all_words()[0]
                wf.persist_word_edit(loaded, {**{key:loaded[key] for key in ('nl','context_ru','context_nl')}, 'context_nl_literal':'De hele dag gaat regen.'})
                self.assertEqual(wf.all_words()[0]['context_nl_literal'],'De hele dag gaat regen.')
                wf.persist_word_edit(loaded, {key:loaded[key] for key in ('nl','context_ru','context_nl')})
                self.assertEqual(wf.all_words()[0]['context_nl_literal'],'De hele dag gaat regen.')
                wf.persist_word_edit(loaded, None)
                self.assertEqual(wf.all_words()[0]['context_nl_literal'],'Hele dag komt regen.')

if __name__ == '__main__':
    unittest.main()
