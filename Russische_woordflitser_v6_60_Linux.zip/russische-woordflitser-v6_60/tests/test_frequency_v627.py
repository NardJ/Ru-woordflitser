import csv
import io
import json
from pathlib import Path
import sys
import tempfile
from unittest import TestCase
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as app
import frequentie as freq

class FrequencyTests(TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.cache = Path(self.tmp.name) / 'frequency_ranks.json'
        self.patch_data = patch.object(app, 'FREQUENCY_FILE', self.cache)
        self.patch_state = patch.object(app, 'STATE_FILE', Path(self.tmp.name) / 'progress.json')
        self.patch_data.start();self.patch_state.start()
    def tearDown(self):
        self.patch_data.stop();self.patch_state.stop();self.tmp.cleanup()
    def test_all_legacy_cards_and_additions_unique(self):
        words = app.all_words()
        self.assertGreaterEqual(len(words),1066)
        keys=[app.word_key(w) for w in words]
        self.assertEqual(len(keys),len(set(keys)))
        self.assertIn('возить',keys)
        self.assertIn('верить',keys)
        self.assertIn('если',keys)
    def test_stress_and_yo(self):
        self.assertEqual(freq.get_lemma({'ru':'чёрный'}),'черный')
        self.assertEqual(freq.get_lemma({'ru':'вози́ть'}),'возить')
        self.assertEqual(freq.get_lemma({'ru':'До свида́ния!'}),'')
    def test_lemma_frequency_parsing(self):
        out=io.StringIO();writer=csv.writer(out,delimiter='\t');writer.writerow(['Lemma','PoS','Freq(ipm)','R','D','Doc'])
        for i in range(10001): writer.writerow([f'слово{i}', 's', '1.0','100','90','10'])
        writer.writerow(['верить','v','50.0','100','99','900'])
        writer.writerow(['возить','v','4.0','90','80','200'])
        writer.writerow(['верить','s.PROP','1000.0','95','85','100'])
        corpus=freq.parse_rnc_csv(out.getvalue().encode('utf8'))
        self.assertGreater(corpus['верить']['ipm'],corpus['возить']['ipm'])
        self.assertLess(corpus['верить']['rank'],corpus['возить']['rank'])
    def test_frequent_word_precedes_rare_word_and_prior_scores_keep(self):
        words=[{'ru':'ве́рить','nl':'geloven','fase':2},
               {'ru':'вози́ть','nl':'vervoeren','fase':1},
               {'ru':'е́сли','nl':'als','fase':1}]
        self.cache.write_text(json.dumps({'source':freq.SOURCE, 'entries':{
            'верить':{'ipm':50.,'rank':568},'возить':{'ipm':4.,'rank':4328},
            'если':{'ipm':500.,'rank':53}}}))
        sched=app.Scheduler(words)
        first=sched.choose({'new_word_every':5,'selected_themes':None})
        self.assertEqual(app.word_key(first),'если')
        sched.note_shown(first);sched.record_result(first,'good')
        self.assertEqual(sched.vocabulary_score(),1)
        sched2=app.Scheduler(words)
        self.assertEqual(sched2.vocabulary_score(),1)
        second=sched2.choose({'new_word_every':2,'selected_themes':None})
        self.assertEqual(app.word_key(second),'верить')
    def test_ratio_and_wrong_priority_unchanged(self):
        words=app.all_words()[:10]
        sched=app.Scheduler(words)
        chosen=sched.choose({'new_word_every':5})
        sched.note_shown(chosen);sched.record_result(chosen,'wrong')
        self.assertEqual(sched.state['words'][app.word_key(chosen)]['last_result'],'wrong')
        self.assertEqual(sched.vocabulary_score(),0)
