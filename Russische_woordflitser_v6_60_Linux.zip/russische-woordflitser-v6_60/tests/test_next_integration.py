"""End-to-end Tk test of the Volgende action and persisted counters."""
import tempfile
from pathlib import Path
import tkinter as tk
import unittest
from unittest.mock import patch
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as rf


class TestNextIntegration(unittest.TestCase):
    def test_next_opens_different_card_and_updates_ratio(self):
        words = [{'ru': f'слово{i}', 'nl': f'woord{i}'} for i in range(10)]
        with tempfile.TemporaryDirectory() as tmp, patch.object(rf, 'STATE_FILE', Path(tmp)/'progress.json'), \
             patch.object(rf, 'all_words', return_value=words):
            root = tk.Tk(); root.withdraw()
            try:
                options = {**rf.DEFAULT_SETTINGS, 'play_audio_automatically': False}
                app = rf.Application(root, options)
                with patch.object(app.popup, 'ensure_audio'):
                    app.try_popup(manual=True)
                    self.assertIsNotNone(app.popup.active_word)
                    first = rf.word_key(app.popup.active_word)
                    app.popup.next_card()
                    root.update()
                    self.assertIsNotNone(app.popup.active_word)
                    second = rf.word_key(app.popup.active_word)
                    self.assertNotEqual(first, second)
                    self.assertEqual(app.sched.state['shown_total'], 2)
                    self.assertEqual(app.sched.state['new_total'], 2)
                    self.assertEqual(app.sched.state['words'][first]['last_result'], 'exposed')
                    # Rapid Next is still paced by cards shown, not by time.
                    for _ in range(4):
                        previous = rf.word_key(app.popup.active_word)
                        app.popup.next_card()
                        root.update()
                        self.assertNotEqual(rf.word_key(app.popup.active_word), previous)
                    self.assertEqual(app.sched.state['shown_total'], 6)
                    self.assertEqual(app.sched.state['new_total'], 2)
                    app.popup.next_card()
                    root.update()
                    self.assertEqual(app.sched.state['new_total'], 3)
                    self.assertEqual(app.sched.state['shown_total'], 7)
                    # A Good rating followed by Next advances immediately.
                    app.popup.reveal()
                    prior = rf.word_key(app.popup.active_word)
                    app.popup.mark_good()
                    app.popup.next_card()
                    root.update()
                    self.assertEqual(app.sched.state['words'][prior]['last_result'], 'good')
                    self.assertNotEqual(rf.word_key(app.popup.active_word), prior)
            finally:
                app.shutdown()
                root.destroy()

if __name__ == '__main__':
    unittest.main()
