"""Checks for cursor-local, on-monitor popup placement (GUI-free)."""
import sys
from pathlib import Path
import unittest
sys.path.insert(0, str(Path(__file__).parents[1]))
import russische_woordflitser as rp


class TestPlacement(unittest.TestCase):
    def test_two_monitor_xrandr_output(self):
        sample = '''Monitors: 2
 0: +*DP-1 1920/520x1080/290+0+0  DP-1
 1: +HDMI-1 2560/601x1440/337+1920+0  HDMI-1
'''
        self.assertEqual(rp.parse_xrandr_monitors(sample),
                         [(0, 0, 1920, 1080), (1920, 0, 2560, 1440)])

    def test_cursor_and_monitor_edge_positions(self):
        rect = (1920, 0, 2560, 1440)
        width, height = 398, 172
        for px, py in [(1921, 2), (1921, 1438), (4478, 1438),
                       (4478, 2), (3200, 800), (4300, 900)]:
            with self.subTest(pointer=(px, py)):
                x, y = rp.place_near_cursor(px, py, width, height, rect)
                self.assertGreaterEqual(x, 1920)
                self.assertGreaterEqual(y, 0)
                self.assertLessEqual(x+width, 4480)
                self.assertLessEqual(y+height, 1440)
                self.assertFalse(x <= px <= x+width and y <= py <= y+height,
                                 'The pointer should never be covered')

    def test_small_screen_fallback_stays_visible(self):
        x, y = rp.place_near_cursor(20, 20, 398, 172, (0, 0, 480, 300))
        self.assertGreaterEqual(x, 0)
        self.assertGreaterEqual(y, 0)
        self.assertLessEqual(x+398, 480)
        self.assertLessEqual(y+172, 300)

if __name__ == '__main__':
    unittest.main()
