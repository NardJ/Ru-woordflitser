"""v6.9: early 'Ik weet het', correction, tray countdown and persistence."""
import sys
import tempfile
import time
from pathlib import Path
from unittest.mock import patch
import tkinter as tk
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as rf
import tray_icon

WORDS = [{'ru': 'окно́', 'nl': 'raam'}, {'ru': 'дом', 'nl': 'huis'},
         {'ru': 'дверь', 'nl': 'deur'}, {'ru': 'во́да', 'nl': 'water'}]

class EarlyKnownTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.base = Path(self.tmp.name)
        (self.base/'settings.json').write_text('{"popup_opacity": 0.85, "hide_after_seconds": 9}')
        self.mocks = [patch.object(rf, 'BASE', self.base),
                      patch.object(rf, 'STATE_FILE', self.base/'progress.json'),
                      patch.object(rf, 'all_words', return_value=WORDS),
                      patch.object(tray_icon, 'SETTINGS_FILE', self.base/'settings.json')]
        for mock in self.mocks: mock.start()
        self.root = tk.Tk()
        self.root.withdraw()
        self.app = rf.Application(self.root, {
            **rf.DEFAULT_SETTINGS, 'play_audio_automatically': False,
            'reveal_after_seconds': 2.0, 'hide_after_seconds': 9,
        }, once=True)
        self.audio_mock = patch.object(self.app.popup, 'ensure_audio')
        self.audio_mock.start()
        self.app.try_popup(manual=True)
        self.root.update()

    def tearDown(self):
        self.audio_mock.stop()
        self.app.shutdown()
        self.root.destroy()
        for mock in reversed(self.mocks): mock.stop()
        self.tmp.cleanup()

    def test_early_button_visible_only_before_reveal(self):
        c = self.app.popup.canvas
        self.assertIn(c.itemcget('know', 'state'), ('', 'normal'))
        self.assertEqual(c.itemcget('rating', 'state'), 'hidden')
        self.assertEqual(c.itemcget('translation', 'text'), '')
        self.app.popup.reveal()
        self.assertEqual(c.itemcget('know', 'state'), 'hidden')
        self.assertEqual(c.itemcget('rating', 'state'), 'normal')

    def test_know_reveals_immediately_and_waits_for_explicit_wrong(self):
        popup = self.app.popup
        word = popup.active_word
        popup.canvas.event_generate('<Button-1>', x=169, y=270)
        self.root.update()
        self.assertIsNone(popup.rated_result)
        self.assertFalse(popup.rating_saved)
        self.assertTrue(popup.revealed)
        self.assertEqual(popup.canvas.itemcget('translation', 'text'), word['nl'])
        self.assertEqual(popup.canvas.itemcget('countdown-label', 'text'), '')
        self.assertIsNone(popup.hide_deadline)
        self.assertIsNone(popup.reveal_timer_id)
        self.assertEqual(rf.vocabulary_score(rf.load_json(rf.STATE_FILE, {})), 0)
        self.assertEqual(popup.canvas.itemcget('know', 'state'), 'hidden')
        self.assertEqual(popup.canvas.itemcget('wrong', 'state'), 'normal')
        self.assertEqual(popup.canvas.itemcget('good', 'state'), 'normal')
        popup.canvas.event_generate('<Button-1>', x=92, y=270)
        self.root.update()
        self.assertEqual(popup.rated_result, 'wrong')
        self.assertEqual(rf.vocabulary_score(rf.load_json(rf.STATE_FILE, {})), 0)
        key = rf.word_key(word)
        self.assertEqual(rf.load_json(rf.STATE_FILE, {})['words'][key]['last_result'], 'wrong')

    def test_know_then_good_increases_score_exactly_once(self):
        popup = self.app.popup
        w = popup.active_word
        popup.mark_known()
        self.assertEqual(rf.vocabulary_score(rf.load_json(rf.STATE_FILE, {})), 0)
        popup.canvas.event_generate('<Button-1>', x=246, y=270)
        self.root.update()
        self.assertEqual(popup.rated_result, 'good')
        self.assertEqual(rf.load_json(rf.STATE_FILE, {})['words'][rf.word_key(w)]['last_result'], 'good')
        self.assertEqual(rf.Scheduler(WORDS).vocabulary_score(), 1)
        popup.canvas.event_generate('<Button-1>', x=246, y=270)
        self.assertEqual(rf.Scheduler(WORDS).vocabulary_score(), 1)

    def test_know_then_next_does_not_record_good(self):
        popup = self.app.popup
        w = popup.active_word
        popup.mark_known()
        popup.next_card()
        self.root.update()
        entry = rf.load_json(rf.STATE_FILE, {})['words'][rf.word_key(w)]
        self.assertNotEqual(entry.get('last_result'), 'good')
        self.assertEqual(rf.Scheduler(WORDS).vocabulary_score(), 0)

    def test_know_then_close_does_not_record_good(self):
        popup = self.app.popup
        w = popup.active_word
        popup.mark_known()
        popup.close_current_card()
        self.root.update()
        entry = rf.load_json(rf.STATE_FILE, {})['words'][rf.word_key(w)]
        self.assertNotEqual(entry.get('last_result'), 'good')
        self.assertEqual(rf.Scheduler(WORDS).vocabulary_score(), 0)

    def test_countdown_menu_applies_now_and_persists_for_restart(self):
        popup = self.app.popup
        self.app.handle_command('countdown:15')
        self.assertEqual(tray_icon.selected_countdown(), 15)
        self.assertEqual(self.app.settings['hide_after_seconds'], 15)
        self.assertEqual(popup.settings['hide_after_seconds'], 15)
        self.assertGreater(popup.hide_deadline - time.monotonic(), 14.5)
        self.assertEqual(popup.canvas.itemcget('countdown-label', 'text'), 'Antwoord over 5 s')
        self.assertEqual(rf.load_json(self.base/'settings.json', {})['popup_opacity'], 0.85)
        self.assertEqual(rf.load_settings()['hide_after_seconds'], 15)
        for value in rf.COUNTDOWN_CHOICES:
            self.app.handle_command(f'countdown:{value}')
            self.assertEqual(tray_icon.selected_countdown(), value)
        for bad in ('countdown:0', 'countdown:3', 'countdown:4', 'countdown:abc', 'countdown:999'):
            with self.assertRaises(ValueError): self.app.handle_command(bad)

    def test_countdown_change_never_restarts_manually_revealed_card(self):
        p = self.app.popup
        p.mark_known()
        self.assertIsNone(p.hide_deadline)
        self.app.handle_command('countdown:13')
        self.assertIsNone(p.hide_deadline)
        self.assertEqual(p.canvas.itemcget('countdown-label', 'text'), '')
        self.assertIsNone(p.rated_result)

if __name__ == '__main__': unittest.main()
