"""Nieuwe layout v6.20: vaste venstergrootte, vast tekstschema en grenzen."""
from pathlib import Path
from unittest.mock import patch
import tkinter as tk
import unittest
import sys
import json

sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as rf

class FixedLayoutTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.words = json.loads((Path(__file__).resolve().parents[1]/'words.json').read_text())
        cls.lookup={rf.plain_russian(w['ru']):w for w in cls.words}
    def setUp(self):
        self.root=tk.Tk();self.root.withdraw()
        opts={**rf.DEFAULT_SETTINGS,'play_audio_automatically':False,'popup_opacity':1.0}
        self.popup=rf.Popup(self.root,opts)
        self.patch=patch.object(self.popup,'ensure_audio')
        self.patch.start()
    def tearDown(self):
        self.patch.stop()
        self.popup.shutdown()
        self.root.destroy()
    def test_identical_geometry_context_picture_and_simple(self):
        xs=[]
        for w in (self.lookup['ничего'],self.lookup['куртка'],self.lookup['горячий']):
            self.popup.show(w,preserve_position=True)
            self.root.update()
            xs.append((self.popup.win.winfo_width(),self.popup.win.winfo_height()))
            self.assertEqual(self.popup.canvas.itemcget('translation','text'),'')
            self.assertEqual(self.popup.canvas.itemcget('translation','state'),'hidden')
            self.popup.mark_known()
            self.root.update_idletasks()
            self.assertEqual(self.popup.canvas.itemcget('translation','text'),w['nl'])
        self.assertEqual(xs,[(580,290)]*3)
    def test_longest_cards_fit_reserved_areas(self):
        problems=[]
        # Gerichte steekproef: extreem lange vormen en alle contextsoorten.
        hardest = sorted(self.words, key=lambda w: len(rf.displayed_russian(w)) + len(w.get('context_nl', '')) + len(w.get('context_ru', '')), reverse=True)[:80]
        sample = hardest + self.words[::37]
        for w in sample:
            self.popup.show(w,preserve_position=True)
            self.popup.reveal()
            self.root.update_idletasks()
            for tag, y_top, y_bottom, x_right in (
                ('russian',49,145,405),('translation',80,145,405),
                ('context-ru',160,230,485),('context-nl',184,239,485)):
                b=self.popup.canvas.bbox(tag)
                if b and (b[1] < y_top or b[3] > y_bottom or b[2] > x_right):
                    problems.append((w['ru'],tag,b))
        self.assertFalse(problems,problems[:10])
    def test_next_preserves_position_even_when_context_changes(self):
        self.popup.show(self.lookup['ничего'])
        self.root.update()
        self.popup.win.geometry('500x290+120+105')
        self.root.update()
        xy=(self.popup.win.winfo_x(),self.popup.win.winfo_y())
        self.popup.show(self.lookup['куртка'],preserve_position=True)
        self.root.update()
        self.assertEqual((self.popup.win.winfo_x(),self.popup.win.winfo_y()),xy)
        self.assertEqual((self.popup.win.winfo_width(),self.popup.win.winfo_height()),(580,290))
    def test_buttons_and_score_work(self):
        self.popup.show(self.lookup['тот'])
        self.root.update()
        self.popup.canvas.event_generate('<Button-1>',x=170,y=270)
        self.root.update()
        self.assertTrue(self.popup.revealed)
        self.assertIsNone(self.popup.rated_result)
        self.popup.canvas.event_generate('<Button-1>',x=246,y=270)
        self.root.update()
        self.assertEqual(self.popup.rated_result,'good')
        self.assertIsNone(self.popup.hide_deadline)
        self.popup.canvas.event_generate('<Button-1>',x=405,y=270)
        self.root.update()
        self.assertIsNone(self.popup.active_word)

if __name__=='__main__': unittest.main()
