"""v6.19: menu restart must request a graceful restart, not spawn a second app."""
from pathlib import Path
import sys
import tempfile
import tkinter as tk
import unittest
from unittest.mock import patch

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE))
import russische_woordflitser as rf


class TrayRestartTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        data = Path(self.temp.name)
        self.patches = [patch.object(rf, 'STATE_FILE', data/'progress.json'),
                        patch.object(rf, 'all_words', return_value=[{'ru':'ко́шка','nl':'kat'}])]
        for p in self.patches:
            p.start()
        self.root = tk.Tk()
        self.root.withdraw()
        self.app = rf.Application(self.root, {**rf.DEFAULT_SETTINGS, 'play_audio_automatically':False})

    def tearDown(self):
        self.app.shutdown()
        self.root.destroy()
        for p in reversed(self.patches):
            p.stop()
        self.temp.cleanup()

    def test_menu_sends_restart_to_owner(self):
        self.assertIn("add('Woordflitser herstarten', 'restart')", (BASE/'tray_icon.py').read_text())
        self.assertFalse(self.app.restart_requested)
        with patch.object(self.root, 'quit') as quit_now, patch.object(rf.subprocess,'Popen') as spawn:
            self.app.handle_command('restart')
        self.assertTrue(self.app.restart_requested)
        quit_now.assert_called_once_with()
        spawn.assert_not_called()

    def test_command_is_available_over_local_socket(self):
        with patch.object(rf.subprocess,'Popen'):
            # Use temporary socket so no user instance can be affected.
            with patch.object(rf, 'CONTROL_SOCKET', Path(self.temp.name)/'control.sock'):
                self.app.start_controls()
                import threading
                done=[]
                t=threading.Thread(target=lambda:done.append(rf.send_control('restart')), daemon=True)
                t.start()
                import time
                for _ in range(30):
                    self.root.update()
                    if done:
                        break
                    time.sleep(.015)
                t.join(.5)
                self.assertEqual(done,[True])
                self.assertTrue(self.app.restart_requested)
                self.app.shutdown()
