"""v6.58 — independent case-recognition cards and unchanged ordinary cards."""
import json
from pathlib import Path
import sys
import unittest
from collections import Counter

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE))
import russische_woordflitser as app
import tray_icon

class CaseContentTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cases = json.loads((BASE/'naamvallen_oefeningen.json').read_text(encoding='utf-8'))

    def test_case_coverage_and_ids(self):
        self.assertEqual(len(self.cases),35)
        self.assertEqual(set(Counter(w['case'] for w in self.cases)), set('NGDAIP'))
        self.assertEqual(len(set(app.word_key(w) for w in self.cases)), len(self.cases))
        for w in self.cases:
            self.assertEqual(w['ru'],w['target'])
            self.assertEqual(w['nl'], app.CASE_LABELS[w['case']])
            self.assertIn(w['target'].casefold(),w['context_ru'].casefold())
            self.assertEqual(app.case_sentence(w).count('«'),1)
            self.assertIn(w['lemma'],app.case_short_explanation(w))
            self.assertTrue(app.word_key(w).startswith('naamvallen:'))

    def test_full_case_table_from_source(self):
        self.assertEqual(app.CASE_PATTERNS['стол'][1], ['стол','стола','столу','стол','столом','столе'])
        self.assertEqual(app.CASE_PATTERNS['мама'][1], ['мама','мамы','маме','маму','мамой','маме'])
        self.assertEqual(app.CASE_PATTERNS['кухня'][1], ['кухня','кухни','кухне','кухню','кухней','кухне'])
        self.assertEqual(app.CASE_PATTERNS['окно'][1], ['окно','окна','окну','окно','окном','окне'])
        self.assertEqual(app.CASE_PATTERNS['Марк'][1][3], 'Марка')
        self.assertEqual(app.CASE_PATTERNS['Мария'][1][5], 'Марии')

    def test_theme_selects_without_changing_old_selection(self):
        self.assertEqual(app.THEME_IDS, tray_icon.THEME_IDS)
        all_words = app.all_words()
        settings = {'selected_themes':['naamvallen'], 'direction':'nl-ru'}
        result = app.eligible_words(all_words,settings)
        self.assertEqual(len(result),35)
        self.assertTrue(all(app.is_case_exercise(w) for w in result))
        self.assertEqual(len(app.eligible_words(all_words, {'selected_themes': [],'direction':'ru-nl'})),0)
        self.assertEqual(len([w for w in app.eligible_words(all_words, {'selected_themes':['thuis'],'direction':'ru-nl'}) if app.is_case_exercise(w)]),0)

    def test_case_scores_do_not_count_as_regular_vocabulary(self):
        state = {'words': {'naamvallen:стол-p': {'last_result':'good'},
                           'стол': {'last_result':'good'},
                           'verwarring:test': {'last_result':'good'}}}
        self.assertEqual(app.vocabulary_score(state),1)

class CaseGuiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        import tkinter as tk
        cls.tk=tk
        cls.root=tk.Tk()
        cls.root.withdraw()
    @classmethod
    def tearDownClass(cls):
        cls.root.destroy()

    def setUp(self):
        self.settings={**app.DEFAULT_SETTINGS, 'play_audio_automatically':False,
                       'speak_examples_automatically':False, 'selected_themes':['naamvallen']}
        self.card=app.Popup(self.root,self.settings)

    def tearDown(self):
        self.card.shutdown()
        self.card.win.destroy()
        self.root.update()

    def test_unchanged_size_and_case_prompt(self):
        w=next(w for w in json.loads((BASE/'naamvallen_oefeningen.json').read_text()) if w['exercise_id']=='стол-p')
        for direction in ('ru-nl', 'nl-ru'):
            self.card.settings['direction']=direction
            self.card.show(w)
            self.root.update()
            self.assertEqual((self.card.WIDTH,self.card.HEIGHT),(580,290))
            self.assertIn('naamval',self.card.canvas.itemcget('russian','text'))
            self.assertIn('«',self.card.canvas.itemcget('context-ru','text'))
            self.assertEqual(self.card.canvas.itemcget('translation','state'),'hidden')
            self.card.mark_known()
            self.root.update()
            self.assertEqual(self.card.canvas.itemcget('translation','text'),'P — Prepositioneel')
            self.assertIn('стол → столе',self.card.canvas.itemcget('context-nl','text'))
            self.assertNotEqual(self.card.canvas.itemcget('case-help','state'),'hidden')
            self.card.show_case_help()
            self.root.update()
            self.assertIsNone(self.card.hide_deadline)
            self.assertIsNotNone(self.card.case_help_dialog)
            # Same action as clicking Sluiten in the explanation window.
            close = next(widget for widget in self.card.case_help_dialog.winfo_children()[0].winfo_children()
                         if isinstance(widget, self.tk.Button) and widget.cget('text') == 'Sluiten')
            close.invoke()
            self.root.update()
            self.assertIsNone(self.card.case_help_dialog)
            self.card.mark_good()
            self.assertEqual(self.card.rated_result,'good')

    def test_normal_card_still_has_editor_and_not_case_help(self):
        self.card.show({'ru':'стол','nl':'tafel','theme':'thuis',
                        'context_ru':'Это стол.','context_nl':'Dit is een tafel.'})
        self.root.update()
        self.assertFalse(self.card.case_mode)
        self.assertTrue(self.card.canvas.find_withtag('edit-word'))
        self.assertFalse(self.card.canvas.find_withtag('case-help'))

if __name__=='__main__': unittest.main()
