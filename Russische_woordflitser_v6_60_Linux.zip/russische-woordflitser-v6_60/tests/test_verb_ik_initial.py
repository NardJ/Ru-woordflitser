"""v6.13: infinitief + ik-vorm zijn voor onthulling zichtbaar en worden samen uitgesproken."""
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest import TestCase
from unittest.mock import patch
import sys
import tkinter as tk
from tkinter import font as tkfont

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as rf


class VerbIkInitialTests(TestCase):
    def setUp(self):
        self.root = tk.Tk()
        self.root.withdraw()
        self.popup = rf.Popup(self.root, {**rf.DEFAULT_SETTINGS, 'play_audio_automatically': False})
        self.verb = {'ru': 'писа́ть', 'ik': 'я пишу́', 'nl': 'schrijven'}

    def tearDown(self):
        self.popup.shutdown()
        self.root.destroy()

    def test_russian_both_visible_before_dutch(self):
        with patch.object(self.popup, 'ensure_audio'):
            self.popup.show(self.verb)
        self.assertEqual(self.popup.canvas.itemcget('russian', 'text'), 'писа́ть — я пишу́')
        self.assertEqual(self.popup.canvas.itemcget('translation', 'text'), '')
        self.popup.mark_known()
        self.assertEqual(self.popup.canvas.itemcget('russian', 'text'), 'писа́ть — я пишу́')
        self.assertEqual(self.popup.canvas.itemcget('translation', 'text'), 'schrijven')
        self.assertEqual(self.popup.canvas.itemcget('status', 'text'),
                         'Controleer je antwoord · kies Goed of Fout')
        self.assertIsNone(self.popup.rated_result)

    def test_speech_starts_with_both_forms_and_uses_new_cache_key(self):
        self.assertEqual(rf.spoken_russian(self.verb), 'писа́ть. я пишу́')
        self.assertNotEqual(rf.voice_cache_path(rf.spoken_russian(self.verb), rf.DEFAULT_SETTINGS['voice']),
                            rf.voice_cache_path(self.verb['ru'], rf.DEFAULT_SETTINGS['voice']))
        self.assertEqual(rf.plain_russian(rf.spoken_russian(self.verb)), 'писать. я пишу')
        self.assertEqual(rf.spoken_russian({'ru': 'ко́шка', 'nl': 'kat'}), 'ко́шка')

    def test_first_speech_auto_play_only_once(self):
        self.popup.settings['play_audio_automatically'] = True
        with patch.object(self.popup, 'play_cached_voice', return_value=True) as playback, \
             patch.object(self.popup, 'ensure_audio') as prepare:
            self.popup.show(self.verb)
            playback.assert_called_once_with(self.verb)
            self.popup.reveal()
            playback.assert_called_once_with(self.verb)
            prepare.assert_not_called()

    def test_all_250_initial_forms_fit_one_line(self):
        verbs = [w for w in rf.all_words() if w.get('ik')]
        self.assertEqual(len(verbs), 252)
        fonts = {size: tkfont.Font(family='DejaVu Sans', size=size, weight='bold')
                 for size in range(12,24)}
        for word in verbs:
            full = rf.displayed_russian(word)
            size = 23
            while size > 12 and fonts[size].measure(full) > 372:
                size -= 1
            self.assertLessEqual(fonts[size].measure(full), 372,
                                 f"Past niet in popup: {full}")

    def test_other_words_keep_original_audio_key_and_display(self):
        noun = {'ru': 'ко́шка', 'nl': 'kat'}
        self.assertEqual(rf.displayed_russian(noun), noun['ru'])
        self.assertEqual(rf.spoken_russian(noun), noun['ru'])


if __name__ == '__main__':
    import unittest
    unittest.main()
