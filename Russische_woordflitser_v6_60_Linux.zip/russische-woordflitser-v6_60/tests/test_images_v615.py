"""v6.16: complete and semantically curated illustration pack, safe migration."""
import json, pathlib, subprocess, tempfile, unittest, os, shutil
from PIL import Image
HERE=pathlib.Path(__file__).resolve().parent.parent

class ImageAssets(unittest.TestCase):
    def test_illustrations_are_complete(self):
        words=json.loads((HERE/'words.json').read_text('utf8'))
        self.assertEqual(len(words),1090)
        self.assertEqual(sum(bool(w.get('image')) for w in words),802)
        self.assertEqual(len({w['image'] for w in words if w.get('image')}),802)
        for word in words:
            if 'image' in word:
                im_path=HERE/word['image']
                self.assertTrue(im_path.exists(),(word['ru'],im_path))
                with Image.open(im_path) as im:
                    self.assertEqual(im.width, im.height)
                    self.assertGreaterEqual(im.width,164)

    def test_specific_words_have_meaningful_distinct_pictures(self):
        words=json.loads((HERE/'words.json').read_text('utf8'))
        checks={'сосе́д':'buurman','сосе́дка':'buurvrouw','плава́ть':'zwemmen (regelmatig / rond)',
                'покупа́ть':'kopen (bezig / gewoonte)','опя́ть':'opnieuw'}
        actual={w['ru']:w for w in words}
        for ru,nl in checks.items():
            self.assertIn(ru, actual)
            self.assertEqual(actual[ru]['nl'],nl)
            self.assertTrue(actual[ru].get('image'))
        self.assertNotEqual(actual['сосе́д']['image'],actual['сосе́дка']['image'])
        self.assertNotEqual(actual['плава́ть']['image'],actual['покупа́ть']['image'])
        self.assertFalse(any(w['ru']=='пого́да' for w in words))

    def test_preserve_progress_and_custom_words_and_fix_again(self):
        with tempfile.TemporaryDirectory() as d:
            d=pathlib.Path(d)
            target=d/'existing';target.mkdir()
            for fn in ['russische_woordflitser.py','start.sh','settings.json','words.json']:
                shutil.copy2(HERE/fn,target/fn)
            (target/'start.sh').write_text('#!/bin/sh\necho "Niet actief"\n')
            (target/'start.sh').chmod(0o755)
            old_words=json.loads((target/'words.json').read_text())
            for word in old_words:
                if word['ru']=='опя́ть':word['nl']='weer'
                if word.get('image','').startswith('images/v_'):
                    word.pop('image')
            old_words.append({'ru':'моё дополнительное слово','nl':'eigen woord','image':'images/user_photo.png'})
            (target/'words.json').write_text(json.dumps(old_words,ensure_ascii=False),'utf8')
            (target/'images').mkdir()
            sample=b'my own illustration'
            (target/'images/user_photo.png').write_bytes(sample)
            dataroot=d/'user-state';folder=dataroot/'russische-woordflitser';folder.mkdir(parents=True)
            progress=folder/'progress.json'
            progress.write_text('{"words":{"кошка":{"last_result":"good"}},"shown_total":42}',encoding='utf8')
            settings=json.loads((target/'settings.json').read_text('utf8'))
            settings['popup_opacity']=.71
            (target/'settings.json').write_text(json.dumps(settings),'utf8')
            result=subprocess.run([str(HERE/'update_existing.sh'),str(target)],text=True,capture_output=True,
                                  env={**os.environ,'XDG_DATA_HOME':str(dataroot)},timeout=30)
            self.assertEqual(result.returncode,0,(result.stdout,result.stderr))
            self.assertEqual(json.loads(progress.read_text())['shown_total'],42)
            self.assertTrue(list(folder.glob('progress.json.backup-*')))
            self.assertEqual(json.loads((target/'settings.json').read_text())['popup_opacity'],.71)
            self.assertEqual((target/'images/user_photo.png').read_bytes(),sample)
            updated=json.loads((target/'words.json').read_text())
            self.assertEqual(len(updated),1091)
            self.assertEqual(next(w['nl'] for w in updated if w['ru']=='опя́ть'),'opnieuw')
            self.assertEqual(sum(bool(w.get('image')) for w in updated),803)
            self.assertTrue(all((target/w['image']).exists() for w in updated if w.get('image')))

if __name__=='__main__':unittest.main()
