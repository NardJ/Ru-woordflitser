"""v6.51: test XApp control menu without requiring a real Cinnamon panel.

This fake reproduces the relevant GTK signal/value semantics. Real desktop
placement and Cinnamon panel integration still require an on-device test.
"""
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import tray_icon
import tray_xapp


class Widget:
    def __init__(self, label='', active=False, value=0, **_kwargs):
        self.label, self.active, self.value = label, active, value
        self.visible = False
        self.parent = None
        self.child = None
        self.children = []
        self.connections = {}
        self.visible_name = None
        self.expanded = False

    def connect(self, signal, fn, *args):
        self.connections.setdefault(signal, []).append((fn,args))
        return len(self.connections[signal])

    def emit(self, signal, *args):
        for fn,extra in self.connections.get(signal, []):
            fn(self, *args, *extra)

    def add(self, widget):
        self.child=widget
        widget.parent=self
    def add_named(self, widget, name):
        self.children.append(widget)
        widget.parent=self
    def get_child(self): return self.child
    def pack_start(self, widget, *_):
        self.children.append(widget)
        widget.parent=self
    def pack_end(self, widget, *_):
        self.children.append(widget)
        widget.parent=self
    def get_children(self): return self.children
    def get_style_context(self): return self
    def add_class(self, *_): pass
    def set_text(self, text): self.label=text
    def set_label(self, text): self.label=text
    def get_active(self):return self.active
    def set_active(self, value):
        if self.active != value:
            self.active=value
            self.emit('toggled')
    def get_value(self):return self.value
    def set_value(self, value):
        if self.value != value:
            self.value=value
            self.emit('value-changed')
    def get_visible(self):return self.visible
    def get_expanded(self):return self.expanded
    def set_expanded(self, expanded):
        if self.expanded != expanded:
            self.expanded = expanded
            self.emit('notify::expanded', None)
    def set_valign(self, align): self.valign = align
    def set_vexpand(self, expand): self.vexpand = expand
    def get_position(self):return getattr(self,'position',(500,20))
    def get_allocated_width(self):return 338
    def translate_coordinates(self, dest, x, y):
        return (x, y + getattr(self, 'row_offset', 0))
    def is_active(self):return False
    def reorder_child(self, child, i):
        self.children.remove(child)
        self.children.insert(i,child)
    def move(self,x,y):self.position=(x,y)
    def resize(self,width,height):self.size=(width,height)
    def show_all(self):self.visible=True
    def hide(self):self.visible=False
    def present(self):self.visible=True
    def get_preferred_width(self):return (338,338)
    def get_preferred_height(self):return (400,400)
    def get_icon_size(self):return 22
    def set_visible_child_name(self, name):self.visible_name=name
    def __getattr__(self, method):
        if method.startswith('set_') or method in ('move','resize'):
            return lambda *args, **kwargs:None
        raise AttributeError(method)

class Css(Widget):
    def load_from_data(self, data):pass

class Toolkit:
    Orientation=SimpleNamespace(VERTICAL=0,HORIZONTAL=1)
    WindowType=SimpleNamespace(TOPLEVEL=0,POPUP=1)
    ShadowType=SimpleNamespace(OUT=0)
    StackTransitionType=SimpleNamespace(NONE=0)
    PolicyType=SimpleNamespace(NEVER=0,AUTOMATIC=1)
    ReliefStyle=SimpleNamespace(NONE=0)
    PositionType=SimpleNamespace(TOP=0,BOTTOM=1,LEFT=2,RIGHT=3)
    Align=SimpleNamespace(START=0,FILL=1)
    STYLE_PROVIDER_PRIORITY_APPLICATION=700
    Window=SimpleNamespace(new=lambda kind: Widget())
    Frame=Widget
    Box=Widget
    Label=staticmethod(lambda label='':Widget(label=label))
    Stack=Widget
    Button=Widget
    Separator=Widget
    ScrolledWindow=Widget
    CheckButton=SimpleNamespace(new_with_label=lambda text:Widget(label=text))
    RadioButton=SimpleNamespace(new_with_label_from_widget=lambda group, text:Widget(label=text))
    Scale=SimpleNamespace(new_with_range=lambda *args:Widget())
    Expander=staticmethod(lambda label:Widget(label=label))
    CssProvider=Css
    StyleContext=SimpleNamespace(add_provider_for_screen=lambda *args:None)
    def __init__(self):
        self.main_called=False
    def main_quit(self):self.main_called=True

class TestMenu(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.settings=Path(self.tmp.name)/'settings.json'
        self.settings.write_text('{"direction":"nl-ru","selected_themes":[],"audio_volume":197, "normalize_audio":false}')
        self.socket=Path(self.tmp.name)/'control.sock'
        self.socket.touch()
        self.pause=Path(self.tmp.name)/'pause'
        self.patch=patch.object(tray_icon, 'SETTINGS_FILE', self.settings)
        self.patch.start()
        self.commands=[]
        Gtk=Toolkit()
        Gdk=SimpleNamespace(
            WindowTypeHint=SimpleNamespace(DROPDOWN_MENU=1),
            Screen=SimpleNamespace(get_default=lambda:object()),
            Display=SimpleNamespace(get_default=lambda:SimpleNamespace(
                get_monitor_at_point=lambda x,y:SimpleNamespace(
                    get_workarea=lambda:SimpleNamespace(x=0,y=0,width=1920,height=1080)))))
        self.sources={}
        self.source_id=0
        def timeout(ms, f):
            self.source_id+=1
            self.sources[self.source_id]=f
            return self.source_id
        GLib=SimpleNamespace(timeout_add=timeout, timeout_add_seconds=timeout, idle_add=lambda f: timeout(0, f),
                             source_remove=lambda ident:self.sources.pop(ident,None))
        XApp=SimpleNamespace(StatusIcon=Widget)
        self.menu=tray_xapp.XAppMenu(Gtk,Gdk,GLib,XApp,self.commands.append,self.socket,self.pause)

    def tearDown(self):
        self.patch.stop()
        self.tmp.cleanup()

    def test_single_icon_and_all_pages(self):
        self.assertEqual(len(self.menu.theme_buttons), len(tray_icon.THEME_CHOICES))
        self.assertEqual(self.menu.icon.label, '')
        self.assertIn('button-release-event', self.menu.icon.connections)
        self.assertEqual(len(self.menu.stack.children), 4)
        self.menu.toggle(900,20,self.menu.Gtk.PositionType.TOP)
        self.assertTrue(self.menu.window.get_visible())
        self.assertEqual(self.menu.scale.get_value(),197)
        self.assertEqual(self.menu.volume_label.label,'197%')
        self.menu.navigate('themes')
        self.assertEqual(self.menu.stack.visible_name, 'themes')
        self.menu.navigate('home')
        self.assertFalse(self.menu.flyout_visible)
        self.assertEqual(self.menu.active_page, 'home')

    def test_no_spurious_writes_when_opening_and_true_slider(self):
        self.menu.toggle(500,30,self.menu.Gtk.PositionType.TOP)
        self.assertFalse(self.commands)
        self.menu.scale.set_value(185)
        self.assertEqual(self.menu.volume_label.label,'185%')
        self.assertEqual(self.menu.pending_volume, 185)
        self.menu.hide()
        self.assertEqual(self.commands,['volume:185'])

    def test_theme_actions_and_empty_theme_persistence(self):
        self.menu.toggle(500,20,self.menu.Gtk.PositionType.TOP)
        self.assertTrue(all(not w.get_active() for w in self.menu.theme_buttons.values()))
        self.menu.set_all_themes(True)
        self.assertEqual(self.commands, ['themes:all'])
        self.assertTrue(all(w.get_active() for w in self.menu.theme_buttons.values()))
        self.menu.set_all_themes(False)
        self.assertEqual(self.commands[-1], 'themes:none')
        self.menu.theme_buttons['natuur'].set_active(True)
        self.assertEqual(self.commands[-1], 'theme:natuur:1')

    def test_direction_timing_speech(self):
        self.menu.toggle(500,20,self.menu.Gtk.PositionType.TOP)
        self.assertTrue(self.menu.direction_buttons['nl-ru'].get_active())
        self.menu.direction_buttons['ru-nl'].set_active(True)
        self.assertIn('direction:ru-nl', self.commands)
        self.menu.interval_buttons[15].set_active(True)
        self.menu.countdown_buttons[11].set_active(True)
        self.menu.ratio_buttons[4].set_active(True)
        self.menu.examples.set_active(False)
        self.menu.normalization.set_active(True)
        self.assertTrue({'interval:15', 'countdown:11', 'newratio:4',
                         'examplespeech:0', 'normalizespeech:1'}.issubset(self.commands))

    def test_close_with_escape_focus_and_lost_socket(self):
        self.menu.toggle(500,20,self.menu.Gtk.PositionType.TOP)
        self.menu.navigate('themes')
        self.assertTrue(self.menu.on_key(None,SimpleNamespace(keyval=0xff1b)))
        self.assertEqual(self.menu.active_page, 'home')
        self.menu.opening=False
        self.menu.on_focus_out()
        self.assertFalse(self.menu.window.get_visible())
        self.socket.unlink()
        self.assertFalse(self.menu.on_tick())
        self.assertTrue(self.menu.Gtk.main_called)


    def test_xapp_bootstraps_without_constructing_a_native_menu(self):
        # This guards against v6.49: falling back to Gtk.StatusIcon while
        # XApp is installed moved the RU icon in the Cinnamon panel.
        import tray_icon
        import types
        gi=types.ModuleType('gi')
        gi.require_version=lambda *_: None
        rep=types.ModuleType('gi.repository')
        rep.Gdk=self.menu.Gdk
        rep.XApp=SimpleNamespace(StatusIcon=Widget)
        mockgtk=Toolkit()
        mockgtk.init_check=lambda:True
        mockgtk.main=lambda:None
        args=['tray_icon.py', str(self.socket), str(self.pause)]
        with patch.dict(sys.modules,{'gi':gi,'gi.repository':rep}), \
             patch.object(tray_icon,'gtk_modules',return_value=(mockgtk,self.menu.GLib,object())), \
             patch.object(sys,'argv',args), \
             patch.object(tray_xapp, 'XAppMenu') as ctor:
            self.assertEqual(tray_icon.main(), 0)
            ctor.assert_called_once()

if __name__ == '__main__':unittest.main()
