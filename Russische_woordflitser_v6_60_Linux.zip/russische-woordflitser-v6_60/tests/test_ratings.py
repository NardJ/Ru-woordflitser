"""Rating logic + Tk popup interactions. Run under xvfb-run when headless."""
import sys
from pathlib import Path
import tkinter as tk
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as rf


class TestRatings(unittest.TestCase):
    def setUp(self):
        self.word = {'ru': 'ко́шка', 'nl': 'kat'}
        self.settings = {'new_words_per_day': 4}
        self.temp = tempfile.TemporaryDirectory()
        self.patcher = patch.object(rf, 'STATE_FILE', Path(self.temp.name) / 'progress.json')
        self.patcher.start()

    def tearDown(self):
        self.patcher.stop()
        self.temp.cleanup()

    def test_wrong_is_due_after_three_other_words(self):
        sched = rf.Scheduler([self.word])
        sched.record_result(self.word, 'wrong', now=10000)
        entry = sched.state['words'][rf.word_key(self.word)]
        self.assertEqual(entry['next_due_other_count'], 3)
        self.assertEqual(entry['good_streak'], 0)

    def test_good_interval_grows_then_wrong_resets_it(self):
        sched = rf.Scheduler([self.word])
        sched.record_result(self.word, 'good', now=10000)
        entry = sched.state['words'][rf.word_key(self.word)]
        self.assertEqual(entry['next_due_other_count'], 10)
        sched.record_result(self.word, 'good', now=20000)
        entry = sched.state['words'][rf.word_key(self.word)]
        self.assertEqual(entry['next_due_other_count'], 25)
        sched.record_result(self.word, 'wrong', now=30000)
        self.assertEqual(entry['good_streak'], 2)  # prior snapshot
        entry = sched.state['words'][rf.word_key(self.word)]
        self.assertEqual(entry['good_streak'], 0)
        sched.record_result(self.word, 'good', now=40000)
        self.assertEqual(sched.state['words'][rf.word_key(self.word)]['next_due_other_count'], 10)

    def test_unrated_does_not_increase_mastery(self):
        sched = rf.Scheduler([self.word])
        sched.record_result(self.word, 'exposed', now=10000)
        entry = sched.state['words'][rf.word_key(self.word)]
        self.assertEqual(entry['next_due_other_count'], 4)
        self.assertEqual(entry['good_streak'], 0)

    def test_next_does_not_shorten_good_interval(self):
        sched = rf.Scheduler([self.word])
        sched.record_result(self.word, 'good', now=10000)
        due = sched.state['words'][rf.word_key(self.word)]['next_due_other_count']
        sched.note_shown(self.word, now=10050)
        sched.record_result(self.word, 'exposed', now=10050)
        entry = sched.state['words'][rf.word_key(self.word)]
        self.assertEqual(entry['next_due_other_count'], due)
        self.assertEqual(entry['last_result'], 'good')

    def test_dismissed_does_not_mark_seen(self):
        sched = rf.Scheduler([self.word])
        sched.record_result(self.word, 'dismissed', now=10000)
        self.assertEqual(sched.state['words'], {})
        self.assertEqual(sched.state['new_today'], 0)

    def test_old_view_count_is_not_credited_as_good(self):
        rf.save_json(rf.STATE_FILE, {'words': {rf.word_key(self.word): {
            'count': 12, 'next_due': 0, 'last_seen': 100,
        }}, 'new_day': '', 'new_today': 0})
        sched = rf.Scheduler([self.word])
        sched.record_result(self.word, 'good', now=10000)
        entry = sched.state['words'][rf.word_key(self.word)]
        self.assertEqual(entry['count'], 13)
        self.assertEqual(entry['good_streak'], 1)
        self.assertEqual(entry['next_due_other_count'], 10)


class TestPopupClicks(unittest.TestCase):
    def setUp(self):
        self.root = tk.Tk()
        self.root.withdraw()
        self.settings = {**rf.DEFAULT_SETTINGS, 'play_audio_automatically': False}
        self.word = {'ru': 'я́блоко', 'nl': 'appel'}
        self.popup = rf.Popup(self.root, self.settings)

    def tearDown(self):
        self.root.destroy()

    def show(self):
        self.results = []
        with patch.object(self.popup, 'ensure_audio'):
            self.popup.show(self.word, lambda w, result: self.results.append(result))
        self.root.update()

    def test_right_click_anywhere_dismisses_without_rating(self):
        self.show()
        self.popup.canvas.event_generate('<Button-3>', x=200, y=80)
        self.root.update()
        self.assertEqual(self.results, ['dismissed'])
        self.assertIsNone(self.popup.active_word)

    def test_good_button_click(self):
        self.show()
        self.popup.reveal()
        self.root.update()
        self.popup.canvas.event_generate('<Button-1>', x=246, y=270)
        self.root.update()
        self.assertIsNotNone(self.popup.active_word)
        self.popup.hide()
        self.assertEqual(self.results, ['good'])

    def test_wrong_button_click(self):
        self.show()
        self.popup.reveal()
        self.root.update()
        self.popup.canvas.event_generate('<Button-1>', x=92, y=270)
        self.root.update()
        self.assertIsNotNone(self.popup.active_word)
        self.popup.hide()
        self.assertEqual(self.results, ['wrong'])

    def test_next_button_immediate_without_rating(self):
        self.show()
        self.popup.canvas.event_generate('<Button-1>', x=405, y=270)
        self.root.update()
        self.assertEqual(self.results, ['next'])
        self.assertIsNone(self.popup.active_word)

    def test_next_button_available_before_reveal(self):
        self.show()
        self.assertTrue(all(self.popup.canvas.itemcget(obj, 'state') != 'hidden'
                            for obj in self.popup.canvas.find_withtag('next')))
        self.popup.canvas.event_generate('<Button-1>', x=405, y=270)
        self.root.update()
        self.assertEqual(self.results, ['next'])

    def test_good_then_next_keeps_rating(self):
        self.show()
        self.popup.reveal()
        self.root.update()
        self.popup.canvas.event_generate('<Button-1>', x=246, y=270)
        self.popup.canvas.event_generate('<Button-1>', x=405, y=270)
        self.root.update()
        self.assertEqual(self.results, ['next:good'])

    def test_timeout_is_neutral(self):
        self.show()
        self.popup.hide()
        self.assertEqual(self.results, ['exposed'])

    def test_rating_buttons_hidden_until_reveal(self):
        self.show()
        self.assertTrue(all(self.popup.canvas.itemcget(obj, 'state') == 'hidden'
                            for obj in self.popup.canvas.find_withtag('rating')))
        self.popup.reveal()
        self.assertTrue(all(self.popup.canvas.itemcget(obj, 'state') == 'normal'
                            for obj in self.popup.canvas.find_withtag('rating')))

if __name__ == '__main__':
    unittest.main()
