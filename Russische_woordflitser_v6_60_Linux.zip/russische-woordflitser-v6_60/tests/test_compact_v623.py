"""v6.23: compact canvas, no visible instruction, examples close together."""
import sys, json, unittest, tkinter as tk
from pathlib import Path
from unittest.mock import patch
BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE))
import russische_woordflitser as rf

class CompactTest(unittest.TestCase):
    def setUp(self):
        self.root=tk.Tk();self.root.withdraw()
        self.p=rf.Popup(self.root,{**rf.DEFAULT_SETTINGS,'play_audio_automatically':False,'popup_opacity':1.0})
        self.audio=patch.object(self.p,'ensure_audio');self.audio.start()
        self.words=json.loads((BASE/'words.json').read_text(encoding='utf-8'))
    def tearDown(self):
        self.audio.stop();self.p.shutdown();self.root.destroy()
    def test_compact_status_and_buttons(self):
        for w in self.words[::41]:
            self.p.show(w,preserve_position=True);self.root.update()
            self.assertEqual((self.p.win.winfo_width(), self.p.win.winfo_height()),(580,290))
            self.assertEqual(self.p.canvas.itemcget('status','state'),'hidden')
            ru=self.p.canvas.bbox('context-ru')
            nl_y=self.p.canvas.coords('context-nl')[1]
            self.assertGreaterEqual(nl_y-ru[3], 2)
            self.assertLessEqual(nl_y-ru[3], 7)
            self.p.mark_known();self.root.update()
            nl=self.p.canvas.bbox('context-nl')
            self.assertLess(nl[3], 255)
            # The answer button has now been swapped for the rating buttons.
            self.p.canvas.event_generate('<Button-1>',x=246,y=270);self.root.update()
            self.assertEqual(self.p.rated_result,'good')

if __name__=='__main__': unittest.main()
