"""Controleer afzonderlijk, ondoorzichtig editorvenster zonder overlap (v6.33)."""
import tkinter as tk
import unittest

import russische_woordflitser as wf


class EditorWindowTests(unittest.TestCase):
    def setUp(self):
        self.root = tk.Tk()
        self.root.withdraw()
        self.popup = wf.Popup(self.root, {
            **wf.DEFAULT_SETTINGS,
            'popup_opacity': 0.55,
            'play_audio_automatically': False,
        })
        self.popup.active_word = {
            'ru': 'свой', 'nl': 'mijn/jouw/zijn/haar eigen',
            'context_ru': 'Это мой дом.',
            'context_nl': 'Dit is mijn huis.',
        }
        self.popup.win.deiconify()
        self.popup.win.wm_attributes('-alpha', 0.55)
        self.root.update()

    def tearDown(self):
        self.popup.shutdown()
        try:
            self.root.destroy()
        except tk.TclError:
            pass

    def _open(self):
        self.popup.open_word_editor()
        self.root.update()
        return self.popup.edit_dialog

    def test_editor_is_independent_opaque_and_keeps_card_opacity(self):
        dlg = self._open()
        self.assertEqual(dlg.winfo_parent(), str(self.root))
        self.assertEqual(dlg.wm_transient(), '')
        self.assertAlmostEqual(float(dlg.wm_attributes('-alpha')), 1.0)
        # Het NOTIFICATION-venster mag niet meer boven de editor liggen.
        self.assertFalse(self.popup.win.winfo_viewable())
        self.assertTrue(dlg.winfo_viewable())
        self.assertAlmostEqual(float(self.popup.win.wm_attributes('-alpha')), 0.55)
        self.assertEqual(dlg.overrideredirect(), None)  # Decorated normally.
        cancel = next(w for w in self._walk(dlg)
                      if isinstance(w, tk.Button) and w['text'] == 'Annuleren')
        cancel.invoke()
        self.root.update()
        self.assertIsNone(self.popup.edit_dialog)
        self.assertTrue(self.popup.win.winfo_viewable())
        self.assertAlmostEqual(float(self.popup.win.wm_attributes('-alpha')), 0.55)

    def test_editor_uses_normal_title_bar_without_extra_drag_handle(self):
        dlg = self._open()
        # Verplaatsing loopt nu via de normale titelbalk van de windowmanager.
        self.assertFalse(bool(dlg.overrideredirect()))
        self.assertEqual(dlg.title(), 'Woordkaart aanpassen')
        labels = [w['text'] for w in self._walk(dlg) if isinstance(w, tk.Label)]
        self.assertFalse(any('Sleep hier' in label for label in labels))
        self.assertTrue(any('Russisch:' in label for label in labels))
        self.assertTrue(any('Nederlandse betekenis' == label for label in labels))
        self.assertFalse(self.popup.win.winfo_viewable())
        self.assertAlmostEqual(float(dlg.wm_attributes('-alpha')), 1.0)

    def test_save_restores_unchanged_card_position_and_opacity(self):
        before = (self.popup.win.winfo_x(), self.popup.win.winfo_y())
        dlg = self._open()
        self.assertFalse(self.popup.win.winfo_viewable())
        save = next(w for w in self._walk(dlg)
                    if isinstance(w, tk.Button) and w['text'] == 'Opslaan')
        save.invoke()
        self.root.update()
        self.assertIsNone(self.popup.edit_dialog)
        self.assertTrue(self.popup.win.winfo_viewable())
        self.assertEqual((self.popup.win.winfo_x(), self.popup.win.winfo_y()), before)
        self.assertAlmostEqual(float(self.popup.win.wm_attributes('-alpha')), 0.55)

    @staticmethod
    def _walk(widget):
        for child in widget.winfo_children():
            yield child
            yield from EditorWindowTests._walk(child)


if __name__ == '__main__':
    unittest.main()
