"""v6.24: fixed 500x290, compact readable text and stable controls."""
import sys, json, unittest, tkinter as tk
from pathlib import Path
from unittest.mock import patch
BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE))
import russische_woordflitser as rf

class CompactV624(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.words = json.loads((BASE / 'words.json').read_text(encoding='utf-8'))
    def setUp(self):
        self.root = tk.Tk(); self.root.withdraw()
        self.p = rf.Popup(self.root, {**rf.DEFAULT_SETTINGS,
                                    'play_audio_automatically': False,
                                    'popup_opacity': 1.0})
        self.audio = patch.object(self.p, 'ensure_audio'); self.audio.start()
    def tearDown(self):
        self.audio.stop(); self.p.shutdown(); self.root.destroy()
    def test_all_words_fit_both_directions(self):
        issues = []
        for direction in ('ru-nl', 'nl-ru'):
            self.p.settings['direction'] = direction
            for w in (sorted(self.words, key=lambda w: len(w.get('context_ru',''))+len(w.get('context_nl','')) + len(w.get('ru',''))+len(w.get('nl','')), reverse=True)[:25] + self.words[::27]):
                self.p.show(w, preserve_position=True)
                self.p.reveal()
                self.root.update_idletasks()
                if (self.p.win.winfo_width(), self.p.win.winfo_height()) != (580, 290):
                    issues.append((direction, w['ru'], 'geometry'))
                for tag, floor, right in (('russian', 145, 403),
                                          ('translation', 145, 403),
                                          ('context-ru', 235, 485),
                                          ('context-nl', 240, 485)):
                    if tag.startswith('context') and not self.p.context_mode:
                        continue
                    b = self.p.canvas.bbox(tag)
                    if b and (b[3] > floor or b[2] > right):
                        issues.append((direction, w['ru'], tag, b))
                if len(issues)>80:
                    break
        self.assertFalse(issues, issues[:30])
    def test_next_keeps_window_position_and_size(self):
        self.p.show(self.words[0]); self.root.update()
        self.p.win.geometry('500x290+123+156'); self.root.update_idletasks()
        before = (self.p.win.winfo_x(), self.p.win.winfo_y())
        self.p.show(self.words[40], preserve_position=True)
        self.root.update_idletasks()
        self.assertEqual((self.p.win.winfo_x(), self.p.win.winfo_y()), before)
        self.assertEqual((self.p.win.winfo_width(), self.p.win.winfo_height()), (580, 290))
    def test_buttons_and_reveal(self):
        self.p.show(self.words[10]);self.root.update()
        self.assertEqual(self.p.canvas.itemcget('translation','state'), 'hidden')
        self.p.canvas.event_generate('<Button-1>', x=180, y=270)
        self.root.update()
        self.assertTrue(self.p.revealed)
        self.assertIsNone(self.p.rated_result)
        self.p.canvas.event_generate('<Button-1>', x=246, y=270)
        self.root.update()
        self.assertEqual(self.p.rated_result,'good')
        self.assertIsNone(self.p.hide_deadline)

if __name__=='__main__':unittest.main()
