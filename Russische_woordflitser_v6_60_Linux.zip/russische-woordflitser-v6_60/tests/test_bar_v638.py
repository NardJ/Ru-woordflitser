"""v6.39: afteltekst alleen tot antwoord, kleurverloop en pauze."""
import sys
import time
import tkinter as tk
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as w

class TwoPhaseTests(unittest.TestCase):
    def setUp(self):
        self.root = tk.Tk(); self.root.withdraw()
        self.p = w.Popup(self.root, {**w.DEFAULT_SETTINGS,
                                    'play_audio_automatically': False,
                                    'hide_after_seconds': 9})
        self.worker = patch.object(self.p, 'ensure_audio'); self.worker.start()
        self.p.show({'ru':'тот', 'nl':'die', 'context_ru':'Тот дом старый.',
                     'context_nl':'Dat huis is oud.'})
        self.root.update()

    def tearDown(self):
        self.worker.stop(); self.p.shutdown(); self.root.destroy()

    def remaining(self, seconds):
        """Simuleer monotone klok bij een kaart van negen seconden."""
        now=time.monotonic()
        self.p.card_shown_at = now-(9-seconds)
        self.p.hide_deadline = now+seconds
        self.p.update_countdown()
        return self.p.canvas.coords('countdown-fill')[2]

    def test_new_bar_does_not_change_popup_size(self):
        self.assertEqual((self.p.win.winfo_width(), self.p.win.winfo_height()), (580,290))
        self.assertEqual(self.p.canvas.itemcget('countdown-track','fill'),'#e2e8f0')
        self.assertEqual(self.p.canvas.itemcget('countdown-fill','fill'),'#52a56d')
        self.assertEqual(self.p.canvas.itemcget('countdown-label','text'),
                         'Antwoord over 3 s')
        self.assertGreater(self.p.canvas.bbox('countdown-label')[0], 105)
        self.assertLessEqual(self.p.canvas.bbox('countdown-label')[2], 396)
        self.assertAlmostEqual(self.p.canvas.coords('countdown-fill')[2],438,delta=2)

    def test_bar_shrinks_continuously_and_turns_yellow_then_red(self):
        c = self.p.canvas
        self.assertEqual(w.countdown_color(0,3),'#52a56d')
        self.assertEqual(w.countdown_color(1.5,3),'#f2c23c')
        self.assertEqual(w.countdown_color(3,3),'#d6404c')
        self.assertAlmostEqual(self.remaining(7.5), 20+418*7.5/9, delta=1)
        self.assertEqual(c.itemcget('countdown-fill','fill'),'#f2c23c')
        self.assertIn('Antwoord over 2 s',c.itemcget('countdown-label','text'))
        self.assertAlmostEqual(self.remaining(6), 20+418*6/9, delta=1)
        self.assertEqual(c.itemcget('countdown-fill','fill'),'#d6404c')
        self.p.reveal()
        self.assertTrue(self.p.revealed)
        self.assertAlmostEqual(c.coords('countdown-fill')[2],20+418*6/9,delta=1)
        self.assertEqual(c.itemcget('countdown-label','text'),
                         '')
        self.assertAlmostEqual(self.remaining(3),20+418*3/9,delta=1)
        self.assertEqual(c.itemcget('countdown-fill','fill'),'#d6404c')
        self.assertEqual(c.itemcget('countdown-label','text'), '')
        self.assertAlmostEqual(self.remaining(0),20,delta=1)
        self.assertEqual(c.itemcget('countdown-fill','fill'),'#d6404c')

    def test_manual_reveal_leaves_card_open_with_empty_bar(self):
        self.p.mark_known()
        self.assertTrue(self.p.revealed)
        self.assertIsNone(self.p.hide_deadline)
        self.assertEqual(self.p.canvas.coords('countdown-fill')[2],self.p.BAR_LEFT)
        self.assertEqual(self.p.canvas.itemcget('countdown-label','text'),'')

    def test_pause_freezes_both_visible_times_color_and_bar(self):
        self.remaining(7.5)
        self.p.on_pause_motion(type('E',(),{'x':283,'y':261})())
        paused_label=self.p.canvas.itemcget('countdown-label','text')
        paused_width=self.p.canvas.coords('countdown-fill')[2]
        paused_color=self.p.canvas.itemcget('countdown-fill','fill')
        self.assertEqual(paused_label, 'Antwoord over 2 s')
        self.assertEqual(self.p.canvas.itemcget('pause-bg', 'fill'), '#486b94')
        with patch.object(w.time,'monotonic',return_value=time.monotonic()+25):
            self.p.update_countdown()
        self.assertEqual(self.p.canvas.itemcget('countdown-label','text'),paused_label)
        self.assertEqual(self.p.canvas.coords('countdown-fill')[2],paused_width)
        self.assertEqual(self.p.canvas.itemcget('countdown-fill','fill'),paused_color)

if __name__=='__main__': unittest.main()
