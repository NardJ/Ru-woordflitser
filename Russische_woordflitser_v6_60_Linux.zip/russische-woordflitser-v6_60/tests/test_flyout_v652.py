"""v6.55 regression: anchored popups must NEVER move or resize the main menu."""
import unittest
from types import SimpleNamespace
from test_xapp_menu_v651 import TestMenu


class TestFlyout(unittest.TestCase):
    def setUp(self):
        self.setup = TestMenu(methodName='test_single_icon_and_all_pages')
        self.setup.setUp()
        self.menu = self.setup.menu
        for page, offset in [('directions', 276), ('themes', 300),
                             ('timing', 324), ('speech', 348)]:
            self.menu.menu_anchors[page].row_offset = offset

    def tearDown(self):
        self.setup.tearDown()

    def test_left_of_main_at_own_item_height(self):
        menu = self.menu
        menu.toggle(1850, 25, menu.Gtk.PositionType.TOP)
        anchor_x, anchor_y = menu.window.get_position()
        main_width = menu.window.get_preferred_width()[1]
        menu.navigate('themes')
        self.assertTrue(menu.flyout_visible)
        self.assertEqual(menu.flyout_side, 'left')
        self.assertEqual(menu.flyout_window.position, (anchor_x - 338, anchor_y + 300))
        self.assertEqual(menu.window.get_position(), (anchor_x, anchor_y))
        self.assertEqual(main_width, menu.window.get_preferred_width()[1])
        menu.navigate('directions')
        self.assertEqual(menu.flyout_window.position, (anchor_x - 338, anchor_y + 276))
        self.assertEqual(menu.window.get_position(), (anchor_x, anchor_y))
        menu.navigate('home')
        self.assertFalse(menu.flyout_visible)
        self.assertTrue(menu.window.get_visible())
        self.assertEqual(menu.window.get_position(), (anchor_x, anchor_y))

    def test_right_of_main_at_own_item_height(self):
        menu = self.menu
        menu.toggle(340, 25, menu.Gtk.PositionType.TOP)
        x, y = menu.window.get_position()
        menu.navigate('directions')
        self.assertEqual(menu.flyout_side, 'right')
        self.assertEqual(menu.flyout_window.position, (x + 338, y + 276))
        self.assertEqual(menu.window.get_position(), (x, y))
        menu.navigate('speech')
        self.assertEqual(menu.flyout_window.position, (x + 338, y + 348))
        self.assertEqual(menu.window.get_position(), (x, y))
        self.assertTrue(menu.flyout_visible)

    def test_one_tray_icon_two_separate_windows(self):
        menu = self.menu
        menu.toggle(1850, 25, menu.Gtk.PositionType.TOP)
        menu.navigate('timing')
        self.assertTrue(menu.flyout_window.get_visible())
        self.assertTrue(menu.window.get_visible())
        self.assertIsNot(menu.window, menu.flyout_window)
        self.assertIs(menu.window.child, menu.main_frame)
        self.assertIs(menu.flyout_window.child, menu.flyout_frame)
        self.assertEqual(menu.stack.visible_name, 'timing')
        menu.timing_expanders['countdown'].set_expanded(True)
        self.assertTrue(menu.timing_expanders['countdown'].get_expanded())
        menu.navigate('home')
        self.assertFalse(menu.flyout_window.get_visible())
        self.assertTrue(menu.window.get_visible())

    def test_hover_navigation_and_volume_persistence(self):
        menu = self.menu
        menu.toggle(1850, 25, menu.Gtk.PositionType.TOP)
        buttons = [menu.menu_anchors[key] for key in ('directions', 'themes', 'timing', 'speech')]
        self.assertEqual(len(buttons), 4)
        buttons[1].emit('enter-notify-event', SimpleNamespace())
        self.assertEqual(menu.active_page, 'themes')
        self.assertTrue(menu.window.get_visible())
        self.assertFalse(self.setup.commands)
        menu.scale.set_value(120)
        menu.hide()
        self.assertEqual(self.setup.commands, ['volume:120'])
        self.assertFalse(menu.flyout_window.get_visible())

    def test_focus_out_and_escape(self):
        menu = self.menu
        menu.toggle(1840, 25, menu.Gtk.PositionType.TOP)
        menu.navigate('themes')
        menu.opening = False
        menu.on_focus_out()
        self.assertFalse(menu.window.get_visible())
        self.assertFalse(menu.flyout_window.get_visible())
        menu.toggle(500, 25, menu.Gtk.PositionType.TOP)
        menu.navigate('speech')
        menu.on_key(None, SimpleNamespace(keyval=0xff1b))
        self.assertTrue(menu.window.get_visible())
        self.assertFalse(menu.flyout_window.get_visible())
        menu.on_key(None, SimpleNamespace(keyval=0xff1b))
        self.assertFalse(menu.window.get_visible())


if __name__ == '__main__': unittest.main()
