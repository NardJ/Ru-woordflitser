"""Regression: manual Next must work even when testing with --once."""
import sys
import tempfile
from pathlib import Path
import tkinter as tk
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as rf


class OnceNextTests(unittest.TestCase):
    def test_once_next_still_shows_new_card(self):
        words = [{'ru': f'слово{i}', 'nl': str(i)} for i in range(4)]
        with tempfile.TemporaryDirectory() as tmp, \
             patch.object(rf, 'STATE_FILE', Path(tmp)/'progress.json'), \
             patch.object(rf, 'all_words', return_value=words):
            root = tk.Tk()
            root.withdraw()
            settings = {**rf.DEFAULT_SETTINGS, 'play_audio_automatically': False}
            app = rf.Application(root, settings, once=True)
            try:
                with patch.object(app.popup, 'ensure_audio'), patch.object(root, 'quit') as quit_mock:
                    app.try_popup(manual=True)
                    key = rf.word_key(app.popup.active_word)
                    app.popup.reveal()
                    app.popup.mark_good()
                    app.popup.next_card()
                    root.update()
                    self.assertIsNotNone(app.popup.active_word)
                    self.assertNotEqual(key, rf.word_key(app.popup.active_word))
                    quit_mock.assert_not_called()
                    # A final close with no Next still exits the test mode.
                    app.popup.close_current_card()
                    root.update()
                    quit_mock.assert_called_once()
            finally:
                app.shutdown()
                root.destroy()


if __name__ == '__main__':
    unittest.main()
