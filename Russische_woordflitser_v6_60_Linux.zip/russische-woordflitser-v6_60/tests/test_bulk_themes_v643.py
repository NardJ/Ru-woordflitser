"""v6.43: bulk theme selection, persistence and menu command integration."""
import json
from pathlib import Path
import sys
import tempfile
import threading
import time
import tkinter as tk
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as rf
import tray_icon

WORDS = [
    {'ru': 'до́м', 'nl': 'huis', 'theme': 'thuis'},
    {'ru': 'ко́шка', 'nl': 'kat', 'theme': 'natuur'},
    {'ru': 'чита́ть', 'nl': 'lezen', 'theme': 'handelingen'},
]


class BulkThemesTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        base = Path(self.temp.name)
        self.cfg = base / 'settings.json'
        self.cfg.write_text(json.dumps({
            'interval_minutes': 10, 'selected_themes': list(rf.THEME_IDS),
            'voice': 'ru-RU-SvetlanaNeural', 'my_custom_preference': 'bewaar',
        }), encoding='utf-8')
        patches = [
            patch.object(rf, 'BASE', base),
            patch.object(rf, 'STATE_FILE', base/'progress.json'),
            patch.object(rf, 'CONTROL_SOCKET', base/'control.sock'),
            patch.object(rf, 'all_words', return_value=WORDS),
            patch.object(tray_icon, 'SETTINGS_FILE', self.cfg),
        ]
        for p in patches:
            p.start()
            self.addCleanup(p.stop)
        self.root = tk.Tk()
        self.root.withdraw()
        self.addCleanup(self.root.destroy)
        self.app = rf.Application(self.root, {**rf.load_settings(),
            'play_audio_automatically': False})
        self.addCleanup(self.app.shutdown)
        p = patch.object(self.app.popup, 'ensure_audio')
        p.start()
        self.addCleanup(p.stop)

    def read_settings(self):
        return json.loads(self.cfg.read_text(encoding='utf-8'))

    def test_all_none_and_restart_preserve_other_preferences(self):
        self.app.sched.note_shown(WORDS[0])
        self.app.sched.record_result(WORDS[0], 'good')
        state = json.loads(rf.STATE_FILE.read_text(encoding='utf-8'))
        self.app.handle_command('themes:none')
        self.assertEqual(self.app.settings['selected_themes'], [])
        self.assertEqual(self.read_settings()['selected_themes'], [])
        self.assertEqual(tray_icon.selected_themes(), set())
        self.assertEqual(rf.load_settings()['selected_themes'], [])
        self.assertEqual(self.app.sched.choose(self.app.settings, manual=True), None)
        self.assertEqual(self.app.prefetched_word, None)
        self.app.handle_command('show')
        self.assertIsNone(self.app.popup.active_word)
        self.assertEqual(self.read_settings()['my_custom_preference'], 'bewaar')
        self.assertEqual(self.read_settings()['voice'], 'ru-RU-SvetlanaNeural')
        self.assertEqual(json.loads(rf.STATE_FILE.read_text(encoding='utf-8')), state)
        self.app.handle_command('themes:all')
        self.assertEqual(self.app.settings['selected_themes'], list(rf.THEME_IDS))
        self.assertEqual(tray_icon.selected_themes(), set(rf.THEME_IDS))
        self.assertIsNotNone(self.app.sched.choose(self.app.settings, manual=True))
        self.assertEqual(json.loads(rf.STATE_FILE.read_text(encoding='utf-8')), state)

    def test_select_a_single_theme_after_everything_off(self):
        self.app.handle_command('themes:none')
        self.app.handle_command('theme:natuur:1')
        self.assertEqual(self.read_settings()['selected_themes'], ['natuur'])
        self.assertEqual([w['nl'] for w in rf.eligible_words(WORDS,self.app.settings)], ['kat'])
        self.app.handle_command('theme:natuur:0')
        self.assertEqual(self.read_settings()['selected_themes'], [])
        self.app.handle_command('theme:thuis:1')
        self.app.handle_command('show')
        self.assertEqual(self.app.popup.active_word['nl'], 'huis')

    def test_bulk_sends_one_persist_per_click_and_rejects_unknown(self):
        with patch.object(rf, 'save_json', wraps=rf.save_json) as save:
            self.app.handle_command('themes:none')
            self.assertEqual(save.call_count, 1)
            self.app.handle_command('themes:all')
            self.assertEqual(save.call_count, 2)
        for bad in ('themes:foo', 'theme:nietbestaand:1', 'theme:natuur:maybe'):
            with self.assertRaises(ValueError):
                self.app.handle_command(bad)
        self.assertEqual(self.read_settings()['selected_themes'], list(rf.THEME_IDS))

    def test_bulk_command_reaches_owner_via_socket(self):
        with patch.object(rf.subprocess, 'Popen'):
            self.app.start_controls()
        for action, expected in [('themes:none', set()), ('theme:natuur:1', {'natuur'}),
                                 ('themes:all', set(rf.THEME_IDS))]:
            finished = []
            worker = threading.Thread(target=lambda: finished.append(rf.send_control(action)), daemon=True)
            worker.start()
            for _ in range(65):
                self.root.update()
                if finished:
                    break
                time.sleep(.01)
            worker.join(timeout=1)
            self.assertEqual(finished, [True])
            self.assertEqual(tray_icon.selected_themes(), expected)

    def test_resume_active_session_after_enabling_theme(self):
        self.app.handle_command('themes:none')
        self.app.handle_command('session')
        self.assertIsNone(self.app.popup.active_word)
        self.app.handle_command('theme:thuis:1')
        self.assertLessEqual(self.app.next_due_at - time.monotonic(), 1.1)
        # Trigger pending popup from next tick without waiting a second.
        self.app.try_popup(manual=True)
        self.assertEqual(self.app.popup.active_word['nl'], 'huis')


if __name__ == '__main__':
    unittest.main()

class FakeGtkItem:
    def __init__(self, label=''):
        self.label, self.submenu, self.active = label, None, False
        self.handlers = {}
        self.children = []

    @classmethod
    def new_with_label(cls, label):
        return cls(label)

    @classmethod
    def new_with_label_from_widget(cls, _first, label):
        return cls(label)

    def connect(self, signal, callback, *args):
        self.handlers[signal] = (callback, args)

    def set_submenu(self, submenu):
        self.submenu = submenu

    def show(self):
        pass

    def show_all(self):
        pass

    def append(self, item):
        self.children.append(item)

    def get_active(self):
        return self.active

    def set_active(self, new_value):
        if self.active != new_value:
            self.active = new_value
            if 'toggled' in self.handlers:
                callback, extra = self.handlers['toggled']
                callback(self, *extra)

    def activate(self):
        if 'activate' in self.handlers:
            callback, extra = self.handlers['activate']
            callback(self, *extra)

    def set_sensitive(self, _):
        pass

    def set_label(self, label):
        self.label = label


class FakeGtkStatus:
    @classmethod
    def new_from_file(cls, _):
        return cls()

    @classmethod
    def new_from_icon_name(cls, _):
        return cls()

    def set_tooltip_text(self, _):
        pass

    def set_visible(self, _):
        pass

    def connect(self, *_):
        pass


class FakeSocket:
    sent = []
    def __enter__(self):
        return self
    def __exit__(self, *_):
        return False
    def settimeout(self, _):
        pass
    def connect(self, _):
        pass
    def sendall(self, payload):
        self.sent.append(payload.decode('ascii').strip())


class TrayBulkMenuTests(unittest.TestCase):
    def test_menu_actions_and_checkboxes_without_15_separate_commands(self):
        with tempfile.TemporaryDirectory() as td:
            base = Path(td)
            setting = base / 'settings.json'
            setting.write_text(json.dumps({'selected_themes':['natuur'],
                                            'direction':'ru-nl'}))
            sock = base / 'test.sock'
            sock.touch()  # file presence is what this GTK helper watches
            FakeSocket.sent = []

            class FakeGLib:
                callback = None
                @classmethod
                def timeout_add_seconds(cls, _seconds, cb):
                    cls.callback = cb

            class FakeGtk:
                Menu = MenuItem = CheckMenuItem = RadioMenuItem = SeparatorMenuItem = FakeGtkItem
                StatusIcon = FakeGtkStatus
                @staticmethod
                def init_check():
                    return True
                @staticmethod
                def main_quit():
                    pass
                @staticmethod
                def main():
                    # menu definitions are created before Gtk.main runs
                    theme_parent = next(item for item in FakeGtk.menus[0].children
                                        if item.label == 'Thema’s oefenen')
                    entries = theme_parent.submenu.children
                    self.assertEqual(entries[0].label, 'Alle thema’s aan')
                    self.assertEqual(entries[1].label, 'Alle thema’s uit')
                    selected = [item.label for item in entries if item.active]
                    self.assertEqual(selected, ['Natuur & dieren'])

                    entries[1].activate()
                    self.assertEqual(FakeSocket.sent, ['themes:none'])
                    self.assertFalse(any(item.active for item in entries[3:]))

                    entries[3].activate()  # actually checkbox must be toggled
                    entries[3].set_active(True)
                    self.assertEqual(len(FakeSocket.sent), 2)
                    self.assertTrue(FakeSocket.sent[1].startswith('theme:'))

                    entries[0].activate()
                    self.assertEqual(FakeSocket.sent[-1], 'themes:all')
                    self.assertEqual(len(FakeSocket.sent), 3)
                    self.assertTrue(all(item.active for item in entries[3:]))

                    # GTK pulls persisted settings back into view on periodic refresh.
                    setting.write_text(json.dumps({'selected_themes':[],
                                                    'direction':'ru-nl'}))
                    FakeGLib.callback()
                    self.assertFalse(any(item.active for item in entries[3:]))
                    self.assertEqual(len(FakeSocket.sent), 3)

            # Capture the root menu as widgets are built.
            class Menu(FakeGtkItem):
                def __init__(self):
                    super().__init__()
                    FakeGtk.menus.append(self)
            FakeGtk.Menu = Menu
            FakeGtk.menus = []

            with patch.object(tray_icon, 'SETTINGS_FILE', setting), \
                 patch.object(tray_icon, 'gtk_modules', return_value=(FakeGtk, FakeGLib, None)), \
                 patch.object(tray_icon.socket, 'socket', return_value=FakeSocket()), \
                 patch.object(sys, 'argv', ['tray_icon.py', str(sock), str(base/'pause.txt')]):
                self.assertEqual(tray_icon.main(), 0)
