"""v6.42: answer time marker is fixed, clear and follows the reveal rule."""
import sys
import time
import tkinter as tk
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as rf


class AnswerMarkerTests(unittest.TestCase):
    def setUp(self):
        self.root = tk.Tk()
        self.root.withdraw()
        self.settings = {**rf.DEFAULT_SETTINGS,
                         'play_audio_automatically': False,
                         'hide_after_seconds': 9}
        self.popup = rf.Popup(self.root, self.settings)
        self.audio = patch.object(self.popup, 'ensure_audio')
        self.audio.start()
        self.popup.show({'ru': 'до́м', 'nl': 'huis',
                         'context_ru': 'Э́то до́м.', 'context_nl': 'Dit is een huis.'})
        self.root.update()

    def tearDown(self):
        self.audio.stop()
        self.popup.shutdown()
        self.root.destroy()

    def marker_x(self):
        return self.popup.canvas.coords('answer-marker-border')[0]

    def marker_state(self):
        return self.popup.canvas.itemcget('answer-marker-border', 'state')

    def remaining(self, seconds):
        now = time.monotonic()
        self.popup.card_shown_at = now - (9-seconds)
        self.popup.hide_deadline = now + seconds
        self.popup.update_countdown()

    def test_marker_at_reveal_point_and_not_enlarge_card(self):
        self.assertEqual((self.popup.win.winfo_width(), self.popup.win.winfo_height()), (580, 290))
        self.assertEqual(self.marker_state(), 'normal')
        self.assertAlmostEqual(self.marker_x(), 20 + 418*6/9, delta=.01)
        self.assertEqual(self.popup.canvas.itemcget('answer-marker-core', 'fill'), '#ffffff')
        self.assertEqual(self.popup.canvas.itemcget('answer-marker-border', 'fill'), '#24344a')
        self.assertAlmostEqual(self.marker_x(), self.popup.canvas.coords('answer-marker-core')[0])
        self.assertLess(self.popup.canvas.coords('answer-marker-border')[1], self.popup.BAR_TOP)
        self.assertGreater(self.popup.canvas.coords('answer-marker-border')[3], self.popup.BAR_BOTTOM)

    def test_stays_fixed_before_at_and_after_answer(self):
        x = self.marker_x()
        self.remaining(7.5)
        self.assertEqual(self.marker_x(), x)
        self.assertGreater(self.popup.canvas.coords('countdown-fill')[2], x)
        self.remaining(6)
        self.assertAlmostEqual(self.popup.canvas.coords('countdown-fill')[2], x, delta=1)
        self.popup.reveal()
        self.assertEqual(self.marker_state(), 'normal')
        self.remaining(3)
        self.assertLess(self.popup.canvas.coords('countdown-fill')[2], x)
        self.assertEqual(self.marker_x(), x)
        self.assertEqual(self.popup.canvas.itemcget('countdown-fill', 'fill'), '#d6404c')

    def test_stays_fixed_when_paused_and_changes_with_duration(self):
        self.popup.toggle_countdown_pause()
        x = self.marker_x()
        self.popup.update_countdown()
        self.assertEqual(self.marker_x(), x)
        self.popup.set_countdown_seconds(15)
        self.assertAlmostEqual(self.marker_x(), rf.answer_marker_x(15, 20, 438), delta=.01)
        self.assertEqual(self.marker_state(), 'normal')
        self.popup.toggle_countdown_pause()
        self.assertEqual(self.marker_state(), 'normal')
        self.assertEqual(self.popup.canvas.itemcget('countdown-label', 'text'), 'Antwoord over 5 s')

    def test_marker_is_hidden_when_countdown_is_cancelled(self):
        self.popup.mark_known()
        self.assertEqual(self.marker_state(), 'hidden')
        self.assertTrue(self.popup.revealed)
        self.popup.show({'ru':'ко́шка','nl':'kat'})
        self.assertEqual(self.marker_state(), 'normal')
        self.popup.reveal()
        self.popup.mark_good()
        self.assertEqual(self.marker_state(), 'hidden')

    def test_marker_math_uses_real_reveal_logic(self):
        for duration in (5, 7, 9, 11, 13, 15, 30):
            expected = 20 + 418 * (duration-rf.reveal_delay_seconds(duration)) / duration
            self.assertAlmostEqual(rf.answer_marker_x(duration,20,438), expected)


if __name__=='__main__':
    unittest.main()
