"""v6.47: audio must start immediately, even when normalisation is slow or broken."""
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as rf
import tray_icon as tray


class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.TemporaryDirectory()
        self.addCleanup(self.dir.cleanup)
        self.base = Path(self.dir.name)
        self.audio = self.base / 'speech.mp3'
        self.output = self.base / 'derived' / 'verified.mp3'
        self.output.parent.mkdir()
        if shutil.which('ffmpeg'):
            subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y',
                '-f', 'lavfi', '-i', 'sine=frequency=750:duration=0.6',
                '-c:a', 'libmp3lame', str(self.audio)], check=True, timeout=8)
        else:
            self.audio.write_bytes(b'fake mp3' * 30)

    def test_plays_original_instantly_during_slow_normalization(self):
        calls = []
        def slow_normalize(path):
            time.sleep(.3)
            self.output.write_bytes(self.audio.read_bytes())
            calls.append(path)
            return self.output
        with patch.object(rf, '_normalized_cache_path', return_value=self.output), \
             patch.object(rf, 'normalized_audio_path', side_effect=slow_normalize), \
             patch.object(rf.shutil, 'which', return_value='/usr/bin/ffmpeg'):
            start = time.monotonic()
            played = rf.audio_path_for_playback(self.audio)
            self.assertEqual(played, self.audio)
            self.assertLess(time.monotonic() - start, .15)
            for _ in range(35):
                if self.output.exists() and calls:
                    break
                time.sleep(.02)
            self.assertEqual(calls, [self.audio])
            self.assertEqual(rf.audio_path_for_playback(self.audio), self.output)

    def test_disable_normalization_never_schedules_a_job(self):
        with patch.object(rf, '_normalized_cache_path') as cache, \
             patch.object(rf._AUDIO_NORMALIZE_POOL, 'submit') as pool:
            self.assertEqual(rf.audio_path_for_playback(self.audio, normalize=False), self.audio)
        cache.assert_not_called()
        pool.assert_not_called()

    def test_missing_ffmpeg_falls_back_to_original(self):
        with patch.object(rf.shutil, 'which', return_value=None), \
             patch.object(rf._AUDIO_NORMALIZE_POOL, 'submit') as pool:
            self.assertEqual(rf.audio_path_for_playback(self.audio), self.audio)
        pool.assert_not_called()

    def test_compatibility_with_ubuntu_speech_player_arguments(self):
        if not shutil.which('ffplay') or not shutil.which('ffmpeg'):
            self.skipTest('ffmpeg/ffplay required')
        with patch.object(rf, 'AUDIO_ERROR_LOG', self.base/'audio-errors.log'):
            with patch.object(rf, 'audio_path_for_playback', return_value=self.audio):
                proc = rf.play_audio(self.audio, volume=100, normalize=True)
            self.assertIsNotNone(proc)
            # SDL dummy is passed to this process through the environment of
            # the test runner; this verifies decoding, not the hardware audio.
            self.assertEqual(proc.wait(timeout=8), 0)

    def test_toggle_read_from_settings(self):
        f = self.base / 'settings.json'
        with patch.object(tray, 'SETTINGS_FILE', f):
            self.assertTrue(tray.selected_audio_normalization())
            f.write_text('{"normalize_audio":false}', encoding='utf-8')
            self.assertFalse(tray.selected_audio_normalization())
            f.write_text('{"normalize_audio":true}', encoding='utf-8')
            self.assertTrue(tray.selected_audio_normalization())

if __name__ == '__main__':
    unittest.main()
