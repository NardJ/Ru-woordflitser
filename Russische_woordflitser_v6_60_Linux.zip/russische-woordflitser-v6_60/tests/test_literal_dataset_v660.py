"""v6.60: alle standaardvoorbeelden hebben een letterlijke RU→NL-leervertaling."""
import json
from pathlib import Path
import unittest

DATA = Path(__file__).resolve().parents[1] / 'words.json'

class LiteralDatasetV660(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.words = json.loads(DATA.read_text(encoding='utf-8'))

    def test_all_standard_examples_have_literal_translations(self):
        self.assertEqual(len(self.words), 1090)
        for i, word in enumerate(self.words):
            with self.subTest(i=i, ru=word['ru']):
                self.assertTrue(word['context_ru'].strip())
                self.assertTrue(word['context_nl'].strip())
                self.assertTrue(word['context_nl_literal'].strip())
                self.assertNotIn('[[', word['context_nl_literal'])
                self.assertNotIn(']]', word['context_nl_literal'])
                self.assertEqual(word['context_nl_literal'].count('['),word['context_nl_literal'].count(']'))

    def test_superlative_and_possession_are_literally_translated(self):
        keyed = {word['ru'].replace('\u0301', ''): word for word in self.words}
        self.assertEqual(keyed['самый']['context_nl_literal'], 'Dit [is] [het] meest grote huis.')
        self.assertEqual(keyed['весь']['context_nl_literal'], 'Hele dag komt regen.')
        self.assertEqual(keyed['ничего']['context_nl_literal'], 'Ik niets niet zie.')
        self.assertEqual(keyed['брат']['context_nl_literal'], 'Hier [is] [een] broer.')
        self.assertEqual(next(w['context_nl_literal'] for w in self.words if w['context_ru']=='У меня́ есть брат.'),'Bij mij is er [een] broer.')

    def test_natural_and_russian_context_retained(self):
        example=next(w for w in self.words if 'са́мый большо́й дом' in w['context_ru'])
        self.assertEqual(example['context_nl'], 'Dit is het grootste huis.')
        self.assertEqual(example['context_ru'], 'Э́то са́мый большо́й дом.')

if __name__ == '__main__':
    unittest.main()
