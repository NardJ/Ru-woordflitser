"""v6.36: hover- en klikpauze voor de bestaande aftellende kaart."""
import sys
import time
import tkinter as tk
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as rf


class PauseCardTests(unittest.TestCase):
    def setUp(self):
        self.root = tk.Tk()
        self.root.withdraw()
        self.settings = {**rf.DEFAULT_SETTINGS, 'play_audio_automatically': False,
                         'hide_after_seconds': 5}
        self.p = rf.Popup(self.root, self.settings)
        self.events = []
        self.audio_mock = patch.object(self.p, 'ensure_audio')
        self.audio_mock.start()
        self.p.show({'ru':'тот', 'nl':'die', 'context_ru':'Тот дом старый.',
                     'context_nl':'Dat huis is oud.'},
                    on_hidden=lambda word, why:self.events.append(why))
        self.root.update()

    def tearDown(self):
        self.audio_mock.stop()
        self.p.shutdown()
        self.root.destroy()

    def test_button_near_reveal_and_size_stays_same(self):
        self.assertEqual((self.p.win.winfo_width(),self.p.win.winfo_height()),(580,290))
        self.assertEqual(self.p.canvas.itemcget('pause-label','text'),'Pauzeer')
        know_box=self.p.canvas.bbox('know')
        pause_box=self.p.canvas.bbox('pause')
        self.assertLess(know_box[2],pause_box[0])
        self.assertIn(self.p.canvas.itemcget('pause','state'), ('', 'normal'))

    def test_hover_freezes_clock_and_reveal(self):
        self.p.on_pause_motion(SimpleNamespace(x=283,y=261))
        self.assertIsNotNone(self.p.countdown_paused_at)
        self.assertIsNone(self.p.reveal_timer_id)
        self.assertIsNone(self.p.hide_timer_id)
        label=self.p.canvas.itemcget('countdown-label','text')
        self.assertTrue(label.startswith('Antwoord over '))
        self.assertEqual(self.p.canvas.itemcget('pause-bg','fill'),'#486b94')
        self.root.after(900, self.root.quit)
        self.root.mainloop()
        self.assertFalse(self.p.revealed)
        self.assertEqual(self.p.canvas.itemcget('countdown-label','text'),label)
        self.p.on_pause_motion(SimpleNamespace(x=198,y=260))
        self.assertIsNone(self.p.countdown_paused_at)
        self.assertIsNotNone(self.p.reveal_timer_id)
        self.assertIsNotNone(self.p.hide_timer_id)
        self.assertAlmostEqual(self.p.hide_deadline - time.monotonic(),5,delta=.25)
        self.assertEqual(self.p.canvas.itemcget('pause-label','text'),'Pauzeer')

    def test_click_locks_and_second_click_resumes_even_hovered(self):
        self.p.on_pause_motion(SimpleNamespace(x=283,y=261))
        self.p.toggle_countdown_pause()
        self.assertTrue(self.p.pause_locked)
        self.assertEqual(self.p.canvas.itemcget('pause-label','text'),'Hervat')
        self.p.on_pause_leave()
        self.assertIsNotNone(self.p.countdown_paused_at)
        self.p.on_pause_motion(SimpleNamespace(x=283,y=261))
        self.p.toggle_countdown_pause()
        self.assertFalse(self.p.pause_locked)
        self.assertIsNone(self.p.countdown_paused_at)
        self.assertIsNotNone(self.p.hide_timer_id)
        self.p.on_pause_motion(SimpleNamespace(x=284,y=260))
        self.assertIsNone(self.p.countdown_paused_at)
        self.p.on_pause_leave()
        self.p.on_pause_motion(SimpleNamespace(x=283,y=261))
        self.assertIsNotNone(self.p.countdown_paused_at)

    def test_reveal_does_not_happen_after_elapsed_time_when_paused(self):
        self.p.on_pause_motion(SimpleNamespace(x=283,y=261))
        # Backdate reference: after a huge monotonic interval the number stays frozen.
        original=self.p.hide_deadline
        with patch.object(rf.time,'monotonic',return_value=time.monotonic()+30):
            self.p.update_countdown()
            self.p.hide()
            self.p.reveal()
        self.assertFalse(self.p.revealed)
        self.assertEqual(self.p.hide_deadline,original)
        self.assertEqual(self.events,[])
        self.p.toggle_countdown_pause()  # lock while hovered
        self.p.mark_known()  # Manual reveal still always works
        self.assertTrue(self.p.revealed)
        self.assertIsNone(self.p.hide_deadline)
        self.assertEqual(self.p.canvas.itemcget('pause','state'),'hidden')
        self.assertEqual(self.p.canvas.itemcget('good','state'),'normal')

    def test_change_duration_while_paused(self):
        self.p.toggle_countdown_pause()
        self.p.set_countdown_seconds(11)
        self.assertEqual(self.p.canvas.itemcget('countdown-label','text'),'Antwoord over 4 s')
        self.assertIsNone(self.p.hide_timer_id)
        self.assertIsNone(self.p.reveal_timer_id)
        self.p.toggle_countdown_pause()
        self.assertAlmostEqual(self.p.hide_deadline-time.monotonic(),11,delta=.25)
        self.assertIsNotNone(self.p.reveal_timer_id)

    def test_next_card_resets_locked_pause(self):
        self.p.toggle_countdown_pause()
        self.p.next_card()
        self.assertFalse(self.p.pause_locked)
        self.assertIsNone(self.p.countdown_paused_at)
        self.assertEqual(self.events,['next'])
        self.p.show({'ru':'так','nl':'zo'})
        self.assertEqual(self.p.canvas.itemcget('pause-label','text'),'Pauzeer')
        self.assertIsNotNone(self.p.hide_timer_id)

    def test_pause_is_armed_while_initial_audio_waits(self):
        self.p.cancel_timers()
        self.p.awaiting_initial_audio=True
        self.p.hide_deadline=None
        self.p.on_pause_motion(SimpleNamespace(x=280,y=260))
        self.assertIsNone(self.p.countdown_paused_at)
        self.p.begin_card_countdown()
        self.assertIsNotNone(self.p.countdown_paused_at)
        self.assertEqual(self.p.canvas.itemcget('countdown-label','text'),'Antwoord over 2 s')
        self.assertIsNone(self.p.hide_timer_id)

if __name__ == '__main__':unittest.main()
