"""Regression: clicking Good/Wrong must leave enough time to click Next."""
import sys
import time
from pathlib import Path
import tkinter as tk
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as rf


class RatingTimeoutTests(unittest.TestCase):
    def setUp(self):
        self.root = tk.Tk()
        self.root.withdraw()
        self.settings = {**rf.DEFAULT_SETTINGS,
                         'play_audio_automatically': False,
                         'hide_after_seconds': 0.10,
                         'reveal_after_seconds': 0.01}
        self.popup = rf.Popup(self.root, self.settings)
        self.events = []
        with patch.object(self.popup, 'ensure_audio'):
            self.popup.show({'ru': 'ко́шка', 'nl': 'kat'},
                            lambda word, result: self.events.append(result))
        self.popup.reveal()
        self.root.update()

    def tearDown(self):
        self.popup.shutdown()
        self.root.destroy()

    def test_good_does_not_auto_close_and_next_saves_good(self):
        self.popup.canvas.event_generate('<Button-1>', x=246, y=270)
        self.root.update()
        self.assertEqual(self.popup.rated_result, 'good')
        self.assertEqual(self.popup.timer_ids, [])
        time.sleep(0.14)
        self.root.update()
        self.assertIsNotNone(self.popup.active_word)
        self.assertEqual(self.events, [])
        self.popup.canvas.event_generate('<Button-1>', x=405, y=270)
        self.root.update()
        self.assertEqual(self.events, ['next:good'])

    def test_wrong_does_not_auto_close_and_next_saves_wrong(self):
        self.popup.canvas.event_generate('<Button-1>', x=92, y=270)
        self.root.update()
        time.sleep(0.14)
        self.root.update()
        self.assertIsNotNone(self.popup.active_word)
        self.popup.canvas.event_generate('<Button-1>', x=405, y=270)
        self.root.update()
        self.assertEqual(self.events, ['next:wrong'])

    def test_without_rating_auto_timeout_still_closes(self):
        time.sleep(0.14)
        self.root.update()
        self.assertIsNone(self.popup.active_word)
        self.assertEqual(self.events, ['exposed'])


if __name__ == '__main__':
    unittest.main()
