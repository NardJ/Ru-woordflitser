"""v6.12: genuine new-card supply and unchanged existing progress."""
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
import sys
sys.path.insert(0,str(Path(__file__).parents[1]))
import russische_woordflitser as rp

class VocabExpansionTests(unittest.TestCase):
    def test_exact_1000_and_grammar_categories(self):
        words=rp.all_words()
        self.assertEqual(len(words),1125)
        self.assertEqual(len({rp.word_key(w) for w in words}),1125)
        categories = {'zelfstandig naamwoord': 350, 'werkwoord':250,
                      'bijvoeglijk naamwoord':150,'functiewoord / bijwoord':150,
                      'uitdrukking':100}
        for cat, expected in categories.items():
            # Historische verdeling van de eerste 1.000 kaarten intact.
            actual=sum(w.get('type','zelfstandig naamwoord')==cat for w in words[:1000])
            self.assertEqual(actual, expected)
        self.assertEqual(len([w for w in words if w.get('ik')]),252)

    def test_unchanged_thirty_cards(self):
        original=json.loads((Path(__file__).parents[2]/'russische-woordflitser-v6_11'/'words.json').read_text()) if (Path(__file__).parents[2]/'russische-woordflitser-v6_11'/'words.json').exists() else None
        if original is not None:
            self.assertEqual(rp.all_words()[:30],original)
        self.assertEqual(rp.word_key(rp.all_words()[0]),'кошка')

    def test_old_30_known_does_not_prevent_real_new_words(self):
        words=rp.all_words()
        with tempfile.TemporaryDirectory() as t:
            with patch.object(rp, 'STATE_FILE', Path(t)/'progress.json'):
                old = {'words':{rp.word_key(w):{'shown_count':1, 'last_result':'good',
                               'next_due_other_count':20000,'good_streak':1}
                               for w in words[:30]},'shown_total':30,
                               'cards_since_new':5, 'scheduler_version':rp.SCHEDULER_VERSION}
                rp.save_json(rp.STATE_FILE,old)
                scheduler=rp.Scheduler(words)
                first=scheduler.choose({'new_word_every':5})
                self.assertNotIn(rp.word_key(first),old['words'])
                new_keys=[]
                for i in range(25):
                    word=scheduler.choose({'new_word_every':5})
                    if rp.word_key(word) not in scheduler.state['words']:
                        new_keys.append(rp.word_key(word))
                    scheduler.note_shown(word)
                    scheduler.record_result(word,'exposed')
                self.assertEqual(len(new_keys),5)
                self.assertEqual(rp.Scheduler(words).state['new_total'],5)
                self.assertEqual(rp.vocabulary_score(scheduler.state),30)

if __name__=='__main__': unittest.main()
