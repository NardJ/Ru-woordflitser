"""Regression v6.50: tray icon remains AppIndicator and volume popup works."""
import importlib.util
from pathlib import Path
import sys
import unittest
from unittest.mock import MagicMock, patch

BASE = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('tray_icon_test_v650', BASE / 'tray_icon.py')
tray = importlib.util.module_from_spec(spec)
spec.loader.exec_module(tray)


class TrayPopupTests(unittest.TestCase):
    def fake_gtk(self):
        Gtk = MagicMock()
        Gtk.init_check.return_value = True
        items = {}
        def named_item(label):
            item = MagicMock()
            items[label] = item
            return item
        Gtk.MenuItem.new_with_label.side_effect = named_item
        Gtk.RadioMenuItem.new_with_label_from_widget.side_effect = lambda *_: MagicMock()
        Gtk.CheckMenuItem.new_with_label.side_effect = lambda *_: MagicMock()
        Gtk.SeparatorMenuItem.side_effect = lambda: MagicMock()
        Gtk.Window.side_effect = lambda *args, **kwargs: MagicMock(name='volume_window')
        # Keep exact reference of slider widget.
        scale = MagicMock(name='slider')
        Gtk.Scale.new_with_range.return_value = scale
        Indicator = MagicMock()
        GLib = MagicMock()
        return Gtk, GLib, Indicator, items, scale

    def test_primary_icon_and_interactive_slider(self):
        Gtk, GLib, Indicator, items, scale = self.fake_gtk()
        with patch.object(tray, 'gtk_modules', return_value=(Gtk, GLib, Indicator)), \
             patch.object(tray, 'selected_volume', return_value=175), \
             patch.object(tray.socket, 'socket') as socket_stub, \
             patch.object(sys, 'argv', ['tray_icon.py', '/tmp/test-v650.sock', '/tmp/test-v650.pause']):
            self.assertEqual(tray.main(), 0)
            # Primary backend restored regardless of DISPLAY / X11.
            Indicator.Indicator.new.assert_called_once()
            Gtk.StatusIcon.new_from_file.assert_not_called()
            volume_menu_item = items['Uitspraakvolume… (175%)']
            clicked = [call.args[1] for call in volume_menu_item.connect.call_args_list
                       if call.args[0] == 'activate']
            self.assertEqual(len(clicked), 1)
            clicked[0](volume_menu_item)
            delayed_popups = [call for call in GLib.timeout_add.call_args_list
                              if call.args[0] == 80]
            self.assertEqual(len(delayed_popups), 1)
            # Delayed callback runs after tray menu releases its mouse grab.
            delayed_popups[0].args[1]()
            Gtk.Window.assert_called_once()
            window = Gtk.Window.return_value if not Gtk.Window.side_effect else Gtk.Window.mock_calls
            created = Gtk.Window.side_effect
            # Each window is a single-child GTK container (no double add).
            # The instance is reached via Gtk.Frame's parent association.
            frame = Gtk.Frame.return_value
            wrapper = Gtk.Box.return_value
            frame.add.assert_called_once_with(wrapper)
            # no second direct window.add call: test via patched custom factory below
            scale.connect.assert_called_once()
            self.assertEqual(scale.connect.call_args.args[0], 'value-changed')
            changed = scale.connect.call_args.args[1]
            scale.get_value.return_value = 186
            changed(scale)
            flushes = [call for call in GLib.timeout_add.call_args_list
                       if call.args[0] == 120]
            self.assertEqual(len(flushes), 1)
            flushes[0].args[1]()
            client = socket_stub.return_value.__enter__.return_value
            client.sendall.assert_called_with(b'volume:186\n')

    def test_window_has_exactly_one_child(self):
        Gtk, GLib, Indicator, items, scale = self.fake_gtk()
        actual_window = MagicMock(name='volume_window')
        Gtk.Window.side_effect = None
        Gtk.Window.return_value = actual_window
        with patch.object(tray, 'gtk_modules', return_value=(Gtk, GLib, Indicator)), \
             patch.object(sys, 'argv', ['tray_icon.py', '/tmp/test-v650.sock', '/tmp/test-v650.pause']):
            tray.main()
            item = next(value for key, value in items.items() if key.startswith('Uitspraakvolume'))
            item.connect.call_args.args[1](item)
            delayed = next(c for c in GLib.timeout_add.call_args_list if c.args[0] == 80)
            delayed.args[1]()
            self.assertEqual(actual_window.add.call_count, 1, 'GTK Window mag maar 1 child hebben')
            actual_window.add.assert_called_once_with(Gtk.Frame.return_value)


if __name__ == '__main__':
    unittest.main()
