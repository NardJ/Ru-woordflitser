"""v6.49: upgrades preserve *all* keys/values, including empty themes and 200% audio."""
import importlib.util
import json
from pathlib import Path
import subprocess
import tempfile
import unittest

BASE = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('settings_migration', BASE / 'settings_migration.py')
migration = importlib.util.module_from_spec(spec)
spec.loader.exec_module(migration)


class SettingsMigrationTests(unittest.TestCase):
    def test_all_existing_settings_unchanged(self):
        old = {
            'direction': 'nl-ru', 'selected_themes': ['natuur', 'handelingen'],
            'audio_volume': 189, 'normalize_audio': False,
            'speak_examples_automatically': False, 'interval_minutes': 15,
            'hide_after_seconds': 11, 'new_word_every': 8,
            'custom_future_option': {'x': [12, None, False]},
        }
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'settings.json'
            path.write_text(json.dumps(old), encoding='utf-8')
            migration.migrate(path)
            new = json.loads(path.read_text(encoding='utf-8'))
            for key, value in old.items():
                self.assertEqual(new[key], value, key)
            self.assertEqual(set(new), set(old) | set(migration.NEW_DEFAULTS))
            self.assertEqual(migration.migrate(path), ())

    def test_empty_themes_and_zero_are_preserved(self):
        old = {'direction': 'nl-ru', 'selected_themes': [], 'audio_volume': 0}
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'settings.json'
            path.write_text(json.dumps(old), encoding='utf-8')
            migration.migrate(path)
            new = json.loads(path.read_text(encoding='utf-8'))
            self.assertEqual(new['selected_themes'], [])
            self.assertEqual(new['audio_volume'], 0)
            self.assertEqual(new['direction'], 'nl-ru')

    def test_invalid_settings_must_never_be_overwritten(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'settings.json'
            for invalid in ['not json', '[]', 'null', '{"hello":']:
                with self.subTest(invalid=invalid):
                    path.write_text(invalid, encoding='utf-8')
                    with self.assertRaises((ValueError, TypeError, json.JSONDecodeError)):
                        migration.migrate(path)
                    self.assertEqual(path.read_text(encoding='utf-8'), invalid)

    def test_update_script_preserves_preferences(self):
        with tempfile.TemporaryDirectory() as tmp:
            tmp = Path(tmp)
            home = tmp / 'home'
            home.mkdir()
            target = tmp / 'old-app'
            target.mkdir()
            (target / 'russische_woordflitser.py').write_text('# old app', encoding='utf-8')
            (target / 'start.sh').write_text('#!/bin/sh\nif [ "$1" = "--status" ]; then echo "Gestopt"; fi\n', encoding='utf-8')
            (target / 'start.sh').chmod(0o755)
            (target / 'words.json').write_text('[]', encoding='utf-8')
            prefs = {'direction': 'nl-ru', 'selected_themes': [], 'audio_volume': 197,
                     'normalize_audio': False, 'my_custom_option': 'keep me'}
            (target / 'settings.json').write_text(json.dumps(prefs), encoding='utf-8')
            # No internet or actual app startup: updater calls start.sh --refresh-frequency,
            # so the test stub simply returns success.
            import os
            env = dict(os.environ, HOME=str(home), XDG_DATA_HOME=str(home / 'localdata'))
            p = subprocess.run(['bash', str(BASE / 'update_existing.sh'), str(target)],
                               capture_output=True, text=True, timeout=45, env=env)
            self.assertEqual(p.returncode, 0, f'{p.stdout}\n{p.stderr}')
            actual = json.loads((target / 'settings.json').read_text(encoding='utf-8'))
            for k, v in prefs.items():
                self.assertEqual(actual[k], v)
            self.assertTrue(list(target.glob('settings.json.backup-*')))
            self.assertTrue((target / 'tray_icon.py').exists())
            self.assertTrue((target / 'tray_xapp.py').exists())


if __name__ == '__main__':
    unittest.main()
