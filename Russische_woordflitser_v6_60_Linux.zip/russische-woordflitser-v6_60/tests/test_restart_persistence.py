"""Regressions for real progress persistence across --demo and --once restarts."""
import contextlib
import io
from pathlib import Path
import sys
import tempfile
import tkinter as tk
import unittest
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as rf

WORDS = [{'ru': f'слово{i}', 'nl': f'woord{i}'} for i in range(30)]


class RestartPersistenceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.path = Path(self.temp.name) / 'progress.json'
        self.patches = [patch.object(rf, 'STATE_FILE', self.path),
                        patch.object(rf, 'all_words', return_value=WORDS)]
        for p in self.patches:
            p.start()
        self.settings = {**rf.DEFAULT_SETTINGS, 'play_audio_automatically': False}

    def tearDown(self):
        for p in reversed(self.patches):
            p.stop()
        self.temp.cleanup()

    def make_app(self, **args):
        root = tk.Tk()
        root.withdraw()
        app = rf.Application(root, self.settings, **args)
        self.addCleanup(root.destroy)
        self.addCleanup(app.shutdown)
        return app, root

    def test_once_saves_good_before_next_and_after_restart(self):
        app, root = self.make_app(once=True)
        with patch.object(app.popup, 'ensure_audio'):
            app.try_popup(manual=True)
            word = app.popup.active_word
            key = rf.word_key(word)
            app.popup.reveal()
            app.popup.mark_good()
            # Durable already: no Next click, no hide, no wait.
            saved = rf.load_json(self.path, {})['words'][key]
            self.assertEqual(saved['last_result'], 'good')
            self.assertEqual(saved['successes'], 1)
            self.assertEqual(saved['next_due_other_count'], 10)
            # One click counts once even if the user clicks twice or closes.
            app.popup.mark_good()
            app.popup.next_card()
            root.update()
            self.assertEqual(rf.load_json(self.path, {})['words'][key]['successes'], 1)
            app.shutdown()
            app.popup.hide(result='dismissed')
        app2, _ = self.make_app(once=True)
        self.assertEqual(app2.sched.state['words'][key]['last_result'], 'good')
        self.assertEqual(app2.sched.state['words'][key]['successes'], 1)
        # A correct word is not due again immediately, even on restart.
        picked = app2.sched.choose(self.settings)
        self.assertNotEqual(rf.word_key(picked), key)

    def test_demo_writes_wrong_and_preserves_on_restart(self):
        app, _ = self.make_app(demo=True)
        with patch.object(app.popup, 'ensure_audio'):
            app.try_popup(manual=True)
            key = rf.word_key(app.popup.active_word)
            app.popup.reveal()
            app.popup.mark_wrong()
        self.assertEqual(rf.load_json(self.path, {})['words'][key]['failures'], 1)
        app2, _ = self.make_app(demo=True)
        self.assertEqual(app2.sched.state['words'][key]['last_result'], 'wrong')
        self.assertEqual(app2.sched.state['words'][key]['next_due_other_count'], 3)

    def test_progress_cli_reads_real_json(self):
        scheduler = rf.Scheduler(WORDS)
        scheduler.note_shown(WORDS[0])
        scheduler.record_result(WORDS[0], 'good')
        out = io.StringIO()
        with contextlib.redirect_stdout(out):
            rf.show_progress()
        self.assertIn('Laatst Goed: 1', out.getvalue())
        self.assertIn('na 10 andere kaarten', out.getvalue())

    def test_random_choice_for_fresh_word(self):
        scheduler = rf.Scheduler(WORDS)
        with patch.object(rf.random, 'choice', side_effect=lambda pool: pool[-1]) as mocked:
            first = scheduler.choose(self.settings)
        self.assertIn(rf.word_key(first), {rf.word_key(w) for w in WORDS[:8]})
        self.assertTrue(mocked.called)

    def test_before_next_new_slot_known_words_fill_ratio(self):
        scheduler = rf.Scheduler(WORDS)
        for word in WORDS[:2]:
            scheduler.note_shown(word)
            scheduler.record_result(word, 'good')
        chosen = scheduler.choose(self.settings)
        # Een bekende kaart kan als neutrale oefening terugkomen zodat
        # het gekozen percentage nieuwe kaarten niet wordt overschreden.
        self.assertIn(rf.word_key(chosen), {rf.word_key(w) for w in WORDS[:2]})


if __name__ == '__main__':
    unittest.main()
