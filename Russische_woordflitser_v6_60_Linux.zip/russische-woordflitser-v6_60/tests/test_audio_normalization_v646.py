"""v6.46 — echte FFmpeg-normalisatie, offline-cache en fallback."""
import json
import shutil
import subprocess
import sys
import tempfile
import time
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as rf


@unittest.skipUnless(shutil.which('ffmpeg'), 'ffmpeg ontbreekt')
class AudioNormalizationTests(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.TemporaryDirectory()
        self.addCleanup(self.dir.cleanup)
        self.base = Path(self.dir.name)
        self.original = self.base / 'sample.mp3'
        self.cache = self.base / 'derived'
        self.cache_patch = patch.object(rf, 'NORMALIZED_AUDIO_DIR', self.cache)
        self.cache_patch.start()
        self.addCleanup(self.cache_patch.stop)
        self.make_sample(-25)

    def make_sample(self, decibels):
        subprocess.run([
            'ffmpeg', '-hide_banner', '-loglevel', 'error', '-y',
            '-f', 'lavfi', '-i', 'sine=frequency=530:duration=1.4:sample_rate=48000',
            '-af', f'volume={decibels}dB', '-c:a', 'libmp3lame', '-q:a', '4',
            str(self.original)
        ], check=True, timeout=8)

    @staticmethod
    def integrated_loudness(path):
        result = subprocess.run([
            'ffmpeg', '-hide_banner', '-loglevel', 'info', '-nostdin',
            '-i', str(path), '-af',
            'loudnorm=I=-16:TP=-1.5:LRA=11:print_format=json',
            '-f', 'null', '-'
        ], capture_output=True, text=True, check=True, timeout=8)
        start = result.stderr.rfind('"input_i"')
        begin = result.stderr.rfind('{', 0, start)
        end = result.stderr.find('}', start)
        data = json.loads(result.stderr[begin:end+1])
        return float(data['input_i']), float(data['input_tp'])

    def test_real_soft_mp3_becomes_louder_and_preserves_original(self):
        initial_bytes = self.original.read_bytes()
        original_lufs, _ = self.integrated_loudness(self.original)
        normalized = rf.normalized_audio_path(self.original)
        self.assertNotEqual(normalized, self.original)
        self.assertTrue(normalized.is_file())
        target_lufs, peak = self.integrated_loudness(normalized)
        self.assertAlmostEqual(target_lufs, -16, delta=1.5)
        self.assertGreater(target_lufs, original_lufs + 12)
        self.assertLessEqual(peak, -1.1)
        self.assertEqual(initial_bytes, self.original.read_bytes())
        self.assertEqual(rf.normalized_audio_path(self.original), normalized)
        self.assertEqual(len(list(self.cache.glob('*.mp3'))), 1)

    def test_different_sources_normalize_to_consistent_loudness(self):
        quiet = rf.normalized_audio_path(self.original)
        self.make_sample(-13)
        loud = rf.normalized_audio_path(self.original)
        self.assertNotEqual(quiet, loud)
        first_lufs, _ = self.integrated_loudness(quiet)
        second_lufs, _ = self.integrated_loudness(loud)
        self.assertAlmostEqual(first_lufs, second_lufs, delta=1.2)

    def test_invalid_file_falls_back_cleanly(self):
        broken = self.base / 'broken.mp3'
        broken.write_bytes(b'x'*201)
        self.assertEqual(rf.normalized_audio_path(broken), broken)
        self.assertFalse(list(self.cache.glob('normalizing-*')))

    def test_ffmpeg_missing_returns_original(self):
        with patch.object(rf.shutil, 'which', return_value=None):
            self.assertEqual(rf.normalized_audio_path(self.original), self.original)

    def test_all_players_get_normalized_path_and_slider_volume(self):
        normalized = rf.normalized_audio_path(self.original)
        real_which = shutil.which
        for player in ('ffplay', 'mpv', 'cvlc'):
            with self.subTest(player=player):
                with patch.object(rf.shutil, 'which', side_effect=lambda name, p=player:
                                  real_which('ffmpeg') if name == 'ffmpeg' else
                                  f'/fake/{p}' if name == p else None), \
                     patch.object(rf.subprocess, 'Popen') as popen:
                    rf.play_audio(self.original, volume=65)
                args = popen.call_args.args[0]
                self.assertEqual(args[-1], str(normalized))
                if player == 'ffplay':
                    self.assertEqual(args[args.index('-volume')+1], '65')
                elif player == 'mpv':
                    self.assertIn('--volume=65', args)
                else:
                    self.assertIn('--gain=0.65', args)

    def test_zero_volume_skips_normalization_and_keeps_mute(self):
        with patch.object(rf.shutil, 'which', side_effect=lambda name:
                          '/fake/ffplay' if name == 'ffplay' else None), \
             patch.object(rf, 'normalized_audio_path') as normalize, \
             patch.object(rf.subprocess, 'Popen') as popen:
            rf.play_audio(self.original, volume=0)
        normalize.assert_not_called()
        args = popen.call_args.args[0]
        self.assertEqual(args[-1], str(self.original))
        self.assertEqual(args[args.index('-volume')+1], '0')


if __name__ == '__main__':
    unittest.main()
