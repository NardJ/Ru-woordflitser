"""GUI regressietests. Start met: xvfb-run -a python3 -m unittest discover -s tests -v"""
import sys
from pathlib import Path
import tkinter as tk
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as rf


class TestAutoplay(unittest.TestCase):
    def setUp(self):
        self.root = tk.Tk()
        self.root.withdraw()
        self.word = {'ru': 'я́блоко', 'nl': 'appel'}
        self.settings = {**rf.DEFAULT_SETTINGS,
                         'reveal_after_seconds': 3, 'hide_after_seconds': 9}

    def tearDown(self):
        self.root.destroy()

    def test_speaks_once_at_show_not_reveal(self):
        self.settings['play_audio_automatically'] = True
        popup = rf.Popup(self.root, self.settings)
        with patch.object(popup, 'play_cached_voice', return_value=True) as player, \
             patch.object(popup, 'ensure_audio') as generator:
            popup.show(self.word)
            self.assertEqual(player.call_count, 1)
            self.assertEqual(generator.call_count, 0)
            popup.reveal()
            self.assertEqual(player.call_count, 1, 'Niet dubbel afspelen na onthullen')
            popup.hide()

    def test_missing_mp3_is_prepared_for_one_initial_play(self):
        self.settings['play_audio_automatically'] = True
        popup = rf.Popup(self.root, self.settings)
        with patch.object(popup, 'play_cached_voice', return_value=False) as player, \
             patch.object(popup, 'ensure_audio') as generator:
            popup.show(self.word)
            self.assertEqual(player.call_count, 1)
            generator.assert_called_once_with(self.word, play_when_ready=True)
            popup.reveal()
            generator.assert_called_once_with(self.word, play_when_ready=True)
            popup.hide()

    def test_silent_setting_disables_automatic_sound(self):
        self.settings['play_audio_automatically'] = False
        popup = rf.Popup(self.root, self.settings)
        with patch.object(popup, 'play_cached_voice', return_value=True) as player, \
             patch.object(popup, 'ensure_audio') as generator:
            popup.show(self.word)
            popup.reveal()
            self.assertEqual(player.call_count, 0)
            generator.assert_called_once_with(self.word, play_when_ready=False)
            popup.hide()

    def test_close_stops_audio_player(self):
        class FakePlayer:
            terminated = False
            def poll(self):
                return None
            def terminate(self):
                self.terminated = True

        popup = rf.Popup(self.root, self.settings)
        with patch.object(popup, 'play_cached_voice', return_value=True):
            popup.show(self.word)
        fake = FakePlayer()
        popup.audio_process = fake
        popup.close_current_card()
        self.assertTrue(fake.terminated, 'Bij wegklikken moet de lopende MP3 stoppen')
        self.assertIsNone(popup.audio_process)

    def test_close_button_still_dismisses_without_marking_seen(self):
        seen_events = []
        popup = rf.Popup(self.root, self.settings)
        with patch.object(popup, 'play_cached_voice', return_value=True):
            popup.show(self.word, lambda w, seen: seen_events.append((w, seen)))
            popup.close_current_card()
            self.assertIsNone(popup.active_word)
            self.assertEqual(seen_events, [(self.word, 'dismissed')])


if __name__ == '__main__':
    unittest.main()
