"""Regressietests: persoonlijke kaarttekst los van de twee oefenrichtingen."""
import json
from pathlib import Path
import tempfile
import tkinter as tk
import unittest
from unittest.mock import patch

import russische_woordflitser as wf


class WordEditStorageTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name)
        self.word = {'ru': 'свой', 'nl': 'eigen; zijn eigen',
                     'context_ru': 'Я люблю́ свой дом.', 'context_nl': 'Ik hou van mijn huis.'}
        (self.base / 'words.json').write_text(json.dumps([self.word], ensure_ascii=False), encoding='utf-8')
        self.edits_patch = patch.object(wf, 'EDITS_FILE', self.base / 'woordcorrecties.json')
        self.base_patch = patch.object(wf, 'BASE', self.base)
        self.extra_patch = patch.object(wf, 'EXTRA_FILE', self.base / 'eigen_woorden.json')
        self.prog_patch = patch.object(wf, 'STATE_FILE', self.base / 'progress.json')
        for p in (self.edits_patch, self.base_patch, self.extra_patch, self.prog_patch):
            p.start(); self.addCleanup(p.stop)

    def test_save_reload_restore_and_keep_base_unchanged(self):
        edited = {'nl': 'mijn/jouw/zijn/haar eigen', 'context_ru': self.word['context_ru'],
                  'context_nl': self.word['context_nl']}
        words = wf.all_words()
        wf.persist_word_edit(words[0], edited)
        self.assertEqual(wf.all_words()[0]['nl'], edited['nl'])
        self.assertEqual(wf.load_json(self.base / 'words.json', [])[0]['nl'], self.word['nl'])
        self.assertEqual(wf.word_key(words[0]), 'свой')
        wf.persist_word_edit(words[0], None)
        self.assertEqual(wf.all_words()[0]['nl'], self.word['nl'])
        self.assertEqual(wf.load_word_edits(), {})

    def test_invalid_edits_do_not_touch_stored_file(self):
        words = wf.all_words()
        with self.assertRaises(ValueError):
            wf.persist_word_edit(words[0], {'nl': '', 'context_ru':'', 'context_nl':''})
        self.assertFalse(wf.EDITS_FILE.exists())
        with self.assertRaises(ValueError):
            wf.persist_word_edit(words[0], {'nl': 'X', 'context_ru':'test', 'context_nl':''})
        self.assertFalse(wf.EDITS_FILE.exists())

    def test_independent_scores_and_same_corrected_label(self):
        words = wf.all_words()
        sched = wf.Scheduler(words, direction='ru-nl')
        sched.note_shown(words[0]); sched.record_result(words[0], 'good')
        wf.persist_word_edit(words[0], {'nl':'mijn/jouw/zijn/haar eigen',
                         'context_ru':self.word['context_ru'], 'context_nl':self.word['context_nl']})
        self.assertEqual(sched.vocabulary_score('ru-nl'), 1)
        sched.set_direction('nl-ru')
        self.assertEqual(sched.vocabulary_score('nl-ru'), 0)
        self.assertEqual(sched.words[0]['nl'], 'mijn/jouw/zijn/haar eigen')
        self.assertEqual(wf.Scheduler(wf.all_words(),direction='nl-ru').words[0]['nl'],
                         'mijn/jouw/zijn/haar eigen')


class EditorGuiTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name)
        self.word = {'ru': 'свой', 'nl': 'eigen',
                     'context_ru': 'Это мой дом.', 'context_nl': 'Dit is mijn huis.'}
        (self.base / 'words.json').write_text(json.dumps([self.word],ensure_ascii=False),encoding='utf-8')
        for x,y in [('BASE',self.base),('EDITS_FILE',self.base / 'woordcorrecties.json'),
                    ('EXTRA_FILE',self.base/'eigen_woorden.json'),('STATE_FILE',self.base/'progress.json')]:
            p=patch.object(wf,x,y); p.start(); self.addCleanup(p.stop)
        self.root=tk.Tk(); self.root.withdraw()
        self.addCleanup(self.root.destroy)

    def test_editor_save_changes_current_card_without_recount(self):
        setting={**wf.DEFAULT_SETTINGS, 'direction':'nl-ru',
                 'play_audio_automatically':False}
        app=wf.Application(self.root, setting, once=True)
        self.addCleanup(app.shutdown)
        with patch.object(app.popup, 'ensure_audio'):
            app.try_popup(manual=True)
        card = app.popup.active_word
        self.assertEqual(app.sched.state['shown_total'], 1)
        self.assertEqual(app.popup.canvas.itemcget('russian','text'), 'eigen')
        app.popup.open_word_editor()
        self.assertIsNotNone(app.popup.edit_dialog)
        dlg=app.popup.edit_dialog
        # De eerste Entry is de NL-vertaling; bewerk en druk op Opslaan.
        entry=next(w for w in self.walk(dlg) if isinstance(w,tk.Entry))
        entry.delete(0,'end'); entry.insert(0,'mijn/jouw/zijn/haar eigen')
        save=next(w for w in self.walk(dlg) if isinstance(w,tk.Button) and w['text']=='Opslaan')
        save.invoke()
        self.assertIsNone(app.popup.edit_dialog)
        self.assertEqual(card['nl'], 'mijn/jouw/zijn/haar eigen')
        self.assertEqual(app.popup.canvas.itemcget('russian','text'), 'mijn/jouw/zijn/haar eigen')
        self.assertEqual(app.sched.state['shown_total'], 1)
        self.assertEqual(app.sched.vocabulary_score('nl-ru'), 0)
        self.assertEqual(wf.all_words()[0]['nl'], 'mijn/jouw/zijn/haar eigen')

    def test_cancel_leaves_card_open_and_same_score(self):
        setting={**wf.DEFAULT_SETTINGS, 'direction':'ru-nl',
                 'play_audio_automatically':False}
        app=wf.Application(self.root, setting, once=True)
        self.addCleanup(app.shutdown)
        with patch.object(app.popup, 'ensure_audio'):
            app.try_popup(manual=True)
        app.popup.reveal(); app.popup.mark_good()
        self.assertEqual(app.sched.vocabulary_score('ru-nl'), 1)
        app.popup.open_word_editor()
        dlg=app.popup.edit_dialog
        cancel=next(w for w in self.walk(dlg) if isinstance(w,tk.Button) and w['text']=='Annuleren')
        cancel.invoke()
        self.assertEqual(app.sched.vocabulary_score('ru-nl'), 1)
        self.assertIsNotNone(app.popup.active_word)
        self.assertEqual(app.popup.rated_result,'good')

    @staticmethod
    def walk(widget):
        for child in widget.winfo_children():
            yield child
            yield from EditorGuiTests.walk(child)

if __name__ == '__main__': unittest.main()
