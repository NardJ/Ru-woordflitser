"""Unique-word vocabulary score: latest Good adds, Wrong removes, no double count."""
import importlib
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
import tkinter as tk

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as rf
import tray_icon

WORDS = [
    {'ru': 'я́блоко', 'nl': 'appel'},
    {'ru': 'молоко́', 'nl': 'melk'},
    {'ru': 'кни́га', 'nl': 'boek'},
]


class VocabularyScoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.progress = Path(self.tmp.name) / 'progress.json'
        self.patchers = [patch.object(rf, 'STATE_FILE', self.progress),
                         patch.object(tray_icon, 'PROGRESS_FILE', self.progress)]
        for patcher in self.patchers:
            patcher.start()

    def tearDown(self):
        for patcher in reversed(self.patchers):
            patcher.stop()
        self.tmp.cleanup()

    def test_unique_known_words_and_losing_points(self):
        sched = rf.Scheduler(WORDS)
        self.assertEqual(sched.vocabulary_score(), 0)
        sched.note_shown(WORDS[0])
        sched.record_result(WORDS[0], 'good')
        self.assertEqual(sched.vocabulary_score(), 1)
        sched.record_result(WORDS[0], 'good')
        self.assertEqual(sched.vocabulary_score(), 1)  # repeated good not +1
        sched.record_result(WORDS[1], 'good')
        self.assertEqual(sched.vocabulary_score(), 2)
        sched.record_result(WORDS[0], 'wrong')
        self.assertEqual(sched.vocabulary_score(), 1)  # known word is removed
        sched.record_result(WORDS[0], 'wrong')
        self.assertEqual(sched.vocabulary_score(), 1)  # repeated wrong not -1
        sched.record_result(WORDS[2], 'wrong')
        self.assertEqual(sched.vocabulary_score(), 1)  # new word wrong = 0
        sched.record_result(WORDS[0], 'good')
        self.assertEqual(sched.vocabulary_score(), 2)  # relearned = +1
        sched.record_result(WORDS[0], 'exposed')
        sched.record_result(WORDS[1], 'dismissed')
        self.assertEqual(sched.vocabulary_score(), 2)  # no grade => no change
        self.assertEqual(tray_icon.read_vocabulary_score(), 2)

    def test_score_survives_restart_and_old_state(self):
        rf.save_json(self.progress, {'words': {
            'appel': {'last_result': 'good', 'successes': 3},
            'melk': {'last_result': 'wrong', 'successes': 8},
            'boek': {'successes': 100},  # viewed but never graded good
            'oud': {'last_result': 'good', 'good_streak': 2},
        }})
        sched = rf.Scheduler(WORDS)
        self.assertEqual(sched.vocabulary_score(), 2)
        self.assertEqual(tray_icon.read_vocabulary_score(), 2)
        sched.record_result(WORDS[1], 'good')
        self.assertEqual(rf.Scheduler(WORDS).vocabulary_score(), 3)
        self.assertEqual(tray_icon.read_vocabulary_score(), 3)

    def test_malformed_history_is_safe(self):
        self.assertEqual(rf.vocabulary_score({}), 0)
        self.assertEqual(rf.vocabulary_score({'words': []}), 0)
        self.assertEqual(rf.vocabulary_score({'words': {'a': 'good'}}), 0)
        self.assertEqual(tray_icon.read_vocabulary_score(), 0)


class VocabularyScorePopupTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.progress = Path(self.tmp.name) / 'progress.json'
        self.patchers = [patch.object(rf, 'STATE_FILE', self.progress),
                         patch.object(rf, 'all_words', return_value=WORDS)]
        for patcher in self.patchers:
            patcher.start()
        self.root = tk.Tk()
        self.root.withdraw()
        self.settings = {**rf.DEFAULT_SETTINGS, 'play_audio_automatically': False}
        self.app = rf.Application(self.root, self.settings, once=True)

    def tearDown(self):
        self.app.shutdown()
        self.root.destroy()
        for patcher in reversed(self.patchers):
            patcher.stop()
        self.tmp.cleanup()

    def visible_score(self):
        canvas = self.app.popup.canvas
        return canvas.itemcget(canvas.find_withtag('vocab-score')[0], 'text')

    def test_good_updates_popup_stats_and_disk_immediately(self):
        with patch.object(self.app.popup, 'ensure_audio'):
            self.app.try_popup(manual=True)
        self.app.popup.reveal()
        self.assertEqual(self.visible_score(), 'Bekend RU→NL: 0')
        self.app.show_statistics()
        self.assertEqual(self.app.stats_score_variable.get(), '0')
        first_word = self.app.popup.active_word
        self.app.popup.mark_good()
        self.assertEqual(self.visible_score(), 'Bekend RU→NL: 1 (+1)')
        self.assertEqual(self.app.stats_score_variable.get(), '1')
        self.assertEqual(rf.vocabulary_score(rf.load_json(self.progress, {})), 1)
        # Same button twice should never increment.
        self.app.popup.mark_good()
        self.assertEqual(self.visible_score(), 'Bekend RU→NL: 1 (+1)')
        self.app.popup.next_card()
        self.root.update()
        self.assertEqual(self.visible_score(), 'Bekend RU→NL: 1')
        self.app.popup.hide('dismissed')
        self.assertEqual(rf.Scheduler(WORDS).vocabulary_score(), 1)

    def test_wrong_removes_point(self):
        with patch.object(self.app.popup, 'ensure_audio'):
            self.app.try_popup(manual=True)
        first = self.app.popup.active_word
        self.app.popup.reveal()
        self.app.popup.mark_good()
        self.app.popup.hide('dismissed')
        with patch.object(self.app.popup, 'ensure_audio'):
            self.app.try_popup(manual=True)
        # Simulate returning known word due for practice, rather than relying
        # on the scheduler's randomness with only 3 test words.
        self.app.popup.hide('dismissed')
        with patch.object(self.app.popup, 'ensure_audio'):
            self.app.popup.show(first, self.app.after_hide)
        self.app.popup.reveal()
        self.app.popup.mark_wrong()
        self.assertEqual(self.visible_score(), 'Bekend RU→NL: 0 (-1)')
        self.assertEqual(rf.Scheduler(WORDS).vocabulary_score(), 0)


if __name__ == '__main__':
    unittest.main()
