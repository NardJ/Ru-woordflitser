"""v6.25: compact 290px popup, selected answer, atomic answer correction."""
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch
import unittest
import tkinter as tk

BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE))
import russische_woordflitser as rf

SAMPLES=[
    {'ru':'хорошо́','nl':'goed','context_ru':'Я хорошо́ спал.','context_nl':'Ik heb goed geslapen.','image':'images/v_0849.png'},
    {'ru':'тот','nl':'die; dat (mannelijk)','context_ru':'Тот дом ста́рый.','context_nl':'Dat huis is oud.'},
    {'ru':'покупа́ть','ik':'я покупа́ю','nl':'kopen','context_ru':'Я покупа́ю хлеб.','context_nl':'Ik koop brood.'},
]

class PopupV625Test(unittest.TestCase):
    def setUp(self):
        self.root=tk.Tk(); self.root.withdraw()
        self.popup=rf.Popup(self.root,{**rf.DEFAULT_SETTINGS,'play_audio_automatically':False,'popup_opacity':1.0})
    def tearDown(self):
        self.popup.shutdown();self.root.destroy()
    def show(self,word=SAMPLES[0]):
        self.popup.show(word,preserve_position=True)
        self.root.update()
    def test_geometry_and_button_height(self):
        self.show()
        self.assertEqual((self.popup.win.winfo_width(),self.popup.win.winfo_height()),(580,290))
        self.assertLessEqual(self.popup.canvas.bbox('image-panel')[3],229)
        coords=self.popup.canvas.bbox('know')
        self.assertGreaterEqual(coords[3]-coords[1],35)
        self.assertLess(self.popup.canvas.bbox('countdown-label')[3],290)
    def test_selected_button_and_correctable_rating(self):
        seen=[]
        self.popup.on_rated=lambda w,r:seen.append(r)
        self.show()
        self.popup.reveal()
        self.popup.mark_good()
        self.assertEqual(self.popup.rated_result,'good')
        self.assertEqual(self.popup.canvas.itemcget('rating-feedback','state'),'normal')
        self.assertIn('Goed opgeslagen', self.popup.canvas.itemcget('rating-feedback','text'))
        self.assertEqual(self.popup.canvas.itemcget('good-label','fill'),'#ffffff')
        self.popup.mark_wrong()
        self.assertEqual(self.popup.rated_result,'wrong')
        self.assertEqual(self.popup.canvas.itemcget('wrong-label','fill'),'#ffffff')
        self.assertIn('Fout opgeslagen',self.popup.canvas.itemcget('rating-feedback','text'))
        self.popup.mark_good()
        self.popup.mark_good()  # double click must be ignored
        self.assertEqual(seen,['good','wrong','good'])
        self.popup.show(SAMPLES[1],preserve_position=True)
        self.assertEqual(self.popup.canvas.itemcget('rating-feedback','state'),'hidden')
        self.assertEqual(self.popup.canvas.itemcget('good-label','fill'),'#216a45')

class PersistenceV625Test(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.p1=patch.object(rf,'STATE_FILE',Path(self.tmp.name)/'progress.json');self.p1.start()
        self.p2=patch.object(rf,'all_words',return_value=[SAMPLES[1]]);self.p2.start()
        self.root=tk.Tk();self.root.withdraw()
        self.app=rf.Application(self.root,{**rf.DEFAULT_SETTINGS,'play_audio_automatically':False},once=True)
        self.app.try_popup(manual=True)
        self.app.popup.reveal()
    def tearDown(self):
        self.app.shutdown();self.root.destroy();self.p2.stop();self.p1.stop();self.tmp.cleanup()
    def entry(self):
        return self.app.sched.state['words'][rf.word_key(SAMPLES[1])]
    def test_correct_one_card_without_double_counting(self):
        self.app.popup.mark_good()
        self.assertEqual(self.entry()['successes'],1)
        self.assertEqual(self.entry()['good_streak'],1)
        self.assertEqual(self.entry()['next_due_other_count'],10)
        self.app.popup.mark_wrong()
        self.assertEqual(self.app.sched.vocabulary_score(),0)
        self.assertEqual(self.entry().get('successes',0),0)
        self.assertEqual(self.entry()['failures'],1)
        self.assertEqual(self.entry()['next_due_other_count'],3)
        self.app.popup.mark_good()
        self.assertEqual(self.app.sched.vocabulary_score(),1)
        self.assertEqual(self.entry()['failures'] if 'failures' in self.entry() else 0,0)
        self.assertEqual(self.entry()['successes'],1)
        self.assertEqual(self.entry()['count'],1)
        self.assertEqual(rf.Scheduler([SAMPLES[1]]).vocabulary_score(),1)
        self.app.popup.next_card()
        self.root.update()
        self.assertEqual(rf.Scheduler([SAMPLES[1]]).vocabulary_score(),1)
    def test_wrong_to_good_corrects_score(self):
        self.app.popup.mark_wrong()
        self.app.popup.mark_good()
        self.assertEqual(self.entry()['count'],1)
        self.assertEqual(self.entry()['good_streak'],1)
        self.assertEqual(self.entry()['successes'],1)
        self.assertEqual(self.entry().get('failures',0),0)
    def test_prior_streak_is_not_inflated_by_correction(self):
        self.app.popup.mark_good();self.app.popup.next_card();self.root.update()
        self.app.popup.hide('dismissed')
        # Open opnieuw als nieuwe kaart zonder reset van score of historische reeks.
        self.app.sched.note_shown(SAMPLES[1])
        self.app.rating_card_identity=None; self.app.rating_baseline=None
        self.app.popup.show(SAMPLES[1],self.app.after_hide,preserve_position=True)
        self.app.popup.reveal()
        self.app.popup.mark_good()
        self.assertEqual(self.entry()['good_streak'],2)
        self.app.popup.mark_wrong()
        self.assertEqual(self.entry()['good_streak'],0)
        self.app.popup.mark_good()
        self.assertEqual(self.entry()['good_streak'],2)
        self.assertEqual(self.entry()['successes'],2)
        self.assertEqual(self.entry()['count'],2)

if __name__=='__main__': unittest.main()
