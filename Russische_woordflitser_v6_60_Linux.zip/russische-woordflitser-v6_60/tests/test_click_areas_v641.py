"""Versie 6.41: boven elke klik alleen woord; onder elke klik alleen voorbeeldzin."""
import sys
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch
import tkinter as tk

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as rf

WORD = {'ru': 'ко́шка', 'nl': 'kat', 'context_ru': 'Ко́шка спит.',
        'context_nl': 'De kat slaapt.'}


class ClickAreaTests(unittest.TestCase):
    def setUp(self):
        self.root = tk.Tk()
        self.root.withdraw()
        self.settings = {**rf.DEFAULT_SETTINGS, 'play_audio_automatically': False}
        self.popup = rf.Popup(self.root, self.settings)

    def tearDown(self):
        self.popup.shutdown()
        self.root.destroy()

    def show(self, direction='ru-nl', word=WORD, reveal=False):
        self.popup.settings['direction'] = direction
        with patch.object(self.popup, 'ensure_audio'):
            self.popup.show(word)
        if reveal:
            with patch.object(self.popup, 'play_cached_voice', return_value=True):
                self.popup.reveal()
        self.root.update()

    def check_click(self, x, y, expected):
        with patch.object(self.popup, 'play_cached_example', return_value=True) as example, \
             patch.object(self.popup, 'play_cached_voice', return_value=True) as word:
            self.popup.click_audio(SimpleNamespace(x=x, y=y))
        self.assertEqual(example.call_count, 1 if expected == 'example' else 0,
                         (x, y, expected))
        self.assertEqual(word.call_count, 1 if expected == 'word' else 0,
                         (x, y, expected))
        if expected == 'word':
            word.assert_called_once_with(WORD, only_word=True)
        if expected == 'example':
            example.assert_called_once_with(WORD)

    def test_entire_top_area_is_word_even_on_translation_or_empty_space(self):
        self.show()
        for x, y in [(22, 45), (32, 55), (560, 138), (380, 106),
                     (200, 88), (405, 144), (1, 100)]:
            with self.subTest(x=x, y=y):
                self.check_click(x, y, 'word')

    def test_entire_example_area_including_label_blank_space_and_image(self):
        self.show()
        for x, y in [(1, 145), (22, 150), (128, 154), (300, 157),
                     (35, 169), (376, 180), (60, 212), (500, 210),
                     (551, 230), (20, 242)]:
            with self.subTest(x=x, y=y):
                self.check_click(x, y, 'example')

    def test_no_audio_in_header_or_buttons(self):
        self.show()
        for x, y in [(100, 22), (180, 42), (20, 243), (200, 270)]:
            with self.subTest(x=x, y=y):
                self.check_click(x, y, 'none')

    def test_reverse_must_not_speak_before_reveal(self):
        self.show('nl-ru')
        for x, y in [(40, 75), (60, 180), (130, 154)]:
            self.check_click(x, y, 'none')
        with patch.object(self.popup, 'play_cached_voice', return_value=True):
            self.popup.reveal()
        self.check_click(300, 120, 'word')
        self.check_click(300, 200, 'example')

    def test_audio_cache_miss_uses_correct_mode(self):
        self.show()
        with patch.object(self.popup, 'play_cached_example', return_value=False), \
             patch.object(self.popup, 'play_cached_voice', return_value=False), \
             patch.object(self.popup, 'ensure_audio') as generate:
            self.popup.click_audio(SimpleNamespace(x=550, y=220))
            generate.assert_called_once_with(WORD, play_when_ready=True, mode='example')
            generate.reset_mock()
            self.popup.click_audio(SimpleNamespace(x=550, y=125))
            generate.assert_called_once_with(WORD, play_when_ready=True, mode='word')

    def test_actual_canvas_events_dispatch_to_correct_sound(self):
        self.show()
        self.popup.win.geometry('580x290+200+100')
        self.root.update()
        with patch.object(self.popup, 'play_cached_example', return_value=True) as example, \
             patch.object(self.popup, 'play_cached_voice', return_value=True) as word:
            for y in (165, 200, 225):
                self.popup.canvas.event_generate('<ButtonPress-1>', x=350, y=y,
                    rootx=550, rooty=100+y)
                self.popup.canvas.event_generate('<ButtonRelease-1>', x=350, y=y,
                    rootx=550, rooty=100+y)
                self.root.update()
            self.assertEqual(example.call_count, 3)
            word.assert_not_called()
            self.popup.canvas.event_generate('<ButtonPress-1>', x=345, y=100,
                rootx=545, rooty=200)
            self.popup.canvas.event_generate('<ButtonRelease-1>', x=345, y=100,
                rootx=545, rooty=200)
            self.root.update()
            word.assert_called_once_with(WORD, only_word=True)


if __name__ == '__main__':
    unittest.main()
