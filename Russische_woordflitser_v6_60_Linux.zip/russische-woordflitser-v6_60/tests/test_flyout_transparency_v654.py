"""v6.56 regression: do not require RGBA transparency for short flyouts."""
import unittest
from pathlib import Path
from test_xapp_menu_v651 import TestMenu
import tray_icon


class SeparatePopupTest(unittest.TestCase):
    def test_version_and_independent_panels(self):
        t=TestMenu(methodName='test_single_icon_and_all_pages')
        t.setUp()
        try:
            self.assertEqual(tray_icon.APP_VERSION,'6.59')
            self.assertEqual(t.menu.title_label.label,'Russische Woordflitser v6.59')
            self.assertIs(t.menu.window.child,t.menu.main_frame)
            self.assertIs(t.menu.flyout_window.child,t.menu.flyout_frame)
        finally:
            t.tearDown()

    def test_no_hack_with_transparent_unused_area(self):
        src=(Path(__file__).resolve().parents[1]/'tray_xapp.py').read_text(encoding='utf-8')
        self.assertEqual(src.count("add_class('wordflitser-panel')"),2)
        self.assertNotIn('configure_transparent_window',src)
        self.assertIn('self.flyout_window = Gtk.Window.new(Gtk.WindowType.POPUP)',src)
        self.assertIn('self.flyout_window.set_accept_focus(False)',src)
        self.assertIn('button.translate_coordinates(self.window, 0, 0)',src)


if __name__=='__main__':unittest.main()
