"""v6.44 - volume config, IPC and audio backend argument checks."""
import json
import sys
import tempfile
import tkinter as tk
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as rf
import tray_icon


class VolumeTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.base = Path(self.temp.name)
        self.config = self.base / 'settings.json'
        self.config.write_text(json.dumps({'voice': 'ru-RU-SvetlanaNeural', 'audio_volume': 75,
                                          'extra': 'keep'}), encoding='utf-8')
        self.patches = [patch.object(rf, 'BASE', self.base),
                        patch.object(rf, 'STATE_FILE', self.base/'progress.json'),
                        patch.object(rf, 'CONTROL_SOCKET', self.base/'control.sock'),
                        patch.object(rf, 'PAUSE_FILE', self.base/'pause'),
                        patch.object(rf, 'all_words', return_value=[
                            {'ru':'ма́ма', 'nl':'mama', 'context_ru':'Мама дома.'}]),
                        patch.object(tray_icon, 'SETTINGS_FILE', self.config)]
        for item in self.patches:
            item.start()
        self.root = tk.Tk()
        self.root.withdraw()
        self.app = rf.Application(self.root, {**rf.load_settings(),
            'play_audio_automatically': False})
        self.audio = patch.object(self.app.popup, 'ensure_audio')
        self.audio.start()

    def tearDown(self):
        self.audio.stop()
        self.app.shutdown()
        self.root.destroy()
        for item in reversed(self.patches):
            item.stop()
        self.temp.cleanup()

    def test_every_percent_and_persistence(self):
        for n in (0, 1, 25, 75, 100, 150, 200):
            self.app.handle_command(f'volume:{n}')
            self.assertEqual(self.app.settings['audio_volume'], n)
            self.assertEqual(self.app.popup.settings['audio_volume'], n)
            self.assertEqual(tray_icon.selected_volume(), n)
            self.assertEqual(rf.load_settings()['audio_volume'], n)
        self.assertEqual(json.loads(self.config.read_text())['extra'], 'keep')

    def test_reject_bad_volume_without_changing_anything(self):
        for value in ('-1','201','abc','15.2','5;quit','', 'NaN'):
            with self.assertRaises(ValueError, msg=value):
                self.app.handle_command('volume:' + value)
        self.assertEqual(self.app.settings['audio_volume'], 75)
        self.assertEqual(tray_icon.selected_volume(), 75)

    def test_player_parameters_all_backends(self):
        p = self.base/'test.mp3'
        p.write_bytes(b'ID3')
        for volume in (0, 33, 100, 150, 200):
            for player in ('ffplay', 'mpv', 'cvlc'):
                with self.subTest(volume=volume, player=player):
                    with patch.object(rf.shutil, 'which', side_effect=lambda name:
                                     '/usr/bin/'+name if name == player else None), \
                         patch.object(rf.subprocess, 'Popen') as popen:
                        self.assertIsNotNone(rf.play_audio(p, volume))
                    args = popen.call_args.args[0]
                    if player == 'ffplay':
                        self.assertEqual(args[args.index('-volume')+1], str(min(volume,100)))
                        if volume > 100:
                            self.assertIn('-af', args)
                            self.assertIn(f'volume={volume/100:.2f},alimiter=limit=0.95:level=false', args)
                        else:
                            self.assertNotIn('-af', args)
                    elif player == 'mpv':
                        self.assertIn(f'--volume={min(volume,100)}', args)
                        if volume > 100:
                            self.assertIn(f'--af=lavfi=[volume={volume/100:.2f},alimiter=limit=0.95:level=false]', args)
                    else:
                        self.assertIn(f'--gain={volume/100:.2f}', args)

    def test_both_word_and_example_use_same_volume(self):
        word = {'ru': 'ма́ма', 'nl':'mama', 'context_ru':'Мама дома.'}
        self.app.set_audio_volume(19)
        with patch.object(rf, 'speech_path', return_value=self.base/'sound.mp3'), \
             patch.object(Path, 'is_file', return_value=True), \
             patch.object(rf, 'play_audio') as player:
            self.app.popup.play_cached_voice(word, only_word=True)
            self.app.popup.play_cached_example(word)
            self.assertEqual(player.call_count, 2)
            self.assertEqual([call.args[1] for call in player.call_args_list], [19, 19])

    def test_corrupt_or_missing_settings_get_default(self):
        for bad in (-1, 201, 'oops', None, []):
            self.config.write_text(json.dumps({'audio_volume':bad}), encoding='utf-8')
            self.assertEqual(rf.load_settings()['audio_volume'], 75)
            self.assertEqual(tray_icon.selected_volume(), 75)
        self.config.write_text('{}', encoding='utf-8')
        self.assertEqual(rf.load_settings()['audio_volume'], 75)


if __name__ == '__main__':
    unittest.main()
