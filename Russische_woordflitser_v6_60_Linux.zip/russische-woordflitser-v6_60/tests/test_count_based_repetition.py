"""Test the new count-based scheduling and conversion from v6.3 progress."""
import sys
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as rf


def example_words(n=70):
    return [{'ru': f'слово{i}', 'nl': f'woord{i}'} for i in range(n)]


class TestCountBasedScheduler(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.patch = patch.object(rf, 'STATE_FILE', Path(self.temp.name) / 'progress.json')
        self.patch.start()

    def tearDown(self):
        self.patch.stop()
        self.temp.cleanup()

    def test_good_steps_are_other_cards_not_elapsed_time(self):
        words = example_words()
        s = rf.Scheduler(words)
        a = words[0]
        s.note_shown(a, now=100)
        s.record_result(a, 'good', now=101)
        entry = s.state['words'][rf.word_key(a)]
        self.assertEqual(entry['next_due_other_count'], 10)
        for w in words[1:11]:
            s.note_shown(w)
        self.assertEqual(s.state['shown_total'], 11)
        self.assertEqual(s.state['shown_total'] - entry['shown_count'], 10)
        self.assertEqual(entry['next_due_other_count'], 10)
        s.note_shown(a, now=110)
        s.record_result(a, 'good', now=111)
        self.assertEqual(entry['good_streak'], 1)  # unchanged copy
        entry = s.state['words'][rf.word_key(a)]
        self.assertEqual(entry['next_due_other_count'], 35)  # 10 already elapsed + 25 more
        self.assertEqual(entry['good_streak'], 2)
        for w in words[11:36]:
            s.note_shown(w)
        s.note_shown(a)
        s.record_result(a, 'good')
        self.assertEqual(s.state['words'][rf.word_key(a)]['next_due_other_count'], 95)
        self.assertEqual(s.state['words'][rf.word_key(a)]['good_streak'], 3)

    def test_wrong_after_three_other_cards_even_if_hours_pass(self):
        words = example_words(20)
        s = rf.Scheduler(words)
        a = words[0]
        s.note_shown(a, now=100)
        s.record_result(a, 'wrong', now=101)
        for w in words[1:4]:
            s.note_shown(w, now=101)
        self.assertEqual(s.state['words'][rf.word_key(a)]['next_due_other_count'], 3)
        # A due Wrong card outranks a fresh word slot.
        self.assertEqual(rf.word_key(s.choose({'new_word_every': 5}, now=9999999)), rf.word_key(a))
        s.note_shown(a)
        s.record_result(a, 'good')
        self.assertEqual(s.state['words'][rf.word_key(a)]['good_streak'], 1)
        self.assertEqual(s.state['words'][rf.word_key(a)]['next_due_other_count'], 13)

    def test_early_extra_view_does_not_count_as_another_word(self):
        words = example_words(20)
        s = rf.Scheduler(words)
        a = words[0]
        s.note_shown(a)
        s.record_result(a, 'good')
        # Extra training on the same word does not count towards its own ten other words.
        s.note_shown(a)
        s.record_result(a, 'exposed')
        entry = s.state['words'][rf.word_key(a)]
        self.assertEqual(entry['next_due_other_count'], 10)
        self.assertEqual(entry['last_result'], 'good')
        for w in words[1:10]:
            s.note_shown(w)
        self.assertEqual(s.state['shown_total'] - entry['shown_count'], 9)
        self.assertLess(s.state['shown_total'] - entry['shown_count'], entry['next_due_other_count'])
        s.note_shown(words[10])
        self.assertEqual(s.state['shown_total'] - entry['shown_count'], 10)

    def test_dismiss_and_next_are_counted_without_rating(self):
        words = example_words(10)
        s = rf.Scheduler(words)
        a, b, c, d = words[:4]
        s.note_shown(a)
        s.record_result(a, 'wrong')
        for w in (b, c, d):
            s.note_shown(w)
            s.record_result(w, 'dismissed')
        self.assertEqual(s.state['shown_total'], 4)
        self.assertEqual(s.state['words'][rf.word_key(a)]['next_due_other_count'], 3)
        self.assertEqual(rf.word_key(s.choose({'new_word_every':5})), rf.word_key(a))

    def test_old_progress_migrates_only_once(self):
        words = example_words(4)
        key = rf.word_key(words[0])
        rf.save_json(rf.STATE_FILE, {'shown_total': 137, 'cards_since_new': 3,
                                    'words': {key: {'count': 8, 'shown_count': 4,
                                                    'good_streak': 3, 'successes': 3,
                                                    'next_due': 666666666, 'last_result': 'good'}}})
        s = rf.Scheduler(words)
        entry = s.state['words'][key]
        self.assertEqual(s.state['scheduler_version'], 2)
        self.assertEqual(entry['next_due_other_count'], 133)
        self.assertEqual(entry['good_streak'], 3)
        self.assertEqual(entry['next_due'], 666666666)  # original backed up for rollback
        s.note_shown(words[1])
        s2 = rf.Scheduler(words)
        self.assertEqual(s2.state['words'][key]['next_due_other_count'], 133)
        self.assertEqual(s2.state['words'][key]['successes'], 3)

    def test_new_ratio_kept_one_in_five(self):
        words = example_words(30)
        s = rf.Scheduler(words)
        # Four older exposed cards available, all others new.
        for w in words[:4]:
            s.state['words'][rf.word_key(w)] = {'shown_count': 0, 'next_due_other_count': 0, 'last_result': 'exposed'}
        new_positions = []
        for i in range(20):
            w = s.choose({'new_word_every': 5}, manual=True)
            if rf.word_key(w) not in s.state['words']:
                new_positions.append(i)
            s.note_shown(w)
            s.record_result(w, 'exposed')
        self.assertEqual(new_positions, [0,5,10,15])

if __name__ == '__main__':
    unittest.main()
