"""v6.55: compact flyouts are independent native GTK popup windows."""
import unittest
from test_flyout_v652 import TestFlyout


class TestCompactFlyout(unittest.TestCase):
    def setUp(self):
        self.fixture=TestFlyout(methodName='test_left_of_main_at_own_item_height')
        self.fixture.setUp()
        self.menu=self.fixture.menu

    def tearDown(self):
        self.fixture.tearDown()

    def test_flyout_is_its_own_compact_window(self):
        menu=self.menu
        self.assertIs(menu.flyout_window.child, menu.flyout_frame)
        self.assertIsNot(menu.flyout_window, menu.window)
        self.assertEqual(menu.stack.get_vhomogeneous() if hasattr(menu.stack,'get_vhomogeneous') else False,False)
        menu.toggle(1850,25,menu.Gtk.PositionType.TOP)
        menu.navigate('directions')
        self.assertTrue(menu.flyout_window.get_visible())
        menu.navigate('home')
        self.assertFalse(menu.flyout_window.get_visible())

    def test_theme_list_is_scrollable(self):
        menu=self.menu
        self.assertIsNotNone(menu.theme_scroll)
        menu.toggle(1850,25,menu.Gtk.PositionType.TOP)
        menu.navigate('themes')
        self.assertTrue(menu.flyout_window.get_visible())

if __name__=='__main__':unittest.main()
