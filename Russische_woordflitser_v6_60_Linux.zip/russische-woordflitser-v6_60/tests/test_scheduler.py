"""Pure logic smoke checks, no audio or GUI required."""
import sys
from pathlib import Path
from datetime import datetime
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parents[1]))
import russische_woordflitser as rp


class TestBasics(unittest.TestCase):
    def test_words_and_images(self):
        words = rp.all_words()
        self.assertEqual(len(words), 1125)
        self.assertEqual(len({rp.word_key(w) for w in words}), 1125)
        self.assertEqual(sum(bool(w.get('image')) for w in words), 802)
        for w in words:
            if w.get('image'):
                self.assertTrue((rp.BASE / w['image']).is_file())

    def test_quiet_crosses_midnight(self):
        s = {'quiet_hours_from': '22:30', 'quiet_hours_until': '08:00'}
        self.assertTrue(rp.is_quiet_now(datetime(2026, 10, 10, 23, 10), s))
        self.assertTrue(rp.is_quiet_now(datetime(2026, 10, 11, 7, 40), s))
        self.assertFalse(rp.is_quiet_now(datetime(2026, 10, 11, 9, 40), s))

    def test_every_five_shown_cards_one_new_word(self):
        words = rp.all_words()[:20]
        with tempfile.TemporaryDirectory() as temp:
            with patch.object(rp, 'STATE_FILE', Path(temp) / 'progress.json'):
                settings = {'new_word_every': 5}
                s = rp.Scheduler(words)
                # Existing words from the old version count as known.
                for w in words[:4]:
                    s.state['words'][rp.word_key(w)] = {'next_due': 0, 'count': 3, 'last_result': 'exposed'}
                seen_new = []
                for index in range(15):
                    when = 10000 + index * 10
                    w = s.choose(settings, now=when)
                    was_new = rp.word_key(w) not in s.state['words']
                    if was_new:
                        seen_new.append(index)
                    s.note_shown(w, now=when)
                    s.record_result(w, 'exposed', now=when)
                self.assertEqual(seen_new, [0, 5, 10])
                self.assertEqual(s.state['shown_total'], 15)
                self.assertEqual(s.state['new_total'], 3)
                reloaded = rp.Scheduler(words)
                self.assertEqual(reloaded.state['cards_since_new'], 4)
                # The next new word is not one of the already introduced
                # words, regardless of their position in the random source.
                next_word = reloaded.choose(settings, now=20000)
                self.assertNotIn(rp.word_key(next_word), reloaded.state['words'])

    def test_new_ratio_counts_dismissed_cards(self):
        words = rp.all_words()[:12]
        with tempfile.TemporaryDirectory() as temp:
            with patch.object(rp, 'STATE_FILE', Path(temp) / 'progress.json'):
                s = rp.Scheduler(words)
                for w in words[:4]:
                    s.state['words'][rp.word_key(w)] = {'next_due': 0, 'count': 3}
                for i in range(5):
                    w = s.choose({'new_word_every': 5}, now=10000+i)
                    s.note_shown(w, now=10000+i)
                    s.record_result(w, 'dismissed', now=10000+i)
                self.assertEqual(s.state['shown_total'], 5)
                self.assertEqual(s.state['new_total'], 1)
                self.assertEqual(s.state['cards_since_new'], 4)

    def test_manual_next_avoids_immediate_same_card(self):
        words = rp.all_words()[:6]
        with tempfile.TemporaryDirectory() as temp:
            with patch.object(rp, 'STATE_FILE', Path(temp) / 'progress.json'):
                s = rp.Scheduler(words)
                one = s.choose({'new_word_every':5}, now=10000)
                s.note_shown(one, now=10000)
                two = s.choose({'new_word_every':5}, now=10001, exclude=rp.word_key(one), manual=True)
                self.assertNotEqual(rp.word_key(one), rp.word_key(two))
                s.note_shown(two, now=10001)
                three = s.choose({'new_word_every':5}, now=10002, exclude=rp.word_key(two), manual=True)
                self.assertEqual(rp.word_key(three), rp.word_key(one))

    def test_stress_removed_for_audio_only(self):
        self.assertEqual(rp.plain_russian('ко́шка'), 'кошка')
        self.assertEqual(rp.word_key({'ru':'ко́шка'}), rp.word_key({'ru':'кошка'}))

    def test_import_csv(self):
        with tempfile.TemporaryDirectory() as temp:
            sample = Path(temp) / 'import.csv'
            sample.write_text('russian,dutch,emoji\nприве́т,hallo,👋\n', encoding='utf-8')
            with patch.object(rp, 'EXTRA_FILE', Path(temp)/'imported.json'):
                n, total = rp.import_csv(sample)
                self.assertEqual(n, 1)
                self.assertEqual(total, 1)
                self.assertEqual(rp.load_json(rp.EXTRA_FILE, [])[0]['nl'], 'hallo')

if __name__ == '__main__':
    unittest.main()
