"""v6.10: two-second countdown choices, reveal=min(5, total/3), ratio commands."""
import json
from pathlib import Path
import sys
import tempfile
import time
import tkinter as tk
import unittest
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as rf
import tray_icon

WORDS = [{'ru': f'слово{i}', 'nl': f'woord{i}'} for i in range(100)]

class PureCountdownTests(unittest.TestCase):
    def test_options_and_exact_reveal(self):
        self.assertEqual(rf.COUNTDOWN_CHOICES, (5, 7, 9, 11, 13, 15))
        expected = {5:5/3, 7:7/3, 9:3.0,
                    11:11/3, 13:13/3, 15:5.0}
        for seconds, reveal in expected.items():
            with self.subTest(seconds=seconds):
                self.assertAlmostEqual(rf.reveal_delay_seconds(seconds), reveal)
                self.assertLess(rf.reveal_delay_seconds(seconds), seconds)
        self.assertEqual(rf.normalized_countdown(20), 15)
        self.assertEqual(rf.normalized_countdown(3), 5)
        self.assertEqual(rf.normalized_countdown(12), 11)
        self.assertEqual(rf.normalized_countdown('invalid'), 9)

class LiveSettingsTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.base = Path(self.temp.name)
        (self.base/'settings.json').write_text(json.dumps({
            'hide_after_seconds': 9, 'new_word_every': 5,
            'popup_opacity': 0.85, 'custom_option': 'bewaren',
            'reveal_after_seconds': 99}))
        self.patches = [
            patch.object(rf, 'BASE', self.base),
            patch.object(rf, 'STATE_FILE', self.base/'progress.json'),
            patch.object(rf, 'all_words', return_value=WORDS),
            patch.object(tray_icon, 'SETTINGS_FILE', self.base/'settings.json'),
        ]
        for item in self.patches:
            item.start()
        self.root = tk.Tk()
        self.root.withdraw()
        self.app = rf.Application(self.root, {**rf.load_settings(),
                                             'play_audio_automatically': False})
        self.audio_mock = patch.object(self.app.popup, 'ensure_audio')
        self.audio_mock.start()
        self.app.try_popup(manual=True)
        self.root.update()

    def tearDown(self):
        self.audio_mock.stop()
        self.app.shutdown()
        self.root.destroy()
        for item in reversed(self.patches):
            item.stop()
        self.temp.cleanup()

    def test_ratio_change_live_saved_and_score_unchanged(self):
        self.assertEqual(tray_icon.selected_new_word_every(), 5)
        word = self.app.popup.active_word
        self.app.popup.reveal()
        self.app.popup.mark_good()
        state_before = rf.load_json(rf.STATE_FILE, {})
        for every in rf.NEW_WORD_EVERY_CHOICES:
            self.app.handle_command(f'newratio:{every}')
            self.assertEqual(self.app.settings['new_word_every'], every)
            self.assertEqual(tray_icon.selected_new_word_every(), every)
            self.assertEqual(rf.load_json(rf.STATE_FILE, {}), state_before)
        self.app.handle_command('newratio:3')
        self.assertEqual(rf.load_settings()['new_word_every'], 3)
        self.assertEqual(rf.load_json(self.base/'settings.json', {})['custom_option'], 'bewaren')
        self.assertEqual(rf.vocabulary_score(rf.load_json(rf.STATE_FILE, {})), 1)
        for bad in ('newratio:1', 'newratio:17', 'newratio:', 'newratio:abc'):
            with self.assertRaises(ValueError):
                self.app.handle_command(bad)

    def test_manual_reveal_is_immediate_even_if_countdown_changes(self):
        popup = self.app.popup
        popup.mark_known()
        self.assertTrue(popup.revealed)
        self.assertIsNone(popup.rated_result)
        self.assertIsNone(popup.hide_deadline)
        self.assertIsNone(popup.reveal_timer_id)
        self.app.handle_command('countdown:5')
        self.assertEqual(tray_icon.selected_countdown(), 5)
        self.assertIsNone(popup.hide_deadline)
        self.assertEqual(popup.canvas.itemcget('translation','text'), popup.active_word['nl'])
        self.assertEqual(popup.canvas.itemcget('good','state'), 'normal')
        self.assertEqual(popup.canvas.itemcget('wrong','state'), 'normal')

    def test_unrated_change_updates_both_timers_and_reveals(self):
        popup = self.app.popup
        self.app.handle_command('countdown:5')
        self.assertAlmostEqual(popup.hide_deadline-time.monotonic(), 5.0, delta=0.20)
        time.sleep(1.75)
        self.root.update()
        self.assertTrue(popup.revealed)
        self.assertIsNotNone(popup.active_word)
        self.assertEqual(tray_icon.selected_countdown(), 5)

    def test_settings_migration_and_old_reveal_option_ignored(self):
        self.assertAlmostEqual(rf.reveal_delay_seconds(self.app.settings['hide_after_seconds']), 3.0)
        stored=rf.load_json(self.base/'settings.json',{})
        stored['hide_after_seconds']=30
        rf.save_json(self.base/'settings.json',stored)
        self.assertEqual(rf.load_settings()['hide_after_seconds'],15)
        self.assertEqual(tray_icon.selected_countdown(),15)

class RatioSchedulerTests(unittest.TestCase):
    def test_fixed_ratio_for_all_choices_with_available_old_words(self):
        for every in rf.NEW_WORD_EVERY_CHOICES:
            with self.subTest(every=every), tempfile.TemporaryDirectory() as tmp:
                with patch.object(rf, 'STATE_FILE', Path(tmp)/'progress.json'):
                    s = rf.Scheduler(WORDS)
                    # Voldoende bekende, onbeoordeelde woorden om de ratio in
                    # te houden, zelfs als er geen 'due' woorden zijn.
                    for w in WORDS[:6]:
                        s.state['words'][rf.word_key(w)] = {
                            'shown_count': 1, 'last_result': 'good',
                            'next_due_other_count': 1000}
                    s.state['shown_total'] = 6
                    s.state['cards_since_new'] = 999
                    fresh_indexes=[]
                    for index in range(every*3):
                        word = s.choose({'new_word_every': every})
                        if rf.word_key(word) not in s.state['words']:
                            fresh_indexes.append(index)
                        s.note_shown(word)
                    self.assertEqual(fresh_indexes, [0,every,every*2])

if __name__ == '__main__':
    unittest.main()
