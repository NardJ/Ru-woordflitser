"""v6.57: dismiss the *whole* menu on pointer exit, without breaking flyouts."""
import unittest
from types import SimpleNamespace
from test_xapp_menu_v651 import TestMenu


class TestMenuAutoHide(unittest.TestCase):
    def setUp(self):
        self.fixture = TestMenu(methodName='test_single_icon_and_all_pages')
        self.fixture.setUp()
        self.menu = self.fixture.menu
        self.menu.toggle(900, 20, self.menu.Gtk.PositionType.TOP)
        self.menu.opening = False

    def tearDown(self):
        self.fixture.tearDown()

    def run_close(self):
        source = self.menu.flyout_close_source
        self.assertIsNotNone(source)
        self.fixture.sources.pop(source)()

    def test_no_submenu_pointer_leaves_closes_root(self):
        self.assertEqual(self.menu.active_page, 'home')
        self.menu._pointer_position = lambda: (10, 900)
        self.menu.on_menu_leave()
        self.assertTrue(self.menu.window.get_visible())  # not immediate
        self.run_close()
        self.assertFalse(self.menu.window.get_visible())
        self.assertFalse(self.menu.flyout_visible)
        self.assertEqual(self.menu.active_page, 'home')

    def test_pointer_returns_to_main_keeps_main_open(self):
        self.menu._pointer_position = lambda: (10, 900)
        self.menu.on_menu_leave()
        x, y = self.menu.window.get_position()
        self.menu._pointer_position = lambda: (x + 10, y + 10)
        self.run_close()
        self.assertTrue(self.menu.window.get_visible())

    def test_pointer_leaves_both_when_flyout_open_closes_both(self):
        self.menu.navigate('speech')
        self.menu._pointer_position = lambda: (10, 900)
        self.menu.on_menu_leave()
        self.run_close()
        self.assertFalse(self.menu.window.get_visible())
        self.assertFalse(self.menu.flyout_window.get_visible())

    def test_pointer_enters_flyout_keeps_both_open(self):
        self.menu.navigate('themes')
        self.menu._pointer_position = lambda: (10, 900)
        self.menu.on_menu_leave()
        self.menu.on_flyout_enter()
        self.assertIsNone(self.menu.flyout_close_source)
        self.assertTrue(self.menu.window.get_visible())
        self.assertTrue(self.menu.flyout_visible)
        # Even if a GTK leave event fires, read actual pointer location.
        x, y = self.menu.flyout_window.get_position()
        self.menu._pointer_position = lambda: (x + 10, y + 10)
        self.menu.on_menu_leave()
        self.run_close()
        self.assertTrue(self.menu.flyout_visible)
        self.assertTrue(self.menu.window.get_visible())

    def test_hover_main_non_anchor_closes_flyout_only(self):
        self.menu.navigate('themes')
        x, y = self.menu.window.get_position()
        self.menu._pointer_position = lambda: (x + 10, y + 10)
        self.menu.on_menu_leave()
        self.run_close()
        self.assertEqual(self.menu.active_page, 'home')
        self.assertTrue(self.menu.window.get_visible())
        self.assertFalse(self.menu.flyout_visible)

    def test_volume_drag_outside_does_not_hide_until_release(self):
        self.menu.scale.emit('button-press-event', SimpleNamespace())
        self.menu.scale.set_value(172)
        self.menu._pointer_position = lambda: (10, 900)
        self.menu.on_menu_leave()
        self.run_close()
        self.assertTrue(self.menu.window.get_visible())
        self.menu.scale.emit('button-release-event', SimpleNamespace())
        self.run_close()
        self.assertFalse(self.menu.window.get_visible())
        self.assertIn('volume:172', self.fixture.commands)

    def test_unavailable_pointer_does_not_close(self):
        self.menu._pointer_position = lambda: None
        self.menu.on_menu_leave()
        self.run_close()
        self.assertTrue(self.menu.window.get_visible())

    def test_main_menu_stays_fixed_while_switching_flyouts(self):
        origin = self.menu.window.get_position()
        self.menu.navigate('themes')
        self.menu.navigate('speech')
        self.assertEqual(origin, self.menu.window.get_position())
        self.assertTrue(self.menu.flyout_visible)


if __name__ == '__main__':
    unittest.main()
