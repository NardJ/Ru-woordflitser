"""v6.48 extra speech gain: v6.47 default compatibility + boosted output."""
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as rf
import tray_icon


class BoostTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name)
        self.audio = self.base / 'test.mp3'
        self.log = self.base / 'audio-errors.log'

    def test_normalized_settings_allow_200_but_reject_overflow(self):
        self.assertEqual(rf.normalized_audio_volume(100), 100)
        self.assertEqual(rf.normalized_audio_volume(150), 150)
        self.assertEqual(rf.normalized_audio_volume(200), 200)
        self.assertEqual(rf.normalized_audio_volume(201), 75)
        conf = self.base / 'settings.json'
        conf.write_text('{"audio_volume":200}', encoding='utf-8')
        with patch.object(rf, 'BASE', self.base), patch.object(tray_icon, 'SETTINGS_FILE', conf):
            self.assertEqual(rf.load_settings()['audio_volume'], 200)
            self.assertEqual(tray_icon.selected_volume(), 200)

    def test_ffplay_filter_is_only_used_above_100(self):
        for volume in (0, 25, 75, 100, 101, 150, 200):
            with self.subTest(volume=volume), \
                 patch.object(rf, 'audio_path_for_playback', return_value=self.audio), \
                 patch.object(rf, 'AUDIO_ERROR_LOG', self.log), \
                 patch.object(rf.shutil, 'which', side_effect=lambda name: '/usr/bin/ffplay' if name == 'ffplay' else None), \
                 patch.object(rf.subprocess, 'Popen') as popen:
                rf.play_audio(self.audio, volume)
                argv = popen.call_args.args[0]
                self.assertEqual(argv[argv.index('-volume')+1], str(min(volume,100)))
                if volume <= 100:
                    self.assertNotIn('-af', argv)
                else:
                    self.assertIn('-af', argv)
                    self.assertEqual(argv[argv.index('-af')+1],
                        f'volume={volume/100:.2f},alimiter=limit=0.95:level=false')

    def test_real_ffplay_boost_does_not_fail_or_silence(self):
        if not shutil.which('ffmpeg') or not shutil.which('ffplay'):
            self.skipTest('ffmpeg and ffplay required')
        subprocess.run(['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y',
            '-f', 'lavfi', '-i', 'sine=frequency=480:duration=0.8',
            '-af', 'volume=0.15', '-codec:a', 'libmp3lame', str(self.audio)],
            check=True, timeout=15)
        def mean_db(filters):
            cmd=['ffmpeg','-hide_banner','-nostats','-i',str(self.audio)]
            if filters: cmd+=['-af',filters+',volumedetect']
            else: cmd+=['-af','volumedetect']
            cmd+=['-f','null','-']
            result=subprocess.run(cmd, capture_output=True, text=True, timeout=15)
            self.assertEqual(result.returncode, 0, result.stderr)
            return float(re.search(r'mean_volume:\s*(-?[\d.]+) dB', result.stderr).group(1))
        original=mean_db(None)
        boosted=mean_db('volume=2.00,alimiter=limit=0.95:level=false')
        self.assertGreater(boosted, original+5.5)
        with patch.object(rf, 'AUDIO_ERROR_LOG', self.log), \
             patch.object(rf, 'audio_path_for_playback', return_value=self.audio), \
             patch.dict(os.environ, {'SDL_AUDIODRIVER':'dummy'}):
            proc=rf.play_audio(self.audio, volume=200)
            self.assertIsNotNone(proc)
            self.assertEqual(proc.wait(timeout=10), 0, self.log.read_text() if self.log.exists() else '')

if __name__ == '__main__':
    unittest.main()
