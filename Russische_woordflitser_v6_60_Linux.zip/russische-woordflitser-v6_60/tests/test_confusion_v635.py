"""Regressies: verwarringsoefeningen gebruiken dezelfde kaart, eigen IDs, eigen planning."""
import json
from pathlib import Path
import sys
import tempfile
import tkinter as tk
from unittest import TestCase, main
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as wf
import tray_icon
BASE = Path(__file__).resolve().parents[1]

class ConfusionTests(TestCase):
    @classmethod
    def setUpClass(cls):
        cls.words = json.loads((BASE / 'words.json').read_text(encoding='utf-8'))
        cls.quiz = [w for w in cls.words if w.get('theme') == 'verwarring']

    def test_24_unique_questions_and_theme_menu(self):
        self.assertEqual(len(self.quiz), 24)
        self.assertEqual(len({wf.word_key(w) for w in self.words}), 1090)
        self.assertIn(('verwarring','Verwarringswoorden (NL → RU)'), wf.THEME_CHOICES)
        self.assertEqual(wf.THEME_CHOICES, tray_icon.THEME_CHOICES)
        self.assertTrue(all(wf.plain_russian(w['ru']) in [wf.plain_russian(o) for o in w['choices']] for w in self.quiz))
        self.assertEqual(len(wf.eligible_words(self.words, {'direction':'nl-ru','selected_themes':['verwarring']})),24)
        self.assertEqual(len(wf.eligible_words(self.words, {'direction':'ru-nl','selected_themes':['verwarring']})),0)
        self.assertEqual(len(wf.eligible_words(self.words, {'direction':'ru-nl','selected_themes':None})),1066)

    def test_prompt_non_quiz_unchanged(self):
        regular = next(w for w in self.words if wf.word_key(w) == 'тот')
        self.assertEqual(wf.confusion_prompt(regular, 'nl-ru'), regular['nl'])
        self.assertEqual(wf.confusion_prompt(regular, 'ru-nl'), wf.displayed_russian(regular))
        self.assertIn('тако́й / тот / так', wf.confusion_prompt(next(w for w in self.quiz if w['exercise_id']=='tot-huis'), 'nl-ru'))

    def test_scheduler_keeps_separate_progress_and_score(self):
        with tempfile.TemporaryDirectory() as td, patch.object(wf,'STATE_FILE',Path(td)/'progress.json'):
            sched=wf.Scheduler(self.words, direction='nl-ru')
            quiz=next(w for w in self.quiz if w['exercise_id']=='tot-huis')
            regular=next(w for w in self.words if wf.word_key(w)=='тот')
            sched.note_shown(quiz)
            sched.record_result(quiz,'good')
            self.assertEqual(sched.vocabulary_score(),0)  # Quiz geen nieuw woord
            self.assertEqual(sched.state['words'][wf.word_key(quiz)]['last_result'],'good')
            sched.note_shown(regular)
            sched.record_result(regular,'good')
            self.assertEqual(sched.vocabulary_score(),1)
            self.assertEqual(len(sched.state['words']),2)
            sched.set_direction('ru-nl')
            self.assertEqual(sched.vocabulary_score(),0)

    def test_popup_same_geometry_and_no_leak_before_reveal(self):
        word=next(w for w in self.quiz if w['exercise_id']=='tot-huis')
        root=tk.Tk();root.withdraw()
        popup=wf.Popup(root,{**wf.DEFAULT_SETTINGS,'direction':'nl-ru','play_audio_automatically':False})
        try:
            with patch.object(popup,'ensure_audio'):
                popup.show(word)
                root.update_idletasks()
                self.assertEqual((popup.WIDTH,popup.HEIGHT),(580,290))
                shown=popup.canvas.itemcget('russian','text')
                self.assertIn(word['nl'],shown)
                for option in word['choices']: self.assertIn(option,shown)
                self.assertEqual(popup.canvas.itemcget('context-ru','text'),word['context_nl'])
                self.assertEqual(popup.canvas.itemcget('translation','text'),'')
                self.assertEqual(popup.canvas.itemcget('context-nl','text'),'')
                self.assertEqual(popup.canvas.itemcget('translation','state'),'hidden')
                popup.mark_known()
                self.assertEqual(popup.canvas.itemcget('translation','text'),word['ru'])
                self.assertEqual(popup.canvas.itemcget('context-nl','text'),word['context_ru'])
                self.assertEqual(popup.canvas.itemcget('context-nl','state'),'normal')
        finally:
            popup.shutdown();root.destroy()

if __name__=='__main__': main()
