"""v6.6: tray/IPC actions should not change the learning architecture."""
from pathlib import Path
import sys
import tempfile
import threading
import time
import tkinter as tk
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import russische_woordflitser as rf

WORDS = [{'ru': f'слово{i}', 'nl': f'woord{i}'} for i in range(12)]


class TrayControls(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        base = Path(self.temp.name)
        self.patches = [patch.object(rf, 'STATE_FILE', base / 'progress.json'),
                        patch.object(rf, 'PAUSE_FILE', base / 'pause.txt'),
                        patch.object(rf, 'CONTROL_SOCKET', base / 'control.sock'),
                        patch.object(rf, 'all_words', return_value=WORDS)]
        for p in self.patches:
            p.start()
        self.root = tk.Tk()
        self.root.withdraw()
        self.app = rf.Application(self.root, {**rf.DEFAULT_SETTINGS,
                                               'play_audio_automatically': False})
        # Tests mustn't launch a real audio synthesis worker.
        self.audio = patch.object(self.app.popup, 'ensure_audio')
        self.audio.start()

    def tearDown(self):
        self.audio.stop()
        self.app.shutdown()
        self.root.destroy()
        for p in reversed(self.patches):
            p.stop()
        self.temp.cleanup()

    def test_show_command_overrides_pause_and_does_not_create_second_popup(self):
        self.app.handle_command('pause')
        self.assertTrue(rf.is_paused())
        self.app.handle_command('show')
        self.assertIsNotNone(self.app.popup.active_word)
        shown = self.app.sched.state['shown_total']
        self.app.handle_command('show')
        self.assertEqual(self.app.sched.state['shown_total'], shown)

    def test_good_rating_saved_and_next_keeps_same_app(self):
        self.app.handle_command('show')
        first = self.app.popup.active_word
        self.app.popup.reveal()
        self.app.popup.mark_good()
        self.assertEqual(rf.load_json(rf.STATE_FILE, {})['words'][rf.word_key(first)]['successes'], 1)
        self.app.popup.next_card()
        self.root.update()
        self.assertNotEqual(rf.word_key(first), rf.word_key(self.app.popup.active_word))

    def test_session_and_dismiss_end(self):
        self.app.handle_command('session')
        self.assertTrue(self.app.session_active)
        self.app.popup.hide('exposed')
        self.assertTrue(self.app.session_active)
        self.assertLessEqual(self.app.next_due_at - time.monotonic(), 1.6)
        self.app.handle_command('end-session')
        self.assertFalse(self.app.session_active)
        self.app.handle_command('session')
        self.app.popup.hide('dismissed')
        self.assertFalse(self.app.session_active)

    def test_stats_and_pause_resume(self):
        self.app.handle_command('stats')
        self.assertTrue(self.app.stats_window.winfo_exists())
        self.app.handle_command('pause')
        self.assertTrue(rf.is_paused())
        self.app.handle_command('resume')
        self.assertFalse(rf.is_paused())

    def test_socket_connects_to_one_owner(self):
        with patch.object(rf.subprocess, 'Popen') as create_tray:
            self.app.start_controls()
        self.assertTrue(rf.CONTROL_SOCKET.is_socket())
        done = []
        t = threading.Thread(target=lambda: done.append(rf.send_control('show')), daemon=True)
        t.start()
        for _ in range(20):
            self.root.update()
            if done:
                break
            time.sleep(.02)
        t.join(timeout=1)
        self.assertEqual(done, [True])
        self.assertEqual(self.app.sched.state['shown_total'], 1)
        self.assertEqual(create_tray.call_count, 1)


if __name__ == '__main__':
    unittest.main()
