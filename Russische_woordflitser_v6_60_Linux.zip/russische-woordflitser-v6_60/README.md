# Russische Woordflitser v6.60 (Linux)

Dit pakket bevat 1.066 gewone woordkaarten, 24 verwarringsoefeningen, 35 naamvaloefeningen, 802 gekoppelde afbeeldingen, aparte leerstanden per oefenrichting en de verbeterde automatische uitspraak.

## Nieuw in v6.60 — Letterlijke voorbeelden voor de volledige standaardwoordenlijst

- Alle 1.090 standaardkaarten (1.066 woorden en 24 verwarringsoefeningen) hebben nu een `context_nl_literal`. De 35 aparte naamvaloefeningen houden hun eigen gespecialiseerde uitleg.
- De leervertaling behoudt de Russische woordvolgorde zoveel mogelijk: **Э́то са́мый большо́й дом. → Dit [is] [het] meest grote huis.**
- Extra Nederlandse woorden (onder meer lidwoorden en de ontbrekende tegenwoordige tijd van 'zijn') staan tussen vierkante haken. Dit is een **didactische vertaling**: grammaticale systemen verschillen en niet elk Russisch woord kan exact één Nederlands woord hebben.
- **У меня́ есть брат. → Bij mij is er [een] broer.** Zo blijft de Russische bezitsconstructie herkenbaar. **Я ничего́ не ви́жу. → Ik niets niet zie.** Zo blijft de Russische dubbele ontkenning zichtbaar.
- Alle bestaande natuurlijke vertalingen (`context_nl`) blijven aanwezig voor NL→RU. De kopieerknop, instelling, uitspraak en voortgang blijven werken als in v6.59.
- Bij updaten naar v6.60 worden ook de 48 oude standaardleervertalingen ververst. Heb je zelf een andere Russische voorbeeldzin ingevoerd, dan krijgt die niet zomaar de leervertaling van de oorspronkelijke zin. Eigen aanpassingen in `woordcorrecties.json` blijven behouden.

## Nieuw in v6.59 — Letterlijke vertalingen en zinnen kopiëren

- Bij RU→NL gebruikt het voorbeeldvak eerst `context_nl_literal` als dit is ingevuld, anders de bestaande Nederlandse vertaling. De oude `context_nl` blijft de natuurlijke formulering voor NL→RU.
- Voor de voorbeeldzin **Весь день идёт дождь.** verschijnt nu **Hele dag komt regen.** in plaats van de natuurlijke vertaling. Dit is een didactische woordvolgordevertaling; *идёт* betekent letterlijk eerder 'gaat' en bij regen 'valt/regent'.
- Klik naast **🔊 zin** op **⧉ Kopieer** om de Russische voorbeeldzin op het klembord te zetten, zonder de uitspraak af te spelen of de kaart te verplaatsen. Er verschijnt een korte bevestiging.
- In NL→RU wordt **Kopieer** pas beschikbaar na het tonen van het antwoord, zodat het de oefening niet verraadt. Bij naamvaloefeningen kopieert het de oorspronkelijke zin zonder «…»-markeringen.
- Via het potlood kun je ook bij andere kaarten zelf een letterlijke vertaling invullen. Eigen correcties en leerhistorie blijven bij updates bewaard.
- Vanaf v6.60 zijn ook alle overige standaardvoorbeelden van een afzonderlijke leervertaling voorzien.

## Nieuw in v6.58 — Naamvallen herkennen in Russische zinnen

- Nieuw afzonderlijk thema **Naamvallen herkennen (RU-zinnen)** onder Thema's oefenen.
- 35 korte Russische zinnen; telkens één gemarkeerd zelfstandig naamwoord waarvan je de naamval bepaalt.
- Na het antwoord: **N/G/D/A/I/P**, volledige naam en korte aanwijzing zoals `на + waar?`.
- Klik na het onthullen op **? Uitleg**: volledige zinvertaling, reden voor de naamval, basisvorm naar verbogen vorm, plus vergelijkingen met mannelijk (levend en levenloos), vrouwelijk (-а en -я), onzijdig (-о) en -ия.
- Het uitlegvenster stopt de kaarttimer; je kunt de uitleg op je gemak lezen en daarna Goed/Fout kiezen.
- De bestaande 580 × 290 pixels kaart en automatische/handmatige Russische zinuitspraak blijven behouden.
- In beide oefenrichtingen worden deze kaarten **altijd als Russische zinsherkenning** getoond.
- **Bestaande themakeuzes blijven exact behouden.** Het nieuwe thema staat dus na een update standaard uit en kan expliciet in Thema's oefenen worden aangezet.
- De case-kaarten hebben eigen leer-ID's en tellen niet mee als reeds bekende woordenschat.
- De voorbeelden zijn opgebouwd op basis van de bijgevoegde `naamvallen.md`. Er is gebruikgemaakt van enkele aanvullende, korte zinnen die hetzelfde grammaticale patroon demonstreren.

## Nieuw in v6.57 — Hele menu automatisch sluiten

- Het hoofdmenu sluit nu ook wanneer **geen** submenu geopend is en de muis het hoofdmenu verlaat.
- Als een submenu geopend is, blijven beide menuvensters open tijdens het bewegen tussen hoofdmenu en submenu. Verlaat de muis ze allebei, dan sluiten **beide** na circa 180 ms.
- Staat de muis nog wel op het hoofdmenu maar niet meer op de bijbehorende submenuoptie, dan sluit alleen het submenu; het hoofdmenu blijft op zijn vaste plaats.
- Tijdens het slepen van de volumeschuif sluit het menu niet voortijdig.
- Bestaande volume-, thema-, oefenrichting- en overige instellingen en leerhistorie blijven behouden bij het bijwerken.

## Nieuw in v6.56 — Submenu’s sluiten automatisch

- De regel `‹ Terug` is verwijderd uit alle submenu’s.
- Als de muis het submenu én de bijbehorende hoofdmenuoptie verlaat, klapt alleen het submenu na circa 180 ms automatisch in. Het hoofdmenu blijft staan.
- Beweeg je over een ander hoofdmenu-item, dan sluit het submenu direct; is dat item zelf een submenu, dan opent dat meteen in dezelfde positie.
- De korte vertraging voorkomt dat het submenu al sluit tijdens het bewegen tussen de twee gescheiden GTK-vensters.
- Onder **Tijd & herhalingen** zijn Afteltijd en Nieuwe woorden voortaan direct uitklapbaar, zonder een extra navigatiepagina of terugknop.
- De update bewaart alle bestaande instellingen en leerhistorie, net als de vorige versie.


## Nieuw in v6.55 — Geankerde submenu’s

- Het hoofdmenu wordt **niet verplaatst of vergroot** wanneer een submenu opent.
- Een submenu gebruikt een **apart compact GTK-popupvenster** zonder eigen systeemvakicoon; de XApp-status blijft identiek.
- De bovenrand is uitgelijnd met de **werkelijke bovenrand van de betreffende menuoptie** (via GTK `translate_coordinates`, dus onafhankelijk van schaal of lettergrootte).
- Links/rechts kiezen gebeurt op basis van vrije schermruimte; lange themalijsten scrollen bij beperkte hoogte.
- Het bestaande volumeniveau, de richting, gekozen thema's en overige instellingen blijven in de updater behouden.
- De echte positionering en focusafhandeling op Cinnamon moeten op de gebruikersdesktop worden bevestigd.

## Nieuw in v6.54 — Korte submenu's en zichtbaar versienummer

- Het titellabel toont nu **Russische Woordflitser v6.54**.
- De ongebruikte ruimte onder een kort submenu wordt niet langer door de
  ondoorzichtige achtergrond van het gezamenlijke GTK-venster gevuld.
  Daarvoor wordt de RGBA/composited visual gebruikt op Cinnamon; de twee
  daadwerkelijke panelen behouden ieder hun eigen thema-achtergrond.
- De bestaande instellingen en woorden worden niet gewijzigd.
- Bij een systeem zonder RGBA-compositing blijft het oude (veilige) uiterlijk
  beschikbaar. GTK/Cinnamon zelf moet op het apparaat visueel getest worden.

## Nieuw in v6.53 — Compacte hoogte voor uitklapmenu's

- Elk uitklapmenu is alleen nog zo hoog als zijn eigen inhoud.
  Korte menu's zoals **Oefenrichting** en **Spraakinstellingen**
  nemen niet langer de volledige hoogte van het hoofdmenu in.
- De bovenranden blijven netjes gelijk; het hoofdmenu, de slider en
  de positie links/rechts zijn niet gewijzigd.
- Het themaoverzicht behoudt zijn eigen scrolvak en kan dus langer zijn.
  Het submenu blijft binnen hetzelfde GTK-venster om focusverlies te vermijden.

## Nieuw in v6.52 — Submenu's uitklappen naast het hoofdmenu

- Het **hoofdmenu blijft zichtbaar** bij Oefenrichting, Thema’s oefenen,
  Tijd & herhalingen en Spraakinstellingen. Het submenu komt in een **tweede
  kolom binnen hetzelfde GTK-venster**, niet in een los venster. Dit voorkomt
  focusverlies of het sluiten van de volumeschuif.
- Het submenu opent door **klikken of aanwijzen met de muis**. Als er ruimte
  rechts van het hoofdmenu is, verschijnt het rechts; vlakbij de rechter
  schermrand verschijnt het links. Dit is handig bij een RU-systeemvakicoon
  rechts op de Cinnamon-balk.
- Binnen Tijd & herhalingen openen Afteltijd en Nieuwe woorden in dezelfde
  tweede kolom. Met Terug ga je naar Tijd & herhalingen; met Escape sluit je
  eerst het submenu en daarna het hele menu.
- De **0–200%-volumeschuif blijft bereikbaar in het hoofdmenu**, ook wanneer
  een submenu openstaat. Alle thema-instellingen en IPC-opdrachten blijven
  hetzelfde. De fallback op systemen zonder XApp is niet aangepast.
- De updater neemt het hele bestaande `settings.json` over en wijzigt geen
  volume, oefenrichting, themaselectie of leerhistorie.
- De opbouw, IPC-acties en plaatsingslogica zijn geautomatiseerd getest. Het
  daadwerkelijke uiterlijk op Cinnamon is nog niet op de pc van de gebruiker
  gecontroleerd.

## Nieuw in v6.51 — XApp-menu zoals BluePlayer

- Op Linux Mint/Cinnamon gebruikt het systeemvak `XApp.StatusIcon`, dezelfde
  aanpak als BluePlayer v2.7. Er hangt **geen traditioneel Gtk.Menu** aan het
  icoon; een klein venster zonder titelbalk verschijnt eronder.
- De schuif **Uitspraakvolume (0–200%) staat direct in het hoofdmenu**.
  Klikken en slepen werkt in dit echte GTK-venster. Na het slepen wordt de
  gekozen stand via de bestaande IPC aan de woordflitser doorgegeven.
- Alle opties zijn behouden: huidige woord, sessie starten/stoppen,
  automatische popups pauzeren/hervatten, statistieken, oefenrichting,
  alle 15 thema's met Alles aan/uit, intervallen, afteltijd,
  nieuwe woorden/herhalingen, voorbeeldzinnen, normalisatie, herstarten
  en afsluiten. Druk `Esc` of klik buiten het venster om het te sluiten.
- De bestaande AppIndicator-weergave blijft beschikbaar als **terugvaloptie**
  op desktops zonder XApp, met het volume in een apart klein schuifpaneel.
- De updater kopieert nu ook `tray_xapp.py`. Het **gehele bestaande**
  `settings.json` blijft behouden, inclusief onbekende voorkeuren;
  `progress.json`, MP3's en persoonlijke afbeeldingen blijven onaangeroerd.
- Voor XApp op Ubuntu/Mint zijn de distributiepakketten voor XApp GI-introspectie
  nodig, doorgaans `gir1.2-xapp-1.0`. Mint levert deze doorgaans zelf.
- De XApp-bediening is met automatische GTK-signaal-simulaties getest.
  Het echte gedrag van het Cinnamon-paneel kan alleen op de gebruikersdesktop
  volledig worden gecontroleerd.

## Nieuw in v6.50 — Herstel systeemvak en werkende volumeschuif

- Het RU-systeemvakicoon gebruikt weer **AppIndicator als primaire backend**, zodat
  het niet ongewenst naar de rechterkant van de bovenbalk verhuist.
- De onbetrouwbare poging om een GTK-schuifregelaar *in* een traditioneel
  systeemvakmenu te plaatsen is verwijderd. Het menu sluit namelijk zodra de
  gebruiker de schuif probeert te bedienen.
- **Uitspraakvolume…** opent nu een klein, onversierd volumevenster bij de muis.
  Het opent pas ná het sluiten van het systeemvakmenu, waardoor de muis correct
  naar de slider gaat. De schuif blijft van **0–200%**, met 100%-markering.
- Het oude probleem waarbij een popup met twee rechtstreekse children van
  `Gtk.Window` werd opgebouwd, is opgelost. Sluiten bewaart ook de laatste waarde.
- Bij updates wordt **de volledige bestaande settings.json** behouden; alleen
  ontbrekende instellingen krijgen een standaardwaarde. Dat geldt ook voor
  oefenrichting, themaselectie (inclusief leeg), volume, normalisatie en onbekende
  toekomstige voorkeuren. De update maakt eerst een reservekopie.

## v6.49 — Instellingen bewaren (menumethode vervangen in v6.50)

- Op **X11 met een Gtk.StatusIcon-systeemvak** komt de echte schuifregelaar
  voor **0–200%** in het systeemvakmenu. De waarde verandert bij slepen en
  wordt meteen in `settings.json` opgeslagen.
- Op desktops die het menu via **AppIndicator/DBusMenu** weergeven, kan GTK
  technisch geen willekeurige slider in het paneelmenu injecteren. Daar opent
  **Uitspraakvolume…** een klein, onversierd paneeltje bij de muis met precies
  dezelfde schuifregelaar. Dit is nadrukkelijk geen apart groot dialoogvenster.
- Bij updaten blijft **iedere bestaande instelling behouden**: oefenrichting,
  themaselectie (ook wanneer alles uit staat), volume tot 200%, normalisatie,
  intervallen, uitspraak, en eventuele zelf toegevoegde JSON-instellingen.
  De updater controleert de bestaande JSON, maakt een reservekopie, en vult
  uitsluitend ontbrekende standaardinstellingen aan. Bij beschadigde JSON
  wordt de update afgebroken in plaats van stilzwijgend teruggezet.
- De leerhistorie en MP3-cache worden door een update niet gewist.

## Nieuw in v6.48 — Extra spraakversterking tot 200%

- **Systeemvakmenu → Volume aanpassen…** heeft nu een schuif van **0–200%**.
- **100% klinkt precies als in v6.47**. Daarboven wordt de audio digitaal
  versterkt: 150% is ongeveer +3,5 dB en 200% ongeveer +6 dB (vóór begrenzing).
- Bij gebruik van `ffplay` (voorkeur) of `mpv` gebeurt de versterking met
  een audiofilter en een piekbegrenzer om digitale oversturing te verminderen.
  Op `cvlc` blijft de eigen versterkingsinstelling van VLC actief.
- Zowel **woorden als voorbeeldzinnen** gebruiken hetzelfde volume. De oude
  MP3-cache en veilige achtergrondnormalisatie blijven ongewijzigd.
- Meer versterking is niet altijd beter: luide passages worden door de begrenzer
  minder versterkt. Zet je luidsprekers laag voordat je het maximum test.

## Nieuw in v6.47 — Herstel uitgevallen geluid

- De originele MP3 wordt **direct** afgespeeld als er nog geen normalisatiecache is;
  normaliseren gaat op de achtergrond en vertraagt de kaart niet meer.
- Nieuw gemaakte MP3-bestanden worden gecontroleerd op hoorbare audio. De
  eerdere normalisatiecache wordt niet hergebruikt; een nieuwe `normalized-v2`
  wordt gemaakt zodat een mogelijk kapotte oude MP3 niet meer wordt afgespeeld.
- Via het systeemvakmenu kun je **Spraakvolume automatisch normaliseren**
  desgewenst uitvinken; de originele MP3's spelen dan zoals in v6.45.
- Fouten van `ffplay` en FFmpeg staan nu in
  `~/.local/share/russische-woordflitser/audio-errors.log` zodat een volgende
  storing te onderzoeken is. Als FFmpeg niet beschikbaar is, blijft de normale
  audioafspeelroute werken.

## Nieuw in v6.46 — Geluidsnormalisatie van Russische spraak

De woordflitser normaliseert het geluid van **zowel losse woorden als Russische
voorbeeldzinnen** naar een vergelijkbaar spraakvolume (richtwaarde **−16 LUFS**, 
begrenst op **−1,5 dBTP**). Dit gebeurt met het standaardhulpprogramma
`ffmpeg`. De normale volumeschuif van **0–100%** blijft werken en wordt **na**
het normaliseren toegepast. 100% geeft het volle genormaliseerde geluid.

- De oorspronkelijke MP3-bestanden blijven ongewijzigd. FFmpeg schrijft de
  bewerkte opnames afzonderlijk weg in
  `~/.local/share/russische-woordflitser/audio/normalized-v1/`.
- De **eerste keer** afspelen kan iets langer duren om een bestaande opname te
  normaliseren; latere keren gebruiken de gecachte versie zonder vertraging.
  De normalisatie vereist **geen internet**, ook niet voor bestaande MP3's.
- Ontbreekt `ffmpeg` of lukt de omzetting niet, dan blijft de gewone
  MP3-uitspraak zonder normalisatie werken. Op Ubuntu/Mint/Debian kan FFmpeg
  zo nodig worden geïnstalleerd met `sudo apt install ffmpeg`.
- Geluidssterkte wordt gelijkgetrokken, maar afhankelijk van stem, luidsprekers
  en andere toepassingen klinkt het niet altijd exact even hard als YouTube.

## Nieuw in v6.45 — Monochroom systeemvakicoon

Het icoon in de Linux-bovenbalk heeft een transparante achtergrond en een
minimalistische witte omlijning met `RU`, passend bij monochrome pictogrammen.

## Nieuw in v6.44 — Spraakvolume instellen

Open het **systeemvakmenu → Volume aanpassen…**. Er verschijnt een klein
venster met een **slider van 0 tot 100%** (standaard 75%). De ingestelde
waarde geldt voor de uitspraak van zowel Russische woorden als
voorbeeldzinnen, automatisch én na een handmatige klik. De speler past het
volume toe **bij de volgende uitspraak**; een opname die al afspeelt,
verandert niet tussentijds. De waarde wordt opgeslagen in `settings.json`
en bij de volgende start hergebruikt. Alleen het volume van de woordflitser
wijzigt; niet het algemene Linux-systeemvolume. Bij gebruik van
AppIndicator kan een slider niet rechtstreeks in het systeemvakmenu staan:
de menu-optie opent daarom een compact GTK-venster met de schuifregelaar.

De woordkaarten zijn nog steeds 580 × 290 pixels en je scores en
leerhistorie blijven behouden bij `update_existing.sh`.

## Nieuw in v6.43 — Alle thema’s in één keer aan/uit

Open het **systeemvakmenu → Thema’s oefenen**. Bovenaan staan nu
**Alle thema’s aan** en **Alle thema’s uit**, gevolgd door de bekende
15 afzonderlijke thema’s. Hiermee kun je eerst alles uitschakelen en daarna
alleen de gewenste thema’s aanvinken. Als alles uit staat, toont de app
geen nieuwe kaarten (ook niet via *Toon nu een woord*). Eén thema
opnieuw inschakelen is voldoende om het oefenen te hervatten; de bestaande
leerhistorie, instellingen en scores blijven intact.

De vinkjes worden bij de menukeuze direct aangepast. Bij een actieve
sessie gaat het oefenen na het opnieuw inschakelen van een thema vanzelf
verder. De bestaande kaartopmaak en alle audiofuncties zijn onveranderd.

## Nieuw in v6.42 — Vast merkteken op de aftelbalk

Een smal verticaal streepje op de bestaande voortgangsbalk markeert precies
**waar het antwoord getoond wordt**. Bij 9 seconden totale duur staat het
streepje op 66,7% van de balk, want het antwoord komt na 3 seconden
(dus bij 6 seconden resterend). Het streepje blijft tijdens het aftellen
op zijn plek; de balk wordt korter en verschiet tot dat punt van groen via
geel naar rood. Na het antwoord blijft de balk rood terwijl hij verder
krimpt. Als de afteller wordt stilgezet door **Toon antwoord** of een
beoordeling, verdwijnt het streepje samen met de actieve afteller.

De positie past zich automatisch aan als de aftelduur wordt gewijzigd;
pauzeren behoudt de markering. Het formaat blijft **580 × 290 pixels**.

## Nieuw in v6.41 — Vaste klikgebieden

Boven de scheidingslijn spreekt een klik alleen het woord uit; onder VOORBEELD
alleen de Russische voorbeeldzin, ook wanneer je niet precies op de letters
klikt. Knoppen en het kaartformaat zijn onveranderd.

## Nieuw in v6.40 — Russische voorbeeldzin beluisteren

- De Russische voorbeeldzin wordt **automatisch samen met het woord** met
  dezelfde natuurlijke Russische vrouwenstem uitgesproken. Bij **RU→NL**
  gebeurt dat vóór het aftellen; je volledige 9 seconden beginnen pas daarna.
- Bij **NL→RU** wordt het Russisch (woord plus zin) pas uitgesproken **nadat**
  het antwoord verschijnt. De kaart wacht tot de stem uitgesproken is en
  geeft daarna nog minimaal 2 seconden om het antwoord te beoordelen.
- Sinds v6.41 werkt de hele bovenste inhoudszone als woordklik en de hele
  onderste voorbeeldzone als zinklik (ook wanneer je naast de letters klikt).
- Via het systeemvakmenu **Voorbeeldzinnen automatisch uitspreken** kun je
  de extra automatische spraak uitzetten. Handmatig klikken werkt dan nog
  steeds, zolang de gewone spraakdienst beschikbaar is.
- Nieuwe MP3's worden bij eerste gebruik met `edge-tts` gemaakt en daarna
  uit de bestaande gebruikerscache hergebruikt. Dat vereist bij een nieuwe
  zin eenmalig internet. `./start.sh --prepare-audio` bereidt nu standaard
  woord én voorbeeldzin in één opname voor.
- Het formaat van de kaart blijft **580 × 290 pixels**, zonder extra knoppen.
  Alle leerstanden, afbeeldingen, eigen correcties en pauzefuncties blijven behouden.

## Nieuw in v6.39 — Alleen aftellen tot het antwoord

Boven de voorbeeldzinnen staat tijdens het nadenken uitsluitend
**Antwoord over 3 s** (met de juiste resterende seconden).
Zodra het antwoord zichtbaar wordt, verdwijnt deze tekst volledig.
Er verschijnt nooit meer **weg over ...**, **Antwoord zichtbaar** of
**Blijft open** op deze plaats. Bij pauzeren bevriest het getal; de
pauzeknop toont de toestand. De groen-geel-rode balk loopt zoals in
v6.38 ongewijzigd terug tot de kaart verdwijnt. De kaart blijft
**580 × 290 pixels** en alle leerstanden blijven behouden.

## v6.38 — Afteller op kaartformaat 580 × 290

Bij een totale leertijd van 9 seconden heeft de **balk altijd de resterende
kaarttijd als breedte**: 9 s = 100% groen, 7,5 s = 83% geel, 6 s = 67% rood
(antwoord verschijnt), 3 s = 33% rood, 0 s = leeg (kaart verdwijnt).
De kleur glijdt vóór het antwoord geleidelijk van groen via geel naar rood,
en blijft daarna rood. De oorspronkelijke v6.38 toonde twee tijdstippen naast de voorbeeldzinnen;
in v6.39 is deze tijdtekst vereenvoudigd tot alleen de seconden tot het antwoord.
Geen nieuwe knoppen of grotere kaart: nog steeds **580 × 290 pixels**.
De bestaande hover-/klikpauze bevriest de balk, kleur en resterende tijd. Met
*Toon antwoord* wordt de afteller gestopt en blijft de kaart open. De
leerhistorie, audio en alle andere functies blijven behouden.

De volgende kaart krijgt zo veel mogelijk alvast een MP3 tijdens de wachttijd tussen popups. Dit vermindert het aantal stille kaarten wanneer de online spraakdienst langzaam reageert. Bij een fout of een te late spraakreactie toont de afteller een korte statusmelding. De app speelt geen late audio af nadat de popup is gesloten.

## Installatie

Pak het ZIP-bestand uit in een aparte map en voer uit:

```bash
./update_existing.sh /pad/naar/je/bestaande/russische-woordflitser
```

Bestaande beoordelingen, spraakbestanden, afbeeldingen, autostart en instellingen blijven behouden. Voor het genereren van nieuwe audio moet `edge-tts` geïnstalleerd zijn in de `.venv` van de app en moet internet beschikbaar zijn. `ffplay` of `mpv` verzorgt het afspelen. Voor de nieuwe geluidsnormalisatie is `ffmpeg` nodig.

## Controleren

```bash
./start.sh --stop
./start.sh --background
```

De gerichte tests voor richting, score, scheduler en systeemvak zijn in een virtuele Linux-desktop gedaan. Bij zeer trage of onbereikbare TTS kan een nieuw woord alsnog stil zijn; in dat geval verschijnt een melding in de afteller.

## v6.30 — twee onafhankelijke leerstanden

De woorden zijn dezelfde, maar RU→NL (herkennen) en NL→RU (zelf Russisch
produceren) hebben elk hun eigen bekende woorden, Goed/Fout-beoordelingen,
kaartteller en herhaalschema. Schakel via **Oefenrichting** in het systeemvak.
De score bovenaan de kaart en de twee scores in het systeemvak worden apart
getoond. `./start.sh --progress` geeft beide overzichten.

**Migratie:** tot en met v6.29 was er één gedeelde voortgang zonder informatie
over de historische oefenrichting. Deze oude voortgang blijft volledig bestaan
als RU→NL; NL→RU begint met een eigen, lege voortgang. Een reservekopie van
`progress.json` wordt door de updater gemaakt. Verwijder of reset je
historie niet; de huidige audio-cache blijft ook gedeeld.

## v6.31 — Tekst aanpassen op de kaart

Klik op het potloodje **✎** in de rechterbovenhoek van een kaart. Bewerk
de Nederlandse betekenis en eventueel beide voorbeeldzinnen. Kies Opslaan
of Annuleren. Via *Standaard herstellen* kun je terug naar de oorspronkelijke
vertaling en voorbeeldzinnen. De kaart wordt tijdens het bewerken niet
automatisch gesloten en krijgt daarna opnieuw leertijd (of blijft open als
de vertaling al zichtbaar was).

Wijzigingen worden apart opgeslagen in
`~/.local/share/russische-woordflitser/woordcorrecties.json`, gedeeld voor
beide oefenrichtingen. Ze blijven behouden na updates en beïnvloeden
Goed/Fout, je scores en geplande herhalingen niet. De Russische woordvorm
is voorlopig niet te wijzigen: die fungeert als vaste sleutel voor je voortgang
en audio-cache. De eerdere vertaling bij **свой** is standaard verduidelijkt
naar **mijn/jouw/zijn/haar eigen**.

## v6.32 — Ondoorzichtig, versleepbaar bewerkvenster

Het bewerkvenster heeft altijd 100% dekking, onafhankelijk van de ingestelde
transparantie van de gewone woordkaart. Het is een zelfstandig venster met
vensterbalk (de extra blauwe sleepgreep is vervallen in v6.34).
Alle leerstanden, woordcorrecties, audio en popupinstellingen blijven ongewijzigd.


## v6.33 — Bewerken zonder overlap

De woordkaart gebruikt een speciaal X11-notificatievenster dat boven een
gewone editor kon blijven hangen. Dit gaf de indruk dat het bewerkvenster
transparant was. Tijdens het bewerken wordt alleen de woordkaart tijdelijk
verborgen; na Opslaan, Annuleren of sluiten verschijnt dezelfde kaart
weer op dezelfde plaats en met dezelfde transparantie. De editor zelf
blijft volledig ondoorzichtig en verplaatsbaar via de titelbalk. Scores, tekstcorrecties en voortgang blijven behouden.


## v6.34 — Vereenvoudigd bewerkvenster

De overbodige lichtblauwe balk met “Sleep hier om het venster te verplaatsen”
is verwijderd. De gewone titelbalk blijft aanwezig en is voldoende om het
bewerkvenster te verplaatsen. De vertaling staat daardoor hoger in het venster.
De gewone woordkaart, transparantie, score en bediening blijven onveranderd.


## v6.35 — Verwarringswoorden (NL → RU)

In **Thema’s oefenen** kun je **Verwarringswoorden (NL → RU)** aan- of uitzetten.
Kies als oefenrichting **NL → RU**. De kaart toont in het gewone vraaggedeelte
een Nederlandse betekenis met drie Russische opties in willekeurige volgorde.
De Nederlandse voorbeeldzin is direct zichtbaar. De correcte Russische vorm
en Russische voorbeeldzin verschijnen tijdens het onthulmoment. De kaartgrootte
blijft 580×290 en Goed/Fout en Volgende werken hetzelfde als voorheen.
De oefenvragen hebben ieder hun eigen herhaalhistorie; de gewone woordkaarten
en de 'bekende woorden'-score blijven onafhankelijk. Het thema is in RU → NL
bewust niet beschikbaar, zodat dezelfde Russische woorden niet dubbel worden
aangeboden.

Om nog meer oefenvragen toe te voegen: nieuwe objecten met `theme` 'verwarring',
`exercise_id` (uniek), `ru` (juiste antwoord), `nl` (opdracht), `choices` (drie
Russische opties) en `context_nl` / `context_ru` aan `words.json` toevoegen.
Het programma hoeft daarvoor niet te worden gewijzigd.


## v6.36 — Afteller pauzeren op de kaart

Naast **Toon antwoord** staat nu **Pauzeer**. Je kunt met de muis boven
**Pauzeer** blijven hangen: zolang de aanwijzer erboven staat, stoppen
zowel het automatisch onthullen als het sluiten van de kaart. Beweeg de
muis eraf om verder te tellen vanaf dezelfde resterende tijd.

Een **klik** zet de pauze vast, zodat je de muis kunt verplaatsen zonder
de aftelling te hervatten. De knop heet dan **Hervat**; nogmaals klikken
start de klok weer, ook als de muis nog op de knop staat. **Toon antwoord**
blijft tijdens een pauze werken. Na onthullen verdwijnen Toon antwoord
en Pauzeer zoals voorheen ten gunste van Goed/Fout. Een nieuwe kaart
begint altijd ongepauzeerd. De kaart blijft **580 × 290 pixels**.

De pauze is uitsluitend voor de huidige kaart; de instelling
**Automatische popups pauzeren** via het systeemvak blijft apart.


## v6.37 — Twee momenten op de afteller

Tijdens het nadenken toont de kleine tijdregel zowel de seconden tot het
antwoord (*Antw.*) als tot het verdwijnen van de kaart (*Weg*). In v6.37 werd de balk eerst rood gevuld en daarna korter;
in v6.38 loopt de breedte vanaf het eerste moment doorlopend terug,
terwijl de kleur van groen via geel naar rood gaat. De knop
**Pauzeer** bevriest zowel de tijden als de balk. Het bestaande kaartformaat
(580 × 290) is ongewijzigd. Na **Toon antwoord** blijft de kaart open.
