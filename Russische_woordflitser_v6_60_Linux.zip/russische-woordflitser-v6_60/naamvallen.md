# Naamvallen

| Naamval            | Simpele kern                             | Vraag die je stelt              | Sterke signalen                                                                                                                                                          |
| ------------------ | ---------------------------------------- | ------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| **Nominatief**     | onderwerp                                | Wie/wat doet iets?              | onderwerp van de zin<br/>basisvorm                                                                                                                                       |
| **Genitief**       | van / <br>afwezigheid                    | Van wie? <br>Waarvan?           | bezit <br>hoeveelheid <br>**нет**: niet <br>**без**: zonder  <br>**из** : uit/vanuit <br>**для**: (bestemd) voor<br>**с**  : van/af<br/>у  + ест: bij ... is / ... heeft |
| **Datief**         | ontvanger / <br>richting naar persoon    | Aan wie? <br>Wie krijgt iets?   | meewerkend voorwerp<br>geven, helpen, schrijven aan, <br>**к**  : naar...toe                                                                                             |
| **Accusatief**     | direct doel / <br>bestemming             | Wie/wat? <br>Waarheen?          | lijdend voorwerp<br>**в   + beweging naar**: naar/in<br>**на  + beweging naar**: naar/op<br>**под + beweging naar**: onder                                               |
| **Instrumentalis** | met / <br>middel / <br>bepaalde plaatsen | Met wie? <br>Waarmee? <br>Waar? | **с**    : met<br>**под**  : onder<br>**над**  : boven<br>**перед**: (ruimtelijk) voor <br>**между**: tussen<br>                                                          |
| **Prepositioneel** | vaste plaats / <br>onderwerp             | Waar? <br>Waarover?             | **в  + vaste plaats**: in <br>**на + vaste plaats**: op <br>**о/об**: over/betreffende                                                                                   |

Ezelsbrug: **N**ard schrijft **in** het **P**ark **met** **I**nkt **aan** de **D**ochter **van** de **G**itarist een **A**nsichtkaart.


De belangrijkste valkuil is **waar**. 

> **в / на + waar? → P**  
> **в / на + waarheen? → A**  
> **под + waar? → I**  
> **под + waarheen? → A**  
> **над / перед / между + waar? → I**  

Daar moet je óók naar het voorzetsel kijken:

  **в/на** + waar?          → **prepositioneel**  
  > Я в парке.            - Ik ben **in** het park.  
  > Я на стуле.           - Ik ben **op** de stoel.  

  **под/над/перед** + waar? → instrumentalis  
  > Я стою перед парком.  - Ik sta **voor** het park.  
  > Я под/над столом.     - Ik ben **onder/boven** tafel  

En bij beweging:

  **в/на/под** + waarheen?  → vaak accusatief
  > Я иду в парк.          - Ik ga **naar** het park.

## Verbuigingen

| Naamval                            | Mannelijk: стол | Vrouwelijk -а: мама | Vrouwelijk -я: кухня | Onzijdig -о: окно |
| ---------------------------------- | --------------- | ------------------- | -------------------- | ----------------- |
| **N** wie/wat doet                 | стол            | мама                | кухня                | окно              |
| **G** van wie / waarvan            | стол**а**       | мам**ы**            | кухн**и**            | окн**а**          |
| **D** aan / voor (ontvanger)       | стол**у**       | мам**е**            | кухн**е**            | окн**у**          |
| **A** wie/wat ondergaat / waarheen | стол            | мам**у**            | кухн**ю**            | окно              |
| **I** met wie /waarmee             | стол**ом**      | мам**ой**           | кухн**ей**           | окн**ом**         |
| **P** waar / waarover              | стол**е**       | мам**е**            | кухн**е**            | окн**е**          |

### Basisrijtjes:

**стол:** ∅ → а → у → ∅ → ом → е  
**мама:** а → ы → е → у → ой → е  
**семья:** я → и → е → ю → ёй → е  
**окно:** о → а → у → о → ом → е

---

### Voor mannelijk:

Levenloos - **стол** = tafel:

| Naamval | Russisch             | Nederlands                   | Vorm      |
| ------- | -------------------- | ---------------------------- | --------- |
| **N**   | **Это стол.**        | Dit is een tafel.            | стол      |
| **G**   | **Нет/Фото стола.**  | Geen/Foto van tafel.         | стола     |
| **D**   | **Я иду к столу.**   | Ik ga naar de tafel **toe**. | стол**у** |
| **A**   | **Я вижу стол.**     | Ik zie de tafel.             | стол      |
| **I**   | **Я под столом.**    | Ik ben onder de tafel.       | столом    |
| **P**   | **Фрукты на столе.** | Fruit op de tafel.           | столе     |

Levend - **Марк**:

| Naamval      | Russisch                 | Nederlands        | Vorm   |
| ------------ | ------------------------ | ----------------- | ------ |
| **N**        | **Это Марк.**            | Dit is Mark.      | Марк   |
| **G**        | **Фото Марка.**          | Foto van Mark.    | Марка  |
| **D**        | **Я иду к Марку.**       | Ik ga naar Mark.  | Марку  |
|              | **Я даю Марку.**         | Ik geef aan Mark. |        |
| **<u>A</u>** | **Я вижу Марк<u>а</u>.** | Ik zie Mark.      | Марка  |
| **I**        | **Я с Марком.**          | Ik ben met Mark.  | Марком |
| **P**        | **Я дмаю о Марке.**      | Ik denk aan Mark. | Марке  |

Dus levenloos wordt: -∅ → -а → -у →  ∅ → -ом → -е  
En levend wordt    : -∅ → -а → -у → -a → -ом → -е

---

### Voor vrouwelijk op **-а**: **мама** = mama:

| Naamval | **мама**          | Nederlands        | Vorm  |
| ------- | ----------------- | ----------------- | ----- |
| **N**   | **Это мама.**     | Dit is mama.      | мама  |
| **G**   | **Фото мамы.**    | Foto van mama.    | мамы  |
| **D**   | **Я иду к маме.** | Ik ga naar mama.  | маме  |
| **A**   | **Я вижу маму.**  | Ik zie mama.      | маму  |
| **I**   | **Я с мамой.**    | Ik ben met mama.  | мамой |
| **P**   | **Думаю о маме.** | Ik denk aan mama. | маме  |

Dus **-а** wordt: **-а → -ы → -е → -у → -ой → -е**

---

### Voor vrouwelijk op **-я**: **семья** = familie/gezin:

| Naamval | **семья**          | Nederlands             | Vorm   |
| ------- | ------------------ | ---------------------- | ------ |
| **N**   | **Это семья.**     | Dit is een gezin.      | семья  |
| **G**   | **Фото семьи.**    | Foto van het gezin.    | семьи  |
| **D**   | **Помощь семье.**  | Hulp voor het gezin.   | семье  |
| **A**   | **Я вижу семью.**  | Ik zie het gezin.      | семью  |
| **I**   | **Я с семьёй.**    | Ik ben met het gezin.  | семьёй |
| **P**   | **Думаю о семье.** | Ik denk aan het gezin. | семье  |

Dus **-я** wordt: **-я → -и → -е → -ю → -ей/-ёй → -е**

Maar woorden op **-ия** hebben een eigen patroon.

| Naamval | Russisch                  | Nederlands         | Vorm   |
| ------- | ------------------------- | ------------------ | ------ |
| **N**   | **Это Мария.**            | Dit is Maria.      | Мария  |
| **G**   | **Фото Марии.**           | Foto van Maria.    | Марии  |
| **D**   | **Я к Мар<u>ии</u>.**     | Ik ga naar Maria.  | Марии  |
| **A**   | **Я вижу Марию.**         | Ik zie Maria.      | Марию  |
| **I**   | **Я с Марией.**           | Ik ben met Maria.  | Марией |
| **P**   | **Думаю о Мар<u>ии</u>.** | Ik denk aan Maria. | Марии  |

---

### Voor onzijdig op **-о**: **окно** = raam:

| Naamval | **окно**          | Nederlands             | Vorm  |
| ------- | ----------------- | ---------------------- | ----- |
| **N**   | **Это окно.**     | Dit is een raam.       | окно  |
| **G**   | **Фото окна.**    | Foto van het raam.     | окна  |
| **D**   | **Я к окну.**     | Ik ga naar het raam.   | окну  |
| **A**   | **Я вижу окно.**  | Ik zie het raam.       | окно  |
| **I**   | **Я под окном.**  | Ik ben onder het raam. | окном |
| **P**   | **Снег на окне.** | Sneeuw op het raam.    | окне  |

Dus **-о** wordt: **-о → -а → -у → -о → -ом → -е**

---

### Met persoonlijke voornaamwoorden: ты / она

| Naamval | **ты**          | **она**        | Nederlands                 |
| ------- | --------------- | -------------- | -------------------------- |
| **N**   | Ты здесь.       | Она здесь.     | Jij bent / zij is hier.    |
| **G**   | Я без тебя.     | Я без неё.     | Ik ben zonder jou / haar.  |
| **D**   | Я к тебе.       | Я к ней.       | Ik ga naar jou / haar toe. |
| **A**   | Я вижу тебя.    | Я вижу её.     | Ik zie jou / haar.         |
| **I**   | Я с тобой.      | Я с ней.       | Ik ben met jou / haar.     |
| **P**   | Я думаю о тебе. | Я думаю о ней. | Ik denk aan jou / haar.    |
