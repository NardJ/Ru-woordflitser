#!/usr/bin/env python3
"""Update-instellingen: voeg uitsluitend ontbrekende nieuwe opties toe.

Bestaande waarden, onbekende persoonlijke opties en de precieze themaselectie
blijven ongewijzigd. Een fout/onleesbaar bestand leidt tot een STOP (geen reset).
"""
from __future__ import annotations
import json
import os
from pathlib import Path
import sys
import tempfile

NEW_DEFAULTS = {
    'interval_minutes': 5,
    'idle_seconds': 12,
    'hide_after_seconds': 9,
    'new_word_every': 5,
    'quiet_hours_from': '22:30',
    'quiet_hours_until': '08:00',
    'position': 'near-cursor',
    'voice': 'ru-RU-SvetlanaNeural',
    'play_audio_automatically': True,
    'speak_examples_automatically': True,
    'audio_volume': 75,
    'normalize_audio': True,
    'popup_opacity': 0.85,
    'direction': 'ru-nl',
    'selected_themes': ['mensen','thuis','eten','natuur','reizen','gezondheid',
                        'werk','kleding','tijd','handelingen','eigenschappen',
                        'grammatica','zinnen','verwarring','overig'],
}


def migrate(path: Path) -> tuple[str, ...]:
    """Save only missing keys. Never normalize or replace an existing value."""
    path = Path(path)
    data = json.loads(path.read_text(encoding='utf-8'))
    if not isinstance(data, dict):
        raise ValueError('settings.json moet een JSON-object bevatten; niets overschreven')
    missing = tuple(key for key in NEW_DEFAULTS if key not in data)
    if not missing:
        return missing
    # All old keys and values stay untouched, including [] and None.
    upgraded = dict(data)
    for key in missing:
        upgraded[key] = NEW_DEFAULTS[key]
    fd, tempname = tempfile.mkstemp(prefix='.settings-upgrade-', suffix='.tmp', dir=path.parent)
    try:
        os.fchmod(fd, path.stat().st_mode & 0o777)
        with os.fdopen(fd, 'w', encoding='utf-8') as target:
            json.dump(upgraded, target, ensure_ascii=False, indent=2)
            target.write('\n')
            target.flush()
            os.fsync(target.fileno())
        os.replace(tempname, path)
    finally:
        if os.path.exists(tempname):
            os.unlink(tempname)
    return missing


if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise SystemExit('Gebruik: python3 settings_migration.py /pad/naar/settings.json')
    try:
        missing = migrate(Path(sys.argv[1]))
    except (OSError, ValueError, TypeError, json.JSONDecodeError) as exc:
        raise SystemExit(f'Update afgebroken: bestaande instellingen niet leesbaar: {exc}')
    print('Bestaande instellingen ongewijzigd behouden.' +
          (f' Alleen nieuwe opties toegevoegd: {", ".join(missing)}.' if missing else ''))
