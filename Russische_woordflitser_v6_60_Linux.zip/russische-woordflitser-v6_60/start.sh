#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ "${1:-}" == "--prepare-audio" ]]; then
  if [[ ! -d .venv ]]; then python3 -m venv .venv; fi
  if ! .venv/bin/python -c 'import edge_tts' &>/dev/null; then
    echo 'Eenmalig edge-tts installeren (internet nodig)...'
    .venv/bin/python -m pip install -U edge-tts
  fi
  exec .venv/bin/python russische_woordflitser.py "$@"
fi
# Use the local virtualenv if it exists; otherwise only the Python standard library.
if [[ -x .venv/bin/python ]]; then
  exec .venv/bin/python russische_woordflitser.py "$@"
else
  exec python3 russische_woordflitser.py "$@"
fi
