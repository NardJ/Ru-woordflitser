#!/usr/bin/env python3
"""Cinnamon/XApp tray with separately anchored, compact flyout panels.

A regular AppIndicator/DBusMenu cannot host an interactive Gtk.Scale. This
module deliberately doesn't attach a Gtk.Menu to the icon: XApp click events
open a focusable undecorated Gtk.Window, exactly as the BluePlayer app does.

The Tk wordflitser remains the sole owner of settings/progress. This helper
only sends the existing IPC commands; it never writes settings.json itself.
"""
from __future__ import annotations
import time

import tray_icon as state


class XAppMenu:
    def __init__(self, Gtk, Gdk, GLib, XApp, send, socket_path, pause_path):
        self.Gtk, self.Gdk, self.GLib = Gtk, Gdk, GLib
        self.send = send
        self.socket_path, self.pause_path = socket_path, pause_path
        self.pending_volume = None
        self.volume_source = None
        self.syncing = False
        self.opening = False
        self.active_page = 'home'
        self.flyout_side = 'right'
        self.flyout_visible = False
        self.anchor_x = None
        self.anchor_y = None
        self.monitor_area = None
        self.menu_anchors = {}  # root menu entries controlling each flyout
        self.theme_scroll = None
        self.theme_buttons = {}
        self.direction_buttons = {}
        self.interval_buttons = {}
        self.countdown_buttons = {}
        self.ratio_buttons = {}
        self.flyout_close_source = None
        self.volume_dragging = False

        self.window = Gtk.Window.new(Gtk.WindowType.TOPLEVEL)
        self.window.set_title(f'Russische Woordflitser v{state.APP_VERSION}')
        self.window.set_decorated(False)
        # The main menu is one fixed toplevel. NEVER resize or move it when
        # opening a submenu: Cinnamon may relocate a growing window, causing
        # a visible jump. Each flyout has its own compact GTK popup window.
        self.window.set_resizable(False)
        self.window.set_skip_taskbar_hint(True)
        self.window.set_skip_pager_hint(True)
        self.window.set_keep_above(True)
        self.window.set_default_size(338, -1)
        self.window.set_accept_focus(True)
        self.window.set_focus_on_map(True)
        self.window.set_type_hint(Gdk.WindowTypeHint.DROPDOWN_MENU)
        self.window.connect('focus-out-event', self.on_focus_out)
        self.window.connect('delete-event', self.on_delete)
        self.window.connect('key-press-event', self.on_key)
        self.window.connect('leave-notify-event', self.on_menu_leave)
        self.window.get_style_context().add_class('wordflitser-tray-popup')
        try:
            self.add_css()
        except (AttributeError, TypeError, ValueError, RuntimeError):
            # Styling is optioneel en mag geen werkend icon/menu verhinderen.
            pass

        self.main_frame = Gtk.Frame()
        self.main_frame.get_style_context().add_class('wordflitser-panel')
        self.main_frame.set_shadow_type(Gtk.ShadowType.OUT)
        self.window.add(self.main_frame)
        main_container = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
        main_container.set_border_width(6)
        main_container.set_size_request(338, -1)
        self.main_frame.add(main_container)
        self.title_label = Gtk.Label(label=f'Russische Woordflitser v{state.APP_VERSION}')
        self.title_label.set_xalign(0)
        self.title_label.get_style_context().add_class('wordflitser-title')
        main_container.pack_start(self.title_label, False, False, 3)
        self.home_page = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=2)
        self.home_page.set_border_width(2)
        main_container.pack_start(self.home_page, False, False, 0)

        # Popup instead of another managed TOPLEVEL: no taskbar icon, no menu
        # resize, and pointer interaction without stealing keyboard focus from
        # the main volume slider. XApp stays the only tray/status icon.
        self.flyout_window = Gtk.Window.new(Gtk.WindowType.POPUP)
        self.flyout_window.set_decorated(False)
        self.flyout_window.set_resizable(False)
        self.flyout_window.set_skip_taskbar_hint(True)
        self.flyout_window.set_skip_pager_hint(True)
        self.flyout_window.set_keep_above(True)
        self.flyout_window.set_accept_focus(False)
        self.flyout_window.set_focus_on_map(False)
        self.flyout_window.set_type_hint(Gdk.WindowTypeHint.DROPDOWN_MENU)
        self.flyout_window.get_style_context().add_class('wordflitser-tray-popup')
        self.flyout_window.connect('key-press-event', self.on_key)
        self.flyout_window.connect('enter-notify-event', self.on_flyout_enter)
        self.flyout_window.connect('leave-notify-event', self.on_menu_leave)
        self.flyout_frame = Gtk.Frame()
        self.flyout_frame.get_style_context().add_class('wordflitser-panel')
        self.flyout_frame.set_shadow_type(Gtk.ShadowType.OUT)
        self.flyout_window.add(self.flyout_frame)
        flyout_container = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
        flyout_container.set_border_width(6)
        flyout_container.set_size_request(338, -1)
        self.flyout_frame.add(flyout_container)
        self.flyout_title = Gtk.Label(label='')
        self.flyout_title.set_xalign(0)
        self.flyout_title.get_style_context().add_class('wordflitser-title')
        flyout_container.pack_start(self.flyout_title, False, False, 3)
        self.stack = Gtk.Stack()
        self.stack.set_transition_type(Gtk.StackTransitionType.NONE)
        self.stack.set_vhomogeneous(False)
        self.stack.set_hhomogeneous(True)
        # Het zijpaneel mag niet verticaal uitrekken tot hoofdmenuhoogte.
        # vhomogeneous=False laat korte pagina's (zoals Oefenrichting)
        # krimpen; Thema's mag door het scrolvak langer blijven.
        flyout_container.pack_start(self.stack, False, False, 0)
        # The flyout window is hidden until a menu item is hovered/clicked.
        self.build_home()
        self.build_directions()
        self.build_themes()
        self.build_timing()
        self.build_speech()

        # BluePlayer's known working Cinnamon/XApp approach. Never attach a
        # native Gtk.Menu, since menu grabs swallow Gtk.Scale pointer events.
        self.icon = XApp.StatusIcon()
        self.icon.set_name('Russische Woordflitser')
        self.icon.set_icon_name(str(state.ICON) if state.ICON.is_file()
                                else 'applications-education')
        self.icon.set_tooltip_text(f'Russische Woordflitser v{state.APP_VERSION} — instellingen')
        self.icon.connect('button-release-event', self.on_icon_release)
        self.icon.set_visible(True)
        GLib.timeout_add_seconds(2, self.on_tick)

    def add_css(self):
        Gtk, Gdk = self.Gtk, self.Gdk
        css = Gtk.CssProvider()
        css.load_from_data(b'''
            .wordflitser-tray-popup .wordflitser-panel {
                background-color: @theme_bg_color;
                background-image: none;
            }
            .wordflitser-tray-popup label { font-size: 10pt; }
            .wordflitser-tray-popup .wordflitser-title {
                font-weight: bold; padding: 2px 5px 4px; }
            .wordflitser-tray-popup button.wordflitser-entry {
                padding: 3px 7px; min-height: 0; margin: 0;
                border: 0; box-shadow: none; background-image: none; }
            .wordflitser-tray-popup scale { margin: 0; padding: 0; }
            .wordflitser-tray-popup separator { min-height: 1px; margin: 3px 0; }
            .wordflitser-tray-popup checkbutton,
            .wordflitser-tray-popup radiobutton { padding: 3px 5px; }
        ''')
        screen = Gdk.Screen.get_default()
        if screen is not None:
            Gtk.StyleContext.add_provider_for_screen(
                screen, css, Gtk.STYLE_PROVIDER_PRIORITY_APPLICATION)
        self.css = css

    def page(self, name):
        if name == 'home':
            return self.home_page
        box = self.Gtk.Box(orientation=self.Gtk.Orientation.VERTICAL, spacing=2)
        box.set_border_width(2)
        self.stack.add_named(box, name)
        return box

    def separator(self, page):
        page.pack_start(self.Gtk.Separator(orientation=self.Gtk.Orientation.HORIZONTAL),
                        False, False, 2)

    def label(self, page, text, *, secondary=False):
        label = self.Gtk.Label(label=text)
        label.set_xalign(0)
        if secondary:
            label.get_style_context().add_class('dim-label')
        page.pack_start(label, False, False, 2)
        return label

    def entry(self, page, text, callback, arrow=False, submenu=None):
        Gtk = self.Gtk
        button = Gtk.Button()
        button.set_relief(Gtk.ReliefStyle.NONE)
        button.get_style_context().add_class('wordflitser-entry')
        row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=8)
        text_label = Gtk.Label(label=text)
        text_label.set_xalign(0)
        row.pack_start(text_label, True, True, 0)
        if arrow:
            row.pack_end(Gtk.Label(label='›'), False, False, 0)
        button.add(row)
        button.connect('clicked', lambda _button: callback())
        if page is self.home_page:
            # Every other main-menu item collapses the current flyout; items
            # with their own flyout switch to that page instead.
            button.connect('enter-notify-event',
                           lambda _widget, _event, target=submenu: self.on_main_item_enter(target))
        if submenu is not None:
            self.menu_anchors[submenu] = button
            button.connect('leave-notify-event', self.on_menu_leave)
        page.pack_start(button, False, False, 0)
        return button

    def send_action(self, cmd, *, close=True):
        if close:
            self.hide()
        self.send(cmd)

    def build_home(self):
        Gtk = self.Gtk
        box = self.page('home')
        self.score = self.label(box, '', secondary=True)
        self.separator(box)
        volume_row = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=6)
        volume_label = Gtk.Label(label='Uitspraakvolume')
        volume_label.set_xalign(0)
        volume_row.pack_start(volume_label, True, True, 0)
        self.volume_label = Gtk.Label(label='')
        volume_row.pack_end(self.volume_label, False, False, 0)
        box.pack_start(volume_row, False, False, 1)
        self.scale = Gtk.Scale.new_with_range(Gtk.Orientation.HORIZONTAL, 0, 200, 1)
        self.scale.set_size_request(292, -1)
        self.scale.set_draw_value(False)
        self.scale.connect('value-changed', self.on_volume_change)
        # A slider drag may legitimately leave the window while held down.
        # Do not auto-dismiss until the user releases the pointer.
        self.scale.connect('button-press-event', self.on_volume_press)
        self.scale.connect('button-release-event', self.on_volume_release)
        box.pack_start(self.scale, False, False, 0)
        endpoints = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=2)
        endpoints.pack_start(Gtk.Label(label='0%'), False, False, 0)
        endpoints.pack_end(Gtk.Label(label='200%'), False, False, 0)
        box.pack_start(endpoints, False, False, 0)
        self.separator(box)
        self.entry(box, 'Toon nu een woord', lambda: self.send_action('show'))
        self.entry(box, 'Start oefensessie', lambda: self.send_action('session'))
        self.entry(box, 'Stop oefensessie', lambda: self.send_action('end-session'))
        self.pause_button = self.entry(box, 'Pauzeer automatische popups', self.pause_or_resume)
        self.entry(box, 'Leerstatistieken', lambda: self.send_action('stats'))
        self.separator(box)
        self.entry(box, 'Oefenrichting', lambda: self.navigate('directions'), arrow=True, submenu='directions')
        self.entry(box, 'Thema’s oefenen', lambda: self.navigate('themes'), arrow=True, submenu='themes')
        self.entry(box, 'Tijd & herhalingen', lambda: self.navigate('timing'), arrow=True, submenu='timing')
        self.entry(box, 'Spraakinstellingen', lambda: self.navigate('speech'), arrow=True, submenu='speech')
        self.separator(box)
        self.entry(box, 'Woordflitser herstarten', lambda: self.send_action('restart'))
        self.entry(box, 'Afsluiten', lambda: self.send_action('quit'))

    def radio_group(self, box, choices, current, command_prefix, store):
        Gtk = self.Gtk
        first = None
        for value, text in choices:
            radio = Gtk.RadioButton.new_with_label_from_widget(first, text)
            if first is None:
                first = radio
            radio.connect('toggled', self.on_radio, command_prefix, value)
            box.pack_start(radio, False, False, 0)
            store[value] = radio
        self.select_radio(store, current)

    def on_radio(self, widget, command_prefix, value):
        if not self.syncing and widget.get_active():
            self.send(f'{command_prefix}:{value}')

    def select_radio(self, options, value):
        if value in options:
            old = self.syncing
            self.syncing = True
            try:
                options[value].set_active(True)
            finally:
                self.syncing = old

    def build_directions(self):
        page = self.page('directions')
        self.radio_group(page, [('ru-nl', 'Russisch → Nederlands'),
                                ('nl-ru', 'Nederlands → Russisch')],
                         state.selected_direction(), 'direction', self.direction_buttons)

    def build_themes(self):
        Gtk = self.Gtk
        outer = self.page('themes')
        actions = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL, spacing=3)
        self.entry(actions, 'Alles aan', lambda: self.set_all_themes(True))
        self.entry(actions, 'Alles uit', lambda: self.set_all_themes(False))
        outer.pack_start(actions, False, False, 2)
        self.separator(outer)
        scroll = Gtk.ScrolledWindow()
        scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        scroll.set_size_request(-1, 360)
        theme_list = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
        theme_list.set_border_width(2)
        scroll.add(theme_list)
        outer.pack_start(scroll, True, True, 0)
        self.theme_scroll = scroll
        for key, title in state.THEME_CHOICES:
            button = Gtk.CheckButton.new_with_label(title)
            button.connect('toggled', self.on_theme, key)
            theme_list.pack_start(button, False, False, 0)
            self.theme_buttons[key] = button
        self.update_themes()

    def set_all_themes(self, selected):
        self.syncing = True
        try:
            for widget in self.theme_buttons.values():
                widget.set_active(selected)
        finally:
            self.syncing = False
        self.send('themes:all' if selected else 'themes:none')

    def on_theme(self, widget, key):
        if not self.syncing:
            self.send(f'theme:{key}:{int(widget.get_active())}')

    def update_themes(self):
        selected = state.selected_themes()
        self.syncing = True
        try:
            for key, widget in self.theme_buttons.items():
                widget.set_active(key in selected)
        finally:
            self.syncing = False

    def build_timing(self):
        Gtk = self.Gtk
        page = self.page('timing')
        self.label(page, 'Interval automatische popups')
        self.radio_group(page, [(m, ('Elke minuut' if m == 1 else f'Elke {m} minuten'))
                                for m in state.INTERVAL_CHOICES],
                         state.selected_interval(), 'interval', self.interval_buttons)
        self.separator(page)
        # No hidden second-level pages and hence no back button. The two
        # longer sets of choices unfold in place, within the same flyout.
        countdown = Gtk.Expander(label='Afteltijd popup')
        countdown_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
        self.radio_group(countdown_box, [(n, f'{n} seconden') for n in state.COUNTDOWN_CHOICES],
                         state.selected_countdown(), 'countdown', self.countdown_buttons)
        countdown.add(countdown_box)
        page.pack_start(countdown, False, False, 2)
        ratio = Gtk.Expander(label='Nieuwe woorden / herhalingen')
        ratio_box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=1)
        self.radio_group(ratio_box, [(n, f'1 nieuw + {n-1} herhaling' +
                                    ('' if n-1 == 1 else 'en'))
                                    for n in state.NEW_WORD_EVERY_CHOICES],
                         state.selected_new_word_every(), 'newratio', self.ratio_buttons)
        ratio.add(ratio_box)
        page.pack_start(ratio, False, False, 2)
        # Only one of the two expandable sections is open at once; long lists
        # won't unintentionally grow the popup beyond the desktop workarea.
        self.timing_expanders = {'countdown': countdown, 'ratio': ratio}
        countdown.connect('notify::expanded', lambda widget, *_: self.on_timing_expanded('countdown', widget))
        ratio.connect('notify::expanded', lambda widget, *_: self.on_timing_expanded('ratio', widget))

    def on_timing_expanded(self, name, widget):
        if widget.get_expanded():
            for other_name, other in self.timing_expanders.items():
                if other_name != name and other.get_expanded():
                    other.set_expanded(False)
        # A GTK popup does not always renegotiate size after an expander
        # changes. Reposition *only* the submenu, never the main window.
        if self.flyout_visible and self.active_page == 'timing':
            self.GLib.idle_add(lambda: (self._position_flyout('timing'), False)[1])

    def build_speech(self):
        Gtk = self.Gtk
        page = self.page('speech')
        self.examples = Gtk.CheckButton.new_with_label('Voorbeeldzinnen automatisch uitspreken')
        self.examples.connect('toggled', lambda w: self.on_check(w, 'examplespeech'))
        page.pack_start(self.examples, False, False, 0)
        self.normalization = Gtk.CheckButton.new_with_label('Spraakvolume automatisch normaliseren')
        self.normalization.connect('toggled', lambda w: self.on_check(w, 'normalizespeech'))
        page.pack_start(self.normalization, False, False, 0)
        self.label(page, 'Geluid wordt bij de volgende uitspraak aangepast.', secondary=True)
        self.update_speech()

    def on_check(self, widget, command):
        if not self.syncing:
            self.send(f'{command}:{int(widget.get_active())}')

    def update_speech(self):
        self.syncing = True
        try:
            self.examples.set_active(state.selected_example_speech())
            self.normalization.set_active(state.selected_audio_normalization())
        finally:
            self.syncing = False

    def paused(self):
        try:
            return float(self.pause_path.read_text().strip()) > time.time()
        except (OSError, ValueError):
            return False

    def pause_or_resume(self):
        self.send_action('resume' if self.paused() else 'pause')

    def refresh(self):
        self.score.set_text(f'Bekend RU→NL: {state.read_vocabulary_score("ru-nl")}  |  '
                            f'NL→RU: {state.read_vocabulary_score("nl-ru")}')
        self.pause_button.get_child().get_children()[0].set_text(
            'Hervat automatische popups' if self.paused() else 'Pauzeer automatische popups')
        self.update_speech()
        self.update_themes()
        self.select_radio(self.direction_buttons, state.selected_direction())
        self.select_radio(self.interval_buttons, state.selected_interval())
        self.select_radio(self.countdown_buttons, state.selected_countdown())
        self.select_radio(self.ratio_buttons, state.selected_new_word_every())
        if self.pending_volume is None:
            self.syncing = True
            try:
                self.scale.set_value(state.selected_volume())
                self.volume_label.set_text(f'{int(self.scale.get_value())}%')
            finally:
                self.syncing = False

    def on_volume_change(self, scale):
        value = round(scale.get_value())
        self.volume_label.set_text(f'{value}%')
        if self.syncing:
            return
        self.pending_volume = value
        if self.volume_source is not None:
            self.GLib.source_remove(self.volume_source)
        self.volume_source = self.GLib.timeout_add(120, self.flush_volume)

    def flush_volume(self):
        self.volume_source = None
        value = self.pending_volume
        self.pending_volume = None
        if value is not None:
            self.send(f'volume:{value}')
        return False

    def on_volume_press(self, *_args):
        self.volume_dragging = True
        self.cancel_flyout_close()
        return False  # Let Gtk.Scale handle the drag normally.

    def on_volume_release(self, *_args):
        self.volume_dragging = False
        # If released outside the menu, it should close as usual; if released
        # inside, the subsequent check will simply do nothing.
        if self.window.get_visible():
            self.schedule_flyout_close()
        return False

    def _preferred_flyout_width(self):
        return 338

    def _popup_area(self):
        if self.monitor_area is not None:
            return self.monitor_area
        display = self.Gdk.Display.get_default()
        if display is None:
            return None
        x, y = self.window.get_position()
        monitor = display.get_monitor_at_point(x, y)
        return monitor.get_workarea() if monitor else None

    def _root_page(self, page):
        return page

    def _entry_top(self, page):
        """Return the absolute Y coordinate of the submenu's ROOT entry.

        translate_coordinates uses GTK's *actual allocated layout*; guessing a
        row number/height fails across Cinnamon themes, font sizes and DPI.
        """
        _x, menu_y = self.window.get_position()
        button = self.menu_anchors.get(self._root_page(page))
        if button is None:
            return menu_y
        try:
            result = button.translate_coordinates(self.window, 0, 0)
            if result is not None:
                return menu_y + int(result[1])
        except (TypeError, AttributeError, ValueError, RuntimeError):
            pass
        # Some GTK backends cannot translate until widgets are realized.
        try:
            return menu_y + int(button.get_allocation().y)
        except (AttributeError, TypeError, ValueError):
            return menu_y

    def _position_flyout(self, page):
        """Position only the flyout, leaving the main window untouched."""
        # Account for GTK frame borders/theme padding, not only content width.
        width = max(self._preferred_flyout_width(),
                    self.flyout_window.get_preferred_width()[1])
        area = self._popup_area()
        main_x, _main_y = self.window.get_position()
        main_width = max(338, self.window.get_allocated_width())
        room_left = main_x - area.x if area else main_x
        room_right = (area.x + area.width - main_x - main_width
                      if area else width)
        use_right = room_right >= width or room_right >= room_left
        self.flyout_side = 'right' if use_right else 'left'
        x = main_x + main_width if use_right else main_x - width
        y = self._entry_top(page)

        # A long theme list may need a shorter viewport on low screens. The
        # rest of the submenu remains naturally sized, not full-menu height.
        if self.theme_scroll is not None:
            if page == 'themes' and area is not None:
                free_below = area.y + area.height - y
                self.theme_scroll.set_size_request(-1, max(105, min(360, free_below - 130)))
            else:
                self.theme_scroll.set_size_request(-1, 360)

        # GTK queues drawing until the next main-loop iteration. Show and
        # position synchronously, before the submenu can be painted.
        self.flyout_window.show_all()
        height = max(1, self.flyout_window.get_preferred_height()[1])
        if area is not None:
            x = max(area.x, min(x, area.x + area.width - width))
            # Prefer exact row alignment. Only shift upward when content
            # otherwise spills beyond the bottom of the display.
            y = max(area.y, min(y, area.y + area.height - height))
        self.flyout_window.move(int(x), int(y))
        self.flyout_visible = True

    def _show_flyout(self):
        if self.window.get_visible():
            self._position_flyout(self.active_page)

    def _hide_flyout(self):
        self.cancel_flyout_close()
        self.flyout_window.hide()
        self.flyout_visible = False

    def cancel_flyout_close(self):
        if self.flyout_close_source is not None:
            self.GLib.source_remove(self.flyout_close_source)
            self.flyout_close_source = None

    def _pointer_position(self):
        """Read the current pointer from GDK, not stale leave-event coords."""
        try:
            display = self.Gdk.Display.get_default()
            screen, x, y = display.get_default_seat().get_pointer().get_position()
            return int(x), int(y)
        except (AttributeError, TypeError, ValueError, RuntimeError):
            return None

    @staticmethod
    def _inside_window(window, x, y):
        if not window.get_visible():
            return False
        wx, wy = window.get_position()
        try:
            width = window.get_allocated_width()
            height = window.get_allocated_height()
        except (AttributeError, TypeError, ValueError, RuntimeError):
            width, height = window.get_preferred_width()[1], window.get_preferred_height()[1]
        return wx <= x < wx + width and wy <= y < wy + height

    def _inside_active_anchor(self, x, y):
        button = self.menu_anchors.get(self.active_page)
        if button is None:
            return False
        try:
            bx, by = button.translate_coordinates(self.window, 0, 0)
            wx, wy = self.window.get_position()
            width = button.get_allocated_width()
            height = button.get_allocated_height()
            return (wx + bx <= x < wx + bx + width and
                    wy + by <= y < wy + by + height)
        except (TypeError, AttributeError, ValueError, RuntimeError):
            return False

    def on_main_item_enter(self, submenu):
        self.cancel_flyout_close()
        if submenu is None:
            self.navigate('home')
        else:
            self.navigate(submenu)
        return False

    def on_flyout_enter(self, *_args):
        self.cancel_flyout_close()
        return False

    def on_menu_leave(self, *_args):
        # Also check when *no* submenu is open: otherwise the main menu can
        # remain on-screen forever after the pointer leaves it.
        if self.window.get_visible():
            self.schedule_flyout_close()
        return False

    def schedule_flyout_close(self):
        """Grace period for moving between the main window and a flyout."""
        self.cancel_flyout_close()
        self.flyout_close_source = self.GLib.timeout_add(180, self.check_flyout_close)

    def check_flyout_close(self):
        self.flyout_close_source = None
        if not self.window.get_visible():
            return False
        if self.volume_dragging:
            # A grabbed pointer may be temporarily outside the window while
            # the user is sliding the volume control. Wait for release.
            return False
        pointer = self._pointer_position()
        if pointer is None:
            # Unable to establish where the pointer is; don't guess and close
            # the entire menu unexpectedly.
            return False
        x, y = pointer
        if self.flyout_visible and self._inside_window(self.flyout_window, x, y):
            return False
        if self._inside_window(self.window, x, y):
            # A flyout stays open when hovering its owning entry, but closes
            # when hovering the rest of the main menu (even empty space).
            if self.flyout_visible and not self._inside_active_anchor(x, y):
                self.navigate('home')
            return False
        if self.opening:
            # Ignore the initial icon-to-window pointer transition.
            self.schedule_flyout_close()
            return False
        # Pointer is in neither menu window: close both (if present), and
        # preserve pending volume adjustments as hide() normally does.
        self.hide()
        return False

    def navigate(self, page):
        self.flush_pending_volume()
        if page not in ('home', 'directions', 'themes', 'timing', 'speech'):
            raise ValueError(page)
        self.cancel_flyout_close()
        self.active_page = page
        if page == 'home':
            self._hide_flyout()
            return
        self.flyout_title.set_text({'directions':'Oefenrichting', 'themes':'Thema’s oefenen',
                                    'timing':'Tijd & herhalingen', 'speech':'Spraakinstellingen'}[page])
        self.stack.set_visible_child_name(page)
        # Switching pages can change panel height but NEVER main geometry.
        self._show_flyout()

    def flush_pending_volume(self):
        if self.volume_source is not None:
            self.GLib.source_remove(self.volume_source)
            self.volume_source = None
        self.flush_volume()

    def hide(self):
        self.flush_pending_volume()
        self._hide_flyout()
        self.volume_dragging = False
        self.window.hide()
        self.active_page = 'home'

    def on_focus_out(self, *_args):
        if not self.opening:
            # Popup windows do not claim keyboard focus, but certain window
            # managers still send focus-out events during a popup click.
            # Do not close while the submenu itself temporarily has focus.
            if self.flyout_visible and self.flyout_window.is_active():
                return False
            self.hide()
        return False

    def on_delete(self, *_args):
        self.hide()
        return True

    def on_key(self, _window, event):
        if event.keyval == 0xff1b:  # Escape
            if self.active_page != 'home':
                self.navigate('home')
            else:
                self.hide()
            return True
        return False

    def on_icon_release(self, _icon, x, y, button, _time, panel_position):
        if button in (1, 3):
            self.toggle(x, y, panel_position)

    def toggle(self, x, y, position):
        if self.window.get_visible():
            self.hide()
            return
        self.opening = True
        self.navigate('home')
        self.refresh()
        self.window.show_all()
        self._hide_flyout()
        width = max(338, self.window.get_preferred_width()[1])
        height = self.window.get_preferred_height()[1]
        display = self.Gdk.Display.get_default()
        monitor = display.get_monitor_at_point(x, y) if display is not None else None
        area = monitor.get_workarea() if monitor else None
        try:
            icon_size = max(18, self.icon.get_icon_size())
        except (AttributeError, TypeError, ValueError):
            icon_size = 24
        if position == self.Gtk.PositionType.BOTTOM:
            left, top = x, y - height
        elif position == self.Gtk.PositionType.LEFT:
            left, top = x + icon_size, y
        elif position == self.Gtk.PositionType.RIGHT:
            left, top = x - width, y
        else:
            left, top = x, y + icon_size
        if area is not None:
            left = max(area.x, min(left, area.x + area.width - width))
            top = max(area.y, min(top, area.y + area.height - height))
        self.anchor_x, self.anchor_y = int(left), int(top)
        self.monitor_area = area
        self.window.move(int(left), int(top))
        self.window.present()
        self.GLib.timeout_add(200, self.finish_opening)

    def finish_opening(self):
        self.opening = False
        return False

    def on_tick(self):
        if not self.socket_path.exists():
            self.hide()
            self.Gtk.main_quit()
            return False
        # Don't overwrite a user's edits while the popup is open.
        if not self.window.get_visible():
            return True
        return True
