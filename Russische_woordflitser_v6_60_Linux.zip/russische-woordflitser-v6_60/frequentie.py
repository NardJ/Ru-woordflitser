"""Corpus-gestuurde rangschikking voor de Russische woordflitser.

Bron: O.N. Ljasjevskaja & S.A. Sjarov, frequentiewoordenboek NKRJa
(2009/2011); CSV-spiegel: appomsk/russian-words, russian-freq.csv.
Data ophalen is *eenmalig*, met Python-standaardbibliotheek, buiten popup.
Bij een netwerkstoring gebruiken we alleen een bescheiden lokaal
startlijstje van direct geverifieerde veelgebruikte lemmata.
"""
from __future__ import annotations
import csv
import io
import json
from pathlib import Path
import time
import unicodedata
import urllib.request

SOURCE = 'Ljasjevskaja en Sjarov (2009/2011), Russisch Nationaal Corpus'
SOURCE_URL = 'https://raw.githubusercontent.com/appomsk/russian-words/main/russian-freq.csv'
BACKUP_URL = 'https://github.com/appomsk/russian-words/raw/main/russian-freq.csv'
# Volgorde: eerste lemmata uit de corpuslijst. Niet het volledige corpus:
# dit is uitsluitend de offline noodrangschikking.
VERIFIED_TOP = '''
и в не на я быть он с что а по это она этот к но они мы как из у который то за свой весь год от так о для ты же все тот мочь вы человек такой его сказать только или ещё бы себя один уже до время если сам когда другой вот говорить наш мой знать стать при чтобы дело жизнь кто первый очень два день новый рука даже во со раз где там под можно ну какой после их работа без самый потом надо хотеть ли слово идти большой должен место иметь ничто сейчас тут лицо каждый друг нет теперь ни глаз тоже тогда видеть вопрос через да здесь дом потому сторона какой-то думать сделать страна жить чем мир об последний случай голова более делать что-то смотреть ребёнок просто конечно сила конец перед несколько вид система всегда работать между три понять пойти часть спросить город дать также никто понимать получить отношение лишь второй именно ваш хотя сидеть над женщина оказаться русский взять прийти являться деньги почему вдруг любить стоить почти земля общий ведь машина однако сразу хорошо вода отец высокий остаться выйти много проблема начать хороший час сегодня право совсем нога считать главный решение увидеть дверь казаться образ писать история лучший власть закон голос найти поэтому стоять вообще больше вместе маленький книга некоторый решить любой возможность результат ночь стол никогда имя молодой например оно число компания про полный принять народ никакой жена настоящий группа развитие давать ответить старый твой помнить ждать путь куда нужно разный нужный минута находиться опять белый улица чёрный вечер снова качество мысль дорога мать месяц язык любовь мама играть нельзя школа уйти комната читать письмо утро помощь ходить квартира
'''.split()


def normal(s: str) -> str:
    s = unicodedata.normalize('NFD', str(s or '')).replace('\u0301', '')
    return unicodedata.normalize('NFC', s).strip().casefold().replace('ё', 'е')


FALLBACK = {}
for i, lemma in enumerate(VERIFIED_TOP, 1):
    FALLBACK.setdefault(normal(lemma), i)


def get_lemma(word) -> str:
    raw = normal(word.get('ru', ''))
    # Uitdrukkingen krijgen géén fictieve corpusfrequentie voor de hele zin.
    return raw if ' ' not in raw and all(ch.isalpha() or ch == '-' for ch in raw) else ''


def load_cache(path: Path) -> dict:
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
        if data.get('source') == SOURCE and isinstance(data.get('entries'), dict):
            return data
    except (OSError, json.JSONDecodeError, AttributeError):
        pass
    return {}


def parse_rnc_csv(payload: bytes) -> dict:
    # In russ.-freq.csv staan lemmata alfabetisch met frequentie per miljoen.
    # Verschillende woordsoorten kunnen dezelfde lemma hebben.
    s = payload.decode('utf-8-sig')
    reader = csv.DictReader(io.StringIO(s), delimiter='\t')
    if not reader.fieldnames or not {'Lemma', 'Freq(ipm)'}.issubset(reader.fieldnames):
        raise ValueError('De bron heeft niet het verwachte CSV-formaat')
    amounts = {}
    n = 0
    for row in reader:
        lemma = normal(row.get('Lemma', ''))
        try:
            value = float(row['Freq(ipm)'])
        except (TypeError, ValueError):
            continue
        if not lemma or not value > 0 or (row.get('PoS') or '').endswith('.PROP'):
            continue
        amounts[lemma] = amounts.get(lemma, 0) + value
        n += 1
    if n < 10000 or len(amounts) < 10000:
        raise ValueError('De frequentiedata lijken onvolledig')
    # Corpuspositie is berekend over lemmata, niet over alle zinsvormen.
    ranking = sorted(amounts, key=lambda k: (-amounts[k], k))
    return {lemma: {'ipm': round(amounts[lemma], 3), 'rank': i}
            for i, lemma in enumerate(ranking, 1)}


def refresh_frequency(path: Path, words, timeout: float = 12,
                      opener=None) -> dict:
    """Haal corpus op, bewaar alleen metadata voor kaarten van deze cursus."""
    opener = opener or urllib.request.urlopen
    errors = []
    for url in (SOURCE_URL, BACKUP_URL):
        try:
            req = urllib.request.Request(url, headers={'User-Agent': 'RussianFlashcards/6.27 (educational)'})
            with opener(req, timeout=timeout) as response:
                payload = response.read(6_000_000)
            if len(payload) < 100000:
                raise ValueError('Te weinig gegevens ontvangen')
            corpus = parse_rnc_csv(payload)
            entries = {lemma: corpus[lemma] for w in words
                       if (lemma := get_lemma(w)) and lemma in corpus}
            obj = {'source': SOURCE, 'download_url': url,
                   'created_at': int(time.time()), 'corpus_lemmas': len(corpus),
                   'matched_cards': len(entries), 'entries': entries}
            path.parent.mkdir(parents=True, exist_ok=True)
            tmp = path.with_suffix('.tmp')
            tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
            tmp.replace(path)
            return obj
        except Exception as e:
            errors.append(f'{type(e).__name__}: {e}')
    raise RuntimeError('Corpus niet opgehaald: ' + ' / '.join(errors))


def priority(word: dict, cache: dict):
    """Lager is vroeger. Behoud nieuw/oud-ratio en SRS; alleen fresh kiezen."""
    lemma = get_lemma(word)
    if lemma:
        entry = cache.get('entries', {}).get(lemma, {})
        if isinstance(entry, dict) and entry.get('ipm', 0) > 0:
            return (0, -float(entry['ipm']), 0)
        if lemma in FALLBACK:
            return (1, FALLBACK[lemma], 0)
    if word.get('frequency_added_v627'):
        return (2, 0, 0)
    # Uitdrukkingen afzonderlijk gedoseerd, want voor een volledige zin
    # bestaat geen lexicale lemmafrequentie.
    if word.get('theme') == 'zinnen':
        return (3, 0, 0)
    return (4 if word.get('fase', 1) == 1 else 5, 0, 0)


def summary(cache: dict, words: list) -> str:
    entries = cache.get('entries', {})
    matched = sum(bool(get_lemma(w) in entries) for w in words)
    if not cache:
        return (f'Geen corpuscache; alleen offline topwoordenlijst ({len(FALLBACK)} lemmata).\n'
                'Voor de volledige rangschikking: ./start.sh --refresh-frequency')
    return (f'Bron: {cache.get("source")}\n'
            f'Download: {cache.get("download_url")}\n'
            f'Corpuslemmata: {cache.get("corpus_lemmas")}\n'
            f'Kaarten met corpusfrequentie: {matched}/{len(words)}\n'
            'Uitdrukkingen en ongekoppelde woorden krijgen een aparte praktische prioriteit.')
