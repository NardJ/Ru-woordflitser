# Illustraties en licenties — v6.18

De meegeleverde woordenlijst bevat momenteel afbeeldingen voor **727 van de 1.000 woorden
of uitdrukkingen**. Van de oorspronkelijke 757 koppelingen zijn er 30 na visuele controle
uitgeschakeld omdat het plaatje verkeerd of te verwarrend was. Zie `BEELDCONTROLE_V6_18.md`. De beelden zijn vooraf opgeslagen PNG-bestanden van 164 × 164
pixels, zodat er op de Linux-desktop geen extra afbeeldingsbibliotheken, fonts
of netwerktoegang nodig zijn om ze te tonen.

## Herkomst

- **Eigen vectorillustraties en diagrammen.** Speciaal gemaakt voor onder
  andere buurman/buurvrouw (persoon naast twee huizen), zwemmen, kopen,
  verkopen, opnieuw, kleuren, afmetingen en vol/leeg.
- **Noto Color Emoji (Google).** Betekenisgericht geselecteerde pictogrammen
  voor herkenbare handelingen, emoties, objecten en uitdrukkingen. De pictogrammen
  zijn gerenderd tot zelfstandige PNG-bestanden; er worden **geen fonts**
  meegestuurd. Bron: https://github.com/googlefonts/noto-emoji/
  (SIL Open Font License 1.1).
- **Font Awesome 4 (Dave Gandy).** Een deel van de eerdere pictogrammen bij
  zelfstandige naamwoorden gebruikt deze bron, CC BY 3.0.
  https://fontawesome.com/v4/license/
- **Oorspronkelijke 30 illustraties** zijn overgenomen uit de basisversie van
  de woordflitser.

Voor alles geldt: het beeld is een **geheugensteun**, geen definitie. Abstracte
woorden zonder ondubbelzinnige voorstelling blijven een tekstkaart. Bij een
werkwoord met onvoltooid en voltooid aspect kan dezelfde handeling als plaatje
worden gebruikt; het Russische woord en de Nederlandse vertaling bepalen de
juiste betekenis.

## Vertaalnuance

**опя́ть — opnieuw**, niet *het weer*; dat laatste heet in het Russisch
**пого́да**. Daarom is een herhaalsymbool gekoppeld en geen weerpictogram.
